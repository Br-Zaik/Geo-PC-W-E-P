using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace GeoOfficeAI.Shared
{
    /// <summary>
    /// Repairs a very small, explicitly-safe subset of common planner mistakes.
    /// It never executes code and never invents actions. The main use case is when
    /// a model accidentally embeds primitive parameters in the action name, e.g.
    /// set_margins{marginTopCm:2,marginBottomCm:2,...}.
    /// Complex/nested values are intentionally not repaired here; those are sent
    /// back to Gemini by the broker for a schema-valid retry.
    /// </summary>
    public static class PlanNormalizer
    {
        public static void Normalize(string host, OfficePlan plan)
        {
            if (plan == null || plan.actions == null) return;
            foreach (OfficeAction action in plan.actions)
            {
                if (action == null) continue;
                action.action = (action.action ?? "").Trim();
                if (PlanSafety.IsAllowedAction(host, action.action)) continue;

                string baseAction;
                Dictionary<string, string> args;
                if (!TryParseEmbeddedAction(action.action, out baseAction, out args)) continue;
                if (!PlanSafety.IsAllowedAction(host, baseAction)) continue;

                bool ok = true;
                foreach (var kv in args)
                {
                    if (!TryAssignPrimitive(action, kv.Key, kv.Value)) { ok = false; break; }
                }
                if (ok) action.action = baseAction;
            }
        }

        private static bool TryParseEmbeddedAction(string raw, out string action, out Dictionary<string, string> args)
        {
            action = null;
            args = null;
            if (string.IsNullOrWhiteSpace(raw)) return false;
            string x = raw.Trim();
            int openBrace = x.IndexOf('{');
            int openParen = x.IndexOf('(');
            int open;
            char close;
            if (openBrace >= 1 && (openParen < 0 || openBrace < openParen)) { open = openBrace; close = '}'; }
            else if (openParen >= 1) { open = openParen; close = ')'; }
            else return false;
            if (x[x.Length - 1] != close) return false;

            string name = x.Substring(0, open).Trim();
            if (name.Length == 0) return false;
            string inner = x.Substring(open + 1, x.Length - open - 2).Trim();
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (inner.Length > 0)
            {
                foreach (string piece in SplitTopLevel(inner))
                {
                    int colon = FindTopLevelColon(piece);
                    if (colon <= 0) return false;
                    string key = piece.Substring(0, colon).Trim().Trim('"', '\'');
                    string value = piece.Substring(colon + 1).Trim();
                    if (key.Length == 0 || value.Length == 0) return false;
                    if (ContainsComplexValue(value)) return false;
                    result[key] = Unquote(value);
                }
            }
            action = name;
            args = result;
            return true;
        }

        private static List<string> SplitTopLevel(string input)
        {
            var result = new List<string>();
            var sb = new StringBuilder();
            bool inQuote = false;
            char quote = '\0';
            for (int i = 0; i < input.Length; i++)
            {
                char c = input[i];
                if (inQuote)
                {
                    sb.Append(c);
                    if (c == quote && (i == 0 || input[i - 1] != '\\')) inQuote = false;
                    continue;
                }
                if (c == '"' || c == '\'') { inQuote = true; quote = c; sb.Append(c); continue; }
                if (c == ',' || c == ';')
                {
                    result.Add(sb.ToString().Trim());
                    sb.Clear();
                }
                else sb.Append(c);
            }
            if (sb.Length > 0) result.Add(sb.ToString().Trim());
            return result;
        }

        private static int FindTopLevelColon(string s)
        {
            bool inQuote = false; char quote = '\0';
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (inQuote)
                {
                    if (c == quote && (i == 0 || s[i - 1] != '\\')) inQuote = false;
                    continue;
                }
                if (c == '"' || c == '\'') { inQuote = true; quote = c; continue; }
                if (c == ':') return i;
            }
            return -1;
        }

        private static bool ContainsComplexValue(string value)
        {
            string v = value.Trim();
            return v.StartsWith("[") || v.StartsWith("{") || v.Contains("=>") || v.Contains(";") || v.IndexOf('\n') >= 0 || v.IndexOf('\r') >= 0;
        }

        private static string Unquote(string value)
        {
            string v = (value ?? "").Trim();
            if (v.Length >= 2 && ((v[0] == '"' && v[v.Length - 1] == '"') || (v[0] == '\'' && v[v.Length - 1] == '\'')))
                v = v.Substring(1, v.Length - 2);
            return v.Replace("\\\"", "\"").Replace("\\'", "'");
        }

        private static bool TryAssignPrimitive(OfficeAction a, string key, string raw)
        {
            double d; int i; bool b;
            switch ((key ?? "").Trim())
            {
                case "text": a.text = raw; return true;
                case "findText": a.findText = raw; return true;
                case "replacementText": a.replacementText = raw; return true;
                case "position": a.position = raw; return true;
                case "target": a.target = raw; return true;
                case "fontName": a.fontName = raw; return true;
                case "fontColorHex": a.fontColorHex = raw; return true;
                case "fillColorHex": a.fillColorHex = raw; return true;
                case "alignment": a.alignment = raw; return true;
                case "styleName": a.styleName = raw; return true;
                case "lineSpacing": a.lineSpacing = raw; return true;
                case "listType": a.listType = raw; return true;
                case "pageNumberPosition": a.pageNumberPosition = raw; return true;
                case "headerText": a.headerText = raw; return true;
                case "footerText": a.footerText = raw; return true;
                case "orientation": a.orientation = raw; return true;
                case "paperSize": a.paperSize = raw; return true;
                case "commentText": a.commentText = raw; return true;
                case "breakType": a.breakType = raw; return true;
                case "url": a.url = raw; return true;
                case "altText": a.altText = raw; return true;
                case "address": a.address = raw; return true;
                case "sheet": a.sheet = raw; return true;
                case "formula": a.formula = raw; return true;
                case "name": a.name = raw; return true;
                case "sourceRange": a.sourceRange = raw; return true;
                case "chartType": a.chartType = raw; return true;
                case "sortBy": a.sortBy = raw; return true;
                case "tableName": a.tableName = raw; return true;
                case "columnName": a.columnName = raw; return true;
                case "operatorName": a.operatorName = raw; return true;
                case "value1": a.value1 = raw; return true;
                case "value2": a.value2 = raw; return true;
                case "criteria1": a.criteria1 = raw; return true;
                case "destination": a.destination = raw; return true;
                case "dataField": a.dataField = raw; return true;
                case "summaryFunction": a.summaryFunction = raw; return true;
                case "title": a.title = raw; return true;
                case "subtitle": a.subtitle = raw; return true;
                case "shapeType": a.shapeType = raw; return true;
                case "filePath": a.filePath = raw; return true;
                case "effect": a.effect = raw; return true;
                case "speed": a.speed = raw; return true;
                case "notesText": a.notesText = raw; return true;
                case "layoutType": a.layoutType = raw; return true;

                case "replaceAll": if (TryBool(raw, out b)) { a.replaceAll = b; return true; } return false;
                case "matchCase": if (TryBool(raw, out b)) { a.matchCase = b; return true; } return false;
                case "bold": if (TryBool(raw, out b)) { a.bold = b; return true; } return false;
                case "italic": if (TryBool(raw, out b)) { a.italic = b; return true; } return false;
                case "underline": if (TryBool(raw, out b)) { a.underline = b; return true; } return false;
                case "enabled": if (TryBool(raw, out b)) { a.enabled = b; return true; } return false;
                case "ascending": if (TryBool(raw, out b)) { a.ascending = b; return true; } return false;

                case "fontSize": if (TryDouble(raw, out d)) { a.fontSize = d; return true; } return false;
                case "spaceBeforePt": if (TryDouble(raw, out d)) { a.spaceBeforePt = d; return true; } return false;
                case "spaceAfterPt": if (TryDouble(raw, out d)) { a.spaceAfterPt = d; return true; } return false;
                case "marginTopCm": if (TryDouble(raw, out d)) { a.marginTopCm = d; return true; } return false;
                case "marginBottomCm": if (TryDouble(raw, out d)) { a.marginBottomCm = d; return true; } return false;
                case "marginLeftCm": if (TryDouble(raw, out d)) { a.marginLeftCm = d; return true; } return false;
                case "marginRightCm": if (TryDouble(raw, out d)) { a.marginRightCm = d; return true; } return false;
                case "leftCm": if (TryDouble(raw, out d)) { a.leftCm = d; return true; } return false;
                case "topCm": if (TryDouble(raw, out d)) { a.topCm = d; return true; } return false;
                case "widthCm": if (TryDouble(raw, out d)) { a.widthCm = d; return true; } return false;
                case "heightCm": if (TryDouble(raw, out d)) { a.heightCm = d; return true; } return false;

                case "headingLevel": if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) { a.headingLevel = i; return true; } return false;
                case "columnsCount": if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) { a.columnsCount = i; return true; } return false;
                case "minLevel": if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) { a.minLevel = i; return true; } return false;
                case "maxLevel": if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) { a.maxLevel = i; return true; } return false;
                case "fieldIndex": if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) { a.fieldIndex = i; return true; } return false;
                case "slideIndex": if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) { a.slideIndex = i; return true; } return false;
                default: return false;
            }
        }

        private static bool TryDouble(string raw, out double value)
        {
            if (double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out value)) return true;
            return double.TryParse(raw, NumberStyles.Float, CultureInfo.CurrentCulture, out value);
        }

        private static bool TryBool(string raw, out bool value)
        {
            if (bool.TryParse(raw, out value)) return true;
            string x = (raw ?? "").Trim().ToLowerInvariant();
            if (x == "1" || x == "sí" || x == "si" || x == "yes") { value = true; return true; }
            if (x == "0" || x == "no") { value = false; return true; }
            value = false;
            return false;
        }
    }
}
