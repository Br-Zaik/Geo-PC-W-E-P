using System;
using System.Collections.Generic;
using System.IO;

namespace GeoOfficeAI.Shared
{
    public static class PlanSafety
    {
        private static readonly Dictionary<string, HashSet<string>> Allowed = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase)
        {
            { "word", new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                "replace_selection","insert_text","replace_text","format_selection","format_document","format_find","add_heading","add_list","add_table",
                "set_margins","set_orientation","set_paper_size","set_header","set_footer","add_page_numbers","page_break","add_comment","track_changes","insert_picture",
                "set_columns","add_toc","add_hyperlink","insert_section_break"
            }},
            { "excel", new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                "set_cell","set_formula","set_range_values","format_range","autofit","create_table","create_chart","add_sheet","rename_sheet",
                "merge_range","freeze_top_row","replace_text","insert_picture",
                "create_calculated_column","conditional_format","data_validation","sort_range","filter_range","create_pivot_table","define_name","set_calculation","show_totals_row"
            }},
            { "powerpoint", new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                "add_slide","set_slide_title","add_textbox","replace_text","format_text","add_table","add_shape","set_background","duplicate_slide","insert_picture",
                "apply_theme","set_transition","add_animation","align_shapes","distribute_shapes","set_notes","add_image_placeholder","set_slide_layout","apply_professional_style"
            }}
        };

        public static bool IsAllowedAction(string host, string action)
        {
            HashSet<string> allowed;
            return Allowed.TryGetValue(host ?? "", out allowed) && !string.IsNullOrWhiteSpace(action) && allowed.Contains(action.Trim());
        }

        public static string[] GetAllowedActions(string host)
        {
            HashSet<string> allowed;
            if (!Allowed.TryGetValue(host ?? "", out allowed)) return new string[0];
            string[] result = new string[allowed.Count];
            allowed.CopyTo(result);
            Array.Sort(result, StringComparer.OrdinalIgnoreCase);
            return result;
        }

        public static void Validate(string host, OfficePlan plan)
        {
            if (plan == null) throw new InvalidOperationException("Gemini devolvió un plan vacío.");
            if (plan.actions == null) plan.actions = new List<OfficeAction>();
            if (plan.sources == null) plan.sources = new List<WebSource>();
            if (plan.actions.Count > 160) throw new InvalidOperationException("Gemini intentó ejecutar demasiadas acciones en una sola petición.");

            PlanNormalizer.Normalize(host, plan);

            HashSet<string> allowed;
            if (!Allowed.TryGetValue(host ?? "", out allowed)) throw new InvalidOperationException("Aplicación de Office no reconocida.");

            long textBudget = 0;
            for (int index = 0; index < plan.actions.Count; index++)
            {
                OfficeAction a = plan.actions[index];
                if (a == null) throw new InvalidOperationException("La acción " + (index + 1) + " está vacía.");
                string action = (a.action ?? "").Trim();
                if (!allowed.Contains(action)) throw new InvalidOperationException("Acción bloqueada por seguridad: " + action);

                textBudget += Len(a.text) + Len(a.replacementText) + Len(a.headerText) + Len(a.footerText) + Len(a.commentText) + Len(a.title) + Len(a.subtitle)
                    + Len(a.formula) + Len(a.notesText) + Len(a.value1) + Len(a.value2) + Len(a.criteria1) + Len(a.url);
                if (a.items != null) foreach (string s in a.items) textBudget += Len(s);
                if (a.rows != null) foreach (var row in a.rows) if (row != null) foreach (string s in row) textBudget += Len(s);
                if (textBudget > 500000) throw new InvalidOperationException("La petición intenta insertar demasiado contenido de una sola vez.");

                ValidateCommonFormatting(a);
                if (string.Equals(host, "word", StringComparison.OrdinalIgnoreCase)) ValidateWordAction(action, a);
                else if (string.Equals(host, "excel", StringComparison.OrdinalIgnoreCase)) ValidateExcelAction(action, a);
                else if (string.Equals(host, "powerpoint", StringComparison.OrdinalIgnoreCase)) ValidatePowerPointAction(action, a);

                if ((string.Equals(action, "set_formula", StringComparison.OrdinalIgnoreCase) || string.Equals(action, "create_calculated_column", StringComparison.OrdinalIgnoreCase)) && SafeHelpers.LooksLikeUnsafeExcelFormula(a.formula))
                    throw new InvalidOperationException("La fórmula fue bloqueada por seguridad.");
                if (string.Equals(action, "add_hyperlink", StringComparison.OrdinalIgnoreCase)) ValidateHttpUrl(a.url);
                if (string.Equals(action, "apply_theme", StringComparison.OrdinalIgnoreCase)) ValidateThemePath(a.filePath);
                if (string.Equals(action, "insert_picture", StringComparison.OrdinalIgnoreCase)) ValidatePicturePath(a.filePath);
            }

            if (plan.sources.Count > 20) throw new InvalidOperationException("Gemini devolvió demasiadas fuentes.");
            foreach (WebSource s in plan.sources)
            {
                if (s == null || string.IsNullOrWhiteSpace(s.url)) continue;
                ValidateHttpUrl(s.url);
            }
        }

        private static void ValidateCommonFormatting(OfficeAction a)
        {
            if (a.fontSize.HasValue && (a.fontSize.Value < 6 || a.fontSize.Value > 96)) throw new InvalidOperationException("fontSize debe estar entre 6 y 96.");
            if (a.spaceBeforePt.HasValue && (a.spaceBeforePt.Value < 0 || a.spaceBeforePt.Value > 72)) throw new InvalidOperationException("spaceBeforePt debe estar entre 0 y 72.");
            if (a.spaceAfterPt.HasValue && (a.spaceAfterPt.Value < 0 || a.spaceAfterPt.Value > 72)) throw new InvalidOperationException("spaceAfterPt debe estar entre 0 y 72.");
            ValidateHexIfPresent(a.fontColorHex, "fontColorHex");
            ValidateHexIfPresent(a.fillColorHex, "fillColorHex");
        }

        private static void ValidateWordAction(string action, OfficeAction a)
        {
            switch (action.ToLowerInvariant())
            {
                case "insert_text": RequireText(a.text, "insert_text requiere text."); ValidatePosition(a.position); break;
                case "replace_selection": break;
                case "replace_text": RequireText(a.findText, "replace_text requiere findText."); break;
                case "format_selection": RequireFormatting(a, "format_selection no contiene ningún formato."); break;
                case "format_document": RequireFormatting(a, "format_document no contiene ningún formato."); break;
                case "format_find": RequireText(a.findText, "format_find requiere findText."); RequireFormatting(a, "format_find no contiene ningún formato."); break;
                case "add_heading":
                    RequireText(a.text, "add_heading requiere text.");
                    if (a.headingLevel.HasValue && (a.headingLevel.Value < 1 || a.headingLevel.Value > 9)) throw new InvalidOperationException("headingLevel debe estar entre 1 y 9.");
                    ValidatePosition(a.position); break;
                case "add_list":
                    if (a.items == null || a.items.Count == 0 || a.items.Count > 200) throw new InvalidOperationException("add_list requiere entre 1 y 200 elementos.");
                    ValidatePosition(a.position); break;
                case "add_table":
                    ValidateRows(a.rows, 100, 30, "Word"); ValidatePosition(a.position); break;
                case "set_margins":
                    if (!a.marginTopCm.HasValue && !a.marginBottomCm.HasValue && !a.marginLeftCm.HasValue && !a.marginRightCm.HasValue) throw new InvalidOperationException("set_margins requiere al menos un margen.");
                    ValidateCm(a.marginTopCm, 0.3, 8, "marginTopCm"); ValidateCm(a.marginBottomCm, 0.3, 8, "marginBottomCm");
                    ValidateCm(a.marginLeftCm, 0.3, 8, "marginLeftCm"); ValidateCm(a.marginRightCm, 0.3, 8, "marginRightCm"); break;
                case "set_orientation": RequireOneOf(a.orientation, "orientation", "portrait", "landscape", "vertical", "horizontal"); break;
                case "set_paper_size": RequireOneOf(a.paperSize, "paperSize", "a4", "letter", "carta", "legal"); break;
                case "set_header": break;
                case "set_footer": break;
                case "add_page_numbers": if (!string.IsNullOrWhiteSpace(a.pageNumberPosition)) RequireOneOf(a.pageNumberPosition, "pageNumberPosition", "left", "center", "right", "izquierda", "centro", "centrado", "derecha"); break;
                case "page_break": ValidatePosition(a.position); break;
                case "add_comment": if (string.IsNullOrWhiteSpace(a.commentText) && string.IsNullOrWhiteSpace(a.text)) throw new InvalidOperationException("add_comment requiere commentText o text."); break;
                case "track_changes": break;
                case "insert_picture": ValidatePosition(a.position); ValidateCm(a.widthCm, 0.1, 50, "widthCm"); ValidateCm(a.heightCm, 0.1, 50, "heightCm"); break;
                case "set_columns": if (!a.columnsCount.HasValue || a.columnsCount.Value < 1 || a.columnsCount.Value > 4) throw new InvalidOperationException("set_columns requiere columnsCount entre 1 y 4."); break;
                case "add_toc":
                    if (a.minLevel.HasValue && (a.minLevel.Value < 1 || a.minLevel.Value > 9)) throw new InvalidOperationException("minLevel debe estar entre 1 y 9.");
                    if (a.maxLevel.HasValue && (a.maxLevel.Value < 1 || a.maxLevel.Value > 9)) throw new InvalidOperationException("maxLevel debe estar entre 1 y 9.");
                    if (a.minLevel.HasValue && a.maxLevel.HasValue && a.maxLevel.Value < a.minLevel.Value) throw new InvalidOperationException("maxLevel no puede ser menor que minLevel.");
                    ValidatePosition(a.position); break;
                case "add_hyperlink": ValidatePosition(a.position); break;
                case "insert_section_break":
                    if (!string.IsNullOrWhiteSpace(a.breakType)) RequireOneOf(a.breakType, "breakType", "next_page", "continuous", "pagina_siguiente", "continuo");
                    ValidatePosition(a.position); break;
            }
        }

        private static void ValidateExcelAction(string action, OfficeAction a)
        {
            switch (action.ToLowerInvariant())
            {
                case "set_cell": RequireText(a.address, "set_cell requiere address."); break;
                case "set_formula": RequireText(a.address, "set_formula requiere address."); RequireText(a.formula, "set_formula requiere formula."); break;
                case "set_range_values": RequireText(a.address, "set_range_values requiere address."); ValidateRows(a.rows, 500, 100, "Excel"); break;
                case "format_range": RequireText(a.address, "format_range requiere address."); RequireFormatting(a, "format_range no contiene ningún formato."); break;
                case "create_table": RequireText(a.address, "create_table requiere address."); break;
                case "create_chart": RequireText(a.sourceRange, "create_chart requiere sourceRange."); break;
                case "add_sheet": RequireText(a.name, "add_sheet requiere name."); break;
                case "rename_sheet": RequireText(a.sheet, "rename_sheet requiere sheet."); RequireText(a.name, "rename_sheet requiere name."); break;
                case "merge_range": RequireText(a.address, "merge_range requiere address."); break;
                case "replace_text": RequireText(a.findText, "replace_text requiere findText."); break;
                case "create_calculated_column": RequireText(a.tableName, "create_calculated_column requiere tableName."); RequireText(a.columnName, "create_calculated_column requiere columnName."); RequireText(a.formula, "create_calculated_column requiere formula."); break;
                case "conditional_format": RequireText(a.address, "conditional_format requiere address."); break;
                case "data_validation": RequireText(a.address, "data_validation requiere address."); break;
                case "sort_range": RequireText(a.address, "sort_range requiere address."); RequireText(a.sortBy, "sort_range requiere sortBy."); break;
                case "filter_range": RequireText(a.address, "filter_range requiere address."); if (!a.fieldIndex.HasValue || a.fieldIndex.Value < 1) throw new InvalidOperationException("filter_range requiere fieldIndex >= 1."); break;
                case "create_pivot_table": RequireText(a.sourceRange, "create_pivot_table requiere sourceRange."); RequireText(a.destination, "create_pivot_table requiere destination."); break;
                case "define_name": RequireText(a.name, "define_name requiere name."); RequireText(a.address, "define_name requiere address."); break;
                case "set_calculation": RequireOneOf(a.target, "target", "automatic", "manual"); break;
                case "show_totals_row": RequireText(a.tableName, "show_totals_row requiere tableName."); break;
            }
        }

        private static void ValidatePowerPointAction(string action, OfficeAction a)
        {
            if (a.slideIndex.HasValue && a.slideIndex.Value < 1) throw new InvalidOperationException("slideIndex debe ser >= 1.");
            ValidateCm(a.leftCm, 0, 100, "leftCm"); ValidateCm(a.topCm, 0, 100, "topCm"); ValidateCm(a.widthCm, 0.1, 100, "widthCm"); ValidateCm(a.heightCm, 0.1, 100, "heightCm");
            switch (action.ToLowerInvariant())
            {
                case "set_slide_title": if (string.IsNullOrWhiteSpace(a.title) && string.IsNullOrWhiteSpace(a.text)) throw new InvalidOperationException("set_slide_title requiere title o text."); break;
                case "add_textbox": RequireText(a.text, "add_textbox requiere text."); break;
                case "replace_text": RequireText(a.findText, "replace_text requiere findText."); break;
                case "format_text": RequireFormatting(a, "format_text no contiene ningún formato."); break;
                case "add_table": ValidateRows(a.rows, 30, 12, "PowerPoint"); break;
                case "set_background": RequireText(a.fillColorHex, "set_background requiere fillColorHex."); break;
                case "apply_theme": RequireText(a.filePath, "apply_theme requiere filePath."); break;
                case "add_animation": RequireText(a.target ?? a.findText, "add_animation requiere target o findText."); break;
                case "set_notes": if (a.notesText == null && a.text == null) throw new InvalidOperationException("set_notes requiere notesText o text."); break;
                case "set_slide_layout": if (string.IsNullOrWhiteSpace(a.layoutType) && string.IsNullOrWhiteSpace(a.target)) throw new InvalidOperationException("set_slide_layout requiere layoutType."); break;
            }
        }

        private static void RequireFormatting(OfficeAction a, string message)
        {
            bool any = !string.IsNullOrWhiteSpace(a.fontName) || a.fontSize.HasValue || a.bold.HasValue || a.italic.HasValue || a.underline.HasValue ||
                !string.IsNullOrWhiteSpace(a.fontColorHex) || !string.IsNullOrWhiteSpace(a.fillColorHex) || !string.IsNullOrWhiteSpace(a.alignment) ||
                !string.IsNullOrWhiteSpace(a.styleName) || !string.IsNullOrWhiteSpace(a.numberFormat) || a.spaceBeforePt.HasValue || a.spaceAfterPt.HasValue || !string.IsNullOrWhiteSpace(a.lineSpacing);
            if (!any) throw new InvalidOperationException(message);
        }

        private static void ValidateRows(List<List<string>> rows, int maxRows, int maxCols, string host)
        {
            if (rows == null || rows.Count == 0 || rows.Count > maxRows) throw new InvalidOperationException("La tabla/bloque de " + host + " requiere entre 1 y " + maxRows + " filas.");
            int cols = 0;
            foreach (List<string> row in rows) if (row != null) cols = Math.Max(cols, row.Count);
            if (cols < 1 || cols > maxCols) throw new InvalidOperationException("La tabla/bloque de " + host + " debe tener entre 1 y " + maxCols + " columnas.");
        }

        private static void ValidatePosition(string position)
        {
            if (string.IsNullOrWhiteSpace(position)) return;
            RequireOneOf(position, "position", "cursor", "start", "end", "inicio", "final");
        }

        private static void ValidateCm(double? value, double min, double max, string name)
        {
            if (value.HasValue && (double.IsNaN(value.Value) || double.IsInfinity(value.Value) || value.Value < min || value.Value > max))
                throw new InvalidOperationException(name + " debe estar entre " + min + " y " + max + ".");
        }

        private static void RequireText(string value, string message) { if (string.IsNullOrWhiteSpace(value)) throw new InvalidOperationException(message); }

        private static void RequireOneOf(string value, string name, params string[] values)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new InvalidOperationException(name + " es obligatorio.");
            foreach (string x in values) if (string.Equals(value.Trim(), x, StringComparison.OrdinalIgnoreCase)) return;
            throw new InvalidOperationException(name + " contiene un valor no admitido: " + value + ".");
        }

        private static void ValidateHexIfPresent(string value, string name)
        {
            if (string.IsNullOrWhiteSpace(value)) return;
            string h = value.Trim().TrimStart('#');
            if (h.Length != 6) throw new InvalidOperationException(name + " debe ser un color hexadecimal de 6 dígitos.");
            int dummy;
            if (!int.TryParse(h, System.Globalization.NumberStyles.HexNumber, System.Globalization.CultureInfo.InvariantCulture, out dummy))
                throw new InvalidOperationException(name + " debe ser un color hexadecimal válido.");
        }

        public static void ValidatePicturePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new InvalidOperationException("Para insertar una imagen debes indicar una ruta local existente.");
            string full;
            try { full = Path.GetFullPath(path); } catch { throw new InvalidOperationException("La ruta de la imagen no es válida."); }
            if (!File.Exists(full)) throw new FileNotFoundException("No se encontró la imagen indicada.", full);
            string ext = Path.GetExtension(full).ToLowerInvariant();
            string[] allowed = { ".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff" };
            bool ok = false; foreach (string x in allowed) if (ext == x) { ok = true; break; }
            if (!ok) throw new InvalidOperationException("Formato de imagen no permitido. Usa PNG, JPG, BMP, GIF o TIFF.");
            if (new FileInfo(full).Length > 25L * 1024L * 1024L) throw new InvalidOperationException("La imagen supera el límite de 25 MB.");
        }

        public static void ValidateThemePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new InvalidOperationException("Para aplicar un tema debes indicar un archivo local .thmx, .pot o .potx.");
            string full;
            try { full = Path.GetFullPath(path); } catch { throw new InvalidOperationException("La ruta del tema no es válida."); }
            if (!File.Exists(full)) throw new FileNotFoundException("No se encontró el tema indicado.", full);
            string ext = Path.GetExtension(full).ToLowerInvariant();
            if (ext != ".thmx" && ext != ".pot" && ext != ".potx") throw new InvalidOperationException("Formato de tema no permitido. Usa THMX, POT o POTX.");
            if (new FileInfo(full).Length > 50L * 1024L * 1024L) throw new InvalidOperationException("El archivo de tema supera 50 MB.");
        }

        public static void ValidateHttpUrl(string url)
        {
            Uri uri;
            if (string.IsNullOrWhiteSpace(url) || !Uri.TryCreate(url, UriKind.Absolute, out uri) || !(uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps))
                throw new InvalidOperationException("Solo se permiten hipervínculos http/https válidos.");
        }

        private static int Len(string s) { return string.IsNullOrEmpty(s) ? 0 : s.Length; }
    }
}
