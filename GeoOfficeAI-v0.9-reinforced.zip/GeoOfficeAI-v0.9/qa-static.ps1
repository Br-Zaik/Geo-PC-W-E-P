$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Require-Text([string]$Path, [string]$Pattern, [string]$Message) {
  $text = Get-Content (Join-Path $root $Path) -Raw
  if ($text -notmatch $Pattern) { throw $Message }
}

function Get-Allowed([string]$Host) {
  $text = Get-Content (Join-Path $root 'GeoOfficeAI.Shared\PlanSafety.cs') -Raw
  $m = [regex]::Match($text, '\{\s*"' + [regex]::Escape($Host) + '"\s*,\s*new HashSet<string>\([^\)]*\)\s*\{(?<body>.*?)\}\s*\}', 'Singleline')
  if (!$m.Success) { throw "No se encontró whitelist para $Host" }
  return [regex]::Matches($m.Groups['body'].Value, '"(?<a>[a-z0-9_]+)"') | ForEach-Object { $_.Groups['a'].Value } | Sort-Object -Unique
}

function Get-Handlers([string]$Path) {
  $text = Get-Content (Join-Path $root $Path) -Raw
  return [regex]::Matches($text, 'case\s+"(?<a>[a-z0-9_]+)"\s*:') | ForEach-Object { $_.Groups['a'].Value } | Sort-Object -Unique
}

$map = @{
  word = 'GeoOfficeAI.Word\WordAutomationService.cs'
  excel = 'GeoOfficeAI.Excel\ExcelAutomationService.cs'
  powerpoint = 'GeoOfficeAI.PowerPoint\PowerPointAutomationService.cs'
}
foreach ($host in $map.Keys) {
  $allowed = Get-Allowed $host
  $handlers = Get-Handlers $map[$host]
  $missing = $allowed | Where-Object { $_ -notin $handlers }
  if ($missing) { throw "${host}: acciones permitidas sin handler: $($missing -join ', ')" }
}

Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'responseJsonSchema' 'Falta structured output schema.'
Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'additionalProperties' 'El schema no bloquea propiedades inesperadas.'
Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'MaxPlanAttempts\s*=\s*3' 'Falta reparación automática limitada.'
Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'Ejemplo correcto Word' 'Falta ejemplo explícito que evita set_margins{...}.'
Require-Text 'GeoOfficeAI.Shared\PlanNormalizer.cs' 'TryParseEmbeddedAction' 'Falta normalizador del formato de acción defectuoso.'
Require-Text 'GeoOfficeAI.Shared\PlanParser.cs' 'actions.Count\s*>\s*160' 'PlanParser no está sincronizado con el límite 160.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'StartCustomRecord\("Geo Office AI"\)' 'Word no inicia UndoRecord transaccional.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'TryRollback\(doc\)' 'Word no intenta rollback en fallo/cancelación.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' '_executionCursor' 'Word no mantiene cursor de ejecución entre acciones.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'PreflightPlan\(doc, plan\)' 'Word no hace preflight antes de abrir la transacción.'
Require-Text 'GeoOfficeAI.Excel\ExcelAutomationService.cs' 'copia de recuperación segura' 'Excel no exige copia de recuperación antes de modificar.'
Require-Text 'GeoOfficeAI.PowerPoint\PowerPointAutomationService.cs' 'BackupFormatForExtension' 'PowerPoint no preserva el formato de la copia de recuperación.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'Listo: los cambios se aplicaron correctamente' 'La UI no confirma éxito después de ApplyPlanAsync.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'ApartmentState\.STA' 'Word no protege el acceso COM con una guarda STA.'
Require-Text 'GeoOfficeAI.Excel\ExcelAutomationService.cs' 'ApartmentState\.STA' 'Excel no protege el acceso COM con una guarda STA.'
Require-Text 'GeoOfficeAI.PowerPoint\PowerPointAutomationService.cs' 'ApartmentState\.STA' 'PowerPoint no protege el acceso COM con una guarda STA.'
Require-Text 'GeoOfficeAI.Word\Properties\AssemblyInfo.cs' 'AssemblyVersion\("0\.9\.0\.0"\)' 'AssemblyVersion de Word no es 0.9.0.0.'
Require-Text 'GeoOfficeAI.Excel\Properties\AssemblyInfo.cs' 'AssemblyVersion\("0\.9\.0\.0"\)' 'AssemblyVersion de Excel no es 0.9.0.0.'
Require-Text 'GeoOfficeAI.PowerPoint\Properties\AssemblyInfo.cs' 'AssemblyVersion\("0\.9\.0\.0"\)' 'AssemblyVersion de PowerPoint no es 0.9.0.0.'

$iss = Get-Content (Join-Path $root 'installer\GeoOfficeAI.iss') -Raw
if ($iss -notmatch '#define MyAppVersion "0\.9"' -or $iss -notmatch 'OutputBaseFilename=GeoOfficeAI-Setup-v0\.9') { throw 'Versionado del instalador no es v0.9.' }
$wf = Get-Content (Join-Path $root '.github\workflows\build-windows.yml') -Raw
if ($wf -notmatch 'GeoOfficeAI-v0\.9-Windows' -or $wf -notmatch 'GeoOfficeAI-Setup-v0\.9\.exe') { throw 'Workflow aún apunta a un artefacto antiguo.' }

Write-Host 'Static QA v0.9: PASS' -ForegroundColor Green
