using GeoOfficeAI.Shared;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Word = Microsoft.Office.Interop.Word;

namespace GeoOfficeAI.WordAddIn
{
    public sealed class WordAutomationService : IOfficeHost
    {
        private readonly Word.Application _app;
        private string _lastTempFile;
        private int? _executionCursor;

        public WordAutomationService(Word.Application app) { _app = app; }
        public string HostName { get { return "Word"; } }
        public string HostLabel { get { return "Microsoft Word " + (_app.Version ?? "") + " · documento actual"; } }

        public string GetContext(int maxCharacters)
        {
            var sb = new StringBuilder();
            Word.Document doc = _app.ActiveDocument;
            if (doc == null) return "No hay documento abierto.";
            sb.AppendLine("Documento: " + (doc.Name ?? "Sin nombre"));
            try { sb.AppendLine("Páginas: " + doc.ComputeStatistics(Word.WdStatistic.wdStatisticPages) + " · Secciones: " + doc.Sections.Count + " · Tablas: " + doc.Tables.Count); } catch { }
            try
            {
                Word.Selection sel = _app.Selection;
                string selected = sel == null ? "" : (sel.Text ?? "").Trim();
                if (selected.Length > 0)
                {
                    sb.AppendLine("SELECCIÓN ACTUAL:");
                    sb.AppendLine(SafeHelpers.Truncate(selected, Math.Min(20000, maxCharacters / 2)));
                }
            }
            catch { }
            sb.AppendLine("CONTENIDO DEL DOCUMENTO:");
            string body = "";
            try { body = doc.Content.Text ?? ""; } catch { }
            sb.AppendLine(SafeHelpers.Truncate(body, Math.Max(1000, maxCharacters - sb.Length)));
            return SafeHelpers.Truncate(sb.ToString(), maxCharacters);
        }

        public string DescribePlan(OfficePlan plan)
        {
            var sb = new StringBuilder();
            if (plan == null || plan.actions == null) return "Sin cambios.";
            foreach (var a in plan.actions) sb.AppendLine("• " + (a == null ? "acción" : a.action));
            return sb.ToString();
        }

        public Task ApplyPlanAsync(OfficePlan plan, CancellationToken token)
        {
            PlanSafety.Validate("word", plan);
            if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA) throw new InvalidOperationException("Word debe modificarse desde un hilo STA de Office. La operación fue bloqueada para evitar errores COM.");
            if (plan == null || plan.actions == null || plan.actions.Count == 0) return Task.CompletedTask;

            Word.Document doc = _app.ActiveDocument;
            if (doc == null) throw new InvalidOperationException("No hay un documento de Word abierto.");
            if (doc.ProtectionType != Word.WdProtectionType.wdNoProtection)
                throw new InvalidOperationException("El documento está protegido. Quita la protección antes de pedir cambios a la IA.");
            try
            {
                dynamic ddoc = doc;
                if ((bool)ddoc.ReadOnly) throw new InvalidOperationException("El documento está abierto como solo lectura y no se puede modificar.");
            }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException) { }

            PreflightPlan(doc, plan);

            try
            {
                Word.Selection sel = _app.Selection;
                int initial = sel == null ? Math.Max(0, doc.Content.End - 1) : sel.Range.End;
                _executionCursor = Math.Max(0, Math.Min(Math.Max(0, doc.Content.End - 1), initial));
            }
            catch { _executionCursor = Math.Max(0, doc.Content.End - 1); }

            Word.UndoRecord undo;
            try
            {
                undo = _app.UndoRecord;
                undo.StartCustomRecord("Geo Office AI");
            }
            catch (Exception ex)
            {
                _executionCursor = null;
                throw new InvalidOperationException("Word no pudo iniciar una transacción segura de Deshacer. No se aplicó ningún cambio. " + ex.Message);
            }

            bool recordOpen = true;
            try
            {
                for (int i = 0; i < plan.actions.Count; i++)
                {
                    token.ThrowIfCancellationRequested();
                    OfficeAction action = plan.actions[i];
                    if (action == null) continue;
                    try { ApplyAction(doc, action); }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException("Falló la acción " + (i + 1) + " (" + action.action + "): " + ex.Message, ex);
                    }
                }
                token.ThrowIfCancellationRequested();
                undo.EndCustomRecord();
                recordOpen = false;
                return Task.CompletedTask;
            }
            catch (OperationCanceledException)
            {
                if (recordOpen) { try { undo.EndCustomRecord(); } catch { } recordOpen = false; }
                bool rolledBack = TryRollback(doc);
                if (!rolledBack)
                    throw new InvalidOperationException("La operación se canceló, pero Word no pudo revertir automáticamente todos los cambios. Usa Deshacer de Word antes de continuar.");
                throw;
            }
            catch (Exception ex)
            {
                if (recordOpen) { try { undo.EndCustomRecord(); } catch { } recordOpen = false; }
                bool rolledBack = TryRollback(doc);
                string suffix = rolledBack ? " Los cambios parciales fueron revertidos." : " Word no pudo confirmar la reversión automática; usa Deshacer de Word antes de continuar.";
                throw new InvalidOperationException(ex.Message + suffix, ex);
            }
            finally
            {
                if (recordOpen) { try { undo.EndCustomRecord(); } catch { } }
                _executionCursor = null;
            }
        }

        private static void PreflightPlan(Word.Document doc, OfficePlan plan)
        {
            if (plan == null || plan.actions == null) return;
            foreach (OfficeAction a in plan.actions)
            {
                if (a == null) continue;
                string action = (a.action ?? "").Trim().ToLowerInvariant();
                if (action == "replace_text" || action == "format_find")
                {
                    if (!DocumentContains(doc, a.findText, a.matchCase ?? false))
                        throw new InvalidOperationException("No se encontró el texto que debía " + (action == "replace_text" ? "reemplazarse" : "formatearse") + ": " + a.findText + ". No se aplicó ningún cambio.");
                }
                else if (action == "add_comment")
                {
                    Word.Selection sel = doc.Application.Selection;
                    if (sel == null) throw new InvalidOperationException("No hay una selección disponible para agregar el comentario. No se aplicó ningún cambio.");
                }
            }
        }

        private static bool DocumentContains(Word.Document doc, string text, bool matchCase)
        {
            if (string.IsNullOrWhiteSpace(text)) return false;
            Word.Range r = doc.Content.Duplicate;
            dynamic find = r.Find;
            find.ClearFormatting();
            return find.Execute(FindText: text, MatchCase: matchCase, Forward: true, Wrap: Word.WdFindWrap.wdFindStop);
        }

        private static bool TryRollback(Word.Document doc)
        {
            try
            {
                dynamic ddoc = doc;
                return (bool)ddoc.Undo(1);
            }
            catch { return false; }
        }

        private void ApplyAction(Word.Document doc, OfficeAction a)
        {
            string action = (a.action ?? "").Trim().ToLowerInvariant();
            switch (action)
            {
                case "replace_selection":
                    {
                        Word.Selection sel = _app.Selection;
                        if (sel == null) throw new InvalidOperationException("No hay una selección disponible en Word.");
                        int start = sel.Range.Start;
                        string replacement = a.text ?? "";
                        sel.Range.Text = replacement;
                        Word.Range inserted = doc.Range(start, start + replacement.Length);
                        if (HasFormatting(a)) ApplyFormat(inserted, a);
                        AdvanceCursor(doc, inserted.End);
                    }
                    break;
                case "insert_text":
                    InsertText(doc, a);
                    break;
                case "replace_text":
                    ReplaceText(doc, a);
                    break;
                case "format_selection":
                    ApplyFormat(_app.Selection.Range, a);
                    break;
                case "format_document":
                    ApplyFormat(doc.Content, a);
                    break;
                case "format_find":
                    FormatFind(doc, a);
                    break;
                case "add_heading":
                    AddHeading(doc, a);
                    break;
                case "add_list":
                    AddList(doc, a);
                    break;
                case "add_table":
                    AddTable(doc, a);
                    break;
                case "set_margins":
                    SetMargins(doc, a);
                    break;
                case "set_orientation":
                    SetOrientation(doc, a.orientation);
                    break;
                case "set_paper_size":
                    SetPaperSize(doc, a.paperSize);
                    break;
                case "set_header":
                    SetHeader(doc, a.headerText ?? a.text ?? "");
                    break;
                case "set_footer":
                    SetFooter(doc, a.footerText ?? a.text ?? "");
                    break;
                case "add_page_numbers":
                    AddPageNumbers(doc, a.pageNumberPosition);
                    break;
                case "page_break":
                    InsertPageBreak(doc, a.position);
                    break;
                case "add_comment":
                    AddComment(doc, a.commentText ?? a.text ?? "Comentario de Gemini");
                    break;
                case "track_changes":
                    {
                        bool expected = a.enabled ?? true;
                        doc.TrackRevisions = expected;
                        if (doc.TrackRevisions != expected) throw new InvalidOperationException("Word no confirmó el estado de Control de cambios.");
                    }
                    break;
                case "insert_picture":
                    InsertPicture(doc, a);
                    break;
                case "set_columns":
                    SetColumns(doc, a.columnsCount ?? 1);
                    break;
                case "add_toc":
                    AddTableOfContents(doc, a);
                    break;
                case "add_hyperlink":
                    AddHyperlink(doc, a);
                    break;
                case "insert_section_break":
                    InsertSectionBreak(doc, a);
                    break;
                default:
                    throw new InvalidOperationException("Acción de Word no permitida: " + a.action);
            }
        }

        private void InsertText(Word.Document doc, OfficeAction a)
        {
            string text = a.text ?? "";
            Word.Range r = GetInsertionRange(doc, a.position);
            int start = r.Start; int beforeEnd = r.End;
            r.InsertAfter(text);
            if (!string.IsNullOrEmpty(text) && r.End <= beforeEnd) throw new InvalidOperationException("Word no confirmó la inserción del texto.");
            Word.Range inserted = doc.Range(start, r.End);
            if (HasFormatting(a)) ApplyFormat(inserted, a);
            AdvanceCursor(doc, inserted.End);
        }

        private Word.Range GetInsertionRange(Word.Document doc, string position)
        {
            string p = (position ?? "cursor").ToLowerInvariant();
            if (p == "start" || p == "inicio") return doc.Range(0, 0);
            if (p == "end" || p == "final")
            {
                int end = Math.Max(0, doc.Content.End - 1);
                return doc.Range(end, end);
            }

            int cursor;
            if (_executionCursor.HasValue) cursor = _executionCursor.Value;
            else
            {
                try { cursor = _app.Selection.Range.End; }
                catch { cursor = Math.Max(0, doc.Content.End - 1); }
            }
            cursor = Math.Max(0, Math.Min(Math.Max(0, doc.Content.End - 1), cursor));
            return doc.Range(cursor, cursor);
        }

        private void AdvanceCursor(Word.Document doc, int position)
        {
            int max = Math.Max(0, doc.Content.End - 1);
            _executionCursor = Math.Max(0, Math.Min(max, position));
        }

        private static void ReplaceText(Word.Document doc, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("replace_text requiere findText.");
            Word.Range r = doc.Content.Duplicate;
            dynamic find = r.Find;
            find.ClearFormatting();
            find.Replacement.ClearFormatting();
            object replace = (a.replaceAll ?? false) ? Word.WdReplace.wdReplaceAll : Word.WdReplace.wdReplaceOne;
            bool found = find.Execute(FindText: a.findText, MatchCase: a.matchCase ?? false, ReplaceWith: a.replacementText ?? "", Replace: replace);
            if (!found) throw new InvalidOperationException("No se encontró el texto que debía reemplazarse: " + a.findText);
        }

        private static void FormatFind(Word.Document doc, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("format_find requiere findText.");
            Word.Range search = doc.Content.Duplicate;
            int applied = 0;
            while (applied < 100)
            {
                dynamic find = search.Find;
                find.ClearFormatting();
                bool found = find.Execute(FindText: a.findText, MatchCase: a.matchCase ?? false, Forward: true, Wrap: Word.WdFindWrap.wdFindStop);
                if (!found) break;
                ApplyFormat(search, a);
                applied++;
                int next = search.End;
                if (next >= doc.Content.End) break;
                search.SetRange(next, doc.Content.End);
                if (!(a.replaceAll ?? false)) break;
            }
            if (applied == 0) throw new InvalidOperationException("No se encontró el texto que debía formatearse: " + a.findText);
        }

        private static bool HasFormatting(OfficeAction a)
        {
            return a != null && (!string.IsNullOrWhiteSpace(a.fontName) || a.fontSize.HasValue || a.bold.HasValue || a.italic.HasValue || a.underline.HasValue ||
                !string.IsNullOrWhiteSpace(a.fontColorHex) || !string.IsNullOrWhiteSpace(a.alignment) || !string.IsNullOrWhiteSpace(a.styleName) ||
                a.spaceBeforePt.HasValue || a.spaceAfterPt.HasValue || !string.IsNullOrWhiteSpace(a.lineSpacing));
        }

        private static void ApplyFormat(Word.Range r, OfficeAction a)
        {
            if (r == null) return;
            if (!string.IsNullOrWhiteSpace(a.styleName)) ApplyStyle(r, a.styleName);
            if (!string.IsNullOrWhiteSpace(a.fontName)) r.Font.Name = a.fontName;
            if (a.fontSize.HasValue && a.fontSize.Value >= 6 && a.fontSize.Value <= 96) r.Font.Size = (float)a.fontSize.Value;
            if (a.bold.HasValue) r.Font.Bold = a.bold.Value ? 1 : 0;
            if (a.italic.HasValue) r.Font.Italic = a.italic.Value ? 1 : 0;
            if (a.underline.HasValue) r.Font.Underline = a.underline.Value ? Word.WdUnderline.wdUnderlineSingle : Word.WdUnderline.wdUnderlineNone;
            if (!string.IsNullOrWhiteSpace(a.fontColorHex)) r.Font.Color = (Word.WdColor)SafeHelpers.ParseRgb(a.fontColorHex, (int)Word.WdColor.wdColorAutomatic);
            if (!string.IsNullOrWhiteSpace(a.alignment))
            {
                string x = a.alignment.ToLowerInvariant();
                if (x == "center" || x == "centrado") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                else if (x == "right" || x == "derecha") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                else if (x == "justify" || x == "justificado") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                else if (x == "left" || x == "izquierda") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            }
            if (a.spaceBeforePt.HasValue) r.ParagraphFormat.SpaceBefore = (float)Math.Max(0, Math.Min(72, a.spaceBeforePt.Value));
            if (a.spaceAfterPt.HasValue) r.ParagraphFormat.SpaceAfter = (float)Math.Max(0, Math.Min(72, a.spaceAfterPt.Value));
            if (!string.IsNullOrWhiteSpace(a.lineSpacing))
            {
                string ls = a.lineSpacing.ToLowerInvariant();
                if (ls.Contains("1.5")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpace1pt5;
                else if (ls.Contains("double") || ls.Contains("doble")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceDouble;
                else if (ls.Contains("single") || ls.Contains("sencillo")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
            }
        }

        private static void ApplyStyle(Word.Range r, string styleName)
        {
            string x = (styleName ?? "").Trim().ToLowerInvariant();
            try
            {
                if (x == "normal") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleNormal; }
                else if (x == "title" || x == "título" || x == "titulo") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleTitle; }
                else if (x == "subtitle" || x == "subtítulo" || x == "subtitulo") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleSubtitle; }
                else if (x == "quote" || x == "cita") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleQuote; }
                else if (x == "heading 1" || x == "título 1" || x == "titulo 1") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleHeading1; }
                else if (x == "heading 2" || x == "título 2" || x == "titulo 2") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleHeading2; }
                else if (x == "heading 3" || x == "título 3" || x == "titulo 3") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleHeading3; }
                else { dynamic dr = r; dr.Style = styleName; }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Word no pudo aplicar el estilo '" + styleName + "'. Usa un estilo existente en el documento. " + ex.Message);
            }
        }

        private void AddHeading(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a.position);
            string text = (a.text ?? "").TrimEnd() + Environment.NewLine;
            r.InsertAfter(text);
            int start = Math.Max(0, r.End - text.Length);
            Word.Range inserted = doc.Range(start, r.End);
            int level = Math.Max(1, Math.Min(9, a.headingLevel ?? 1));
            try
            {
                Word.WdBuiltinStyle style;
                switch (level)
                {
                    case 1: style = Word.WdBuiltinStyle.wdStyleHeading1; break;
                    case 2: style = Word.WdBuiltinStyle.wdStyleHeading2; break;
                    case 3: style = Word.WdBuiltinStyle.wdStyleHeading3; break;
                    case 4: style = Word.WdBuiltinStyle.wdStyleHeading4; break;
                    case 5: style = Word.WdBuiltinStyle.wdStyleHeading5; break;
                    case 6: style = Word.WdBuiltinStyle.wdStyleHeading6; break;
                    case 7: style = Word.WdBuiltinStyle.wdStyleHeading7; break;
                    case 8: style = Word.WdBuiltinStyle.wdStyleHeading8; break;
                    default: style = Word.WdBuiltinStyle.wdStyleHeading9; break;
                }
                dynamic d = inserted;
                d.Style = style;
            }
            catch { inserted.Font.Bold = 1; inserted.Font.Size = level == 1 ? 18 : (level == 2 ? 15 : 12); }
            ApplyFormat(inserted, a);
            AdvanceCursor(doc, inserted.End);
        }

        private void AddList(Word.Document doc, OfficeAction a)
        {
            if (a.items == null || a.items.Count == 0) return;
            if (a.items.Count > 200) throw new InvalidOperationException("La lista supera el límite de 200 elementos.");
            Word.Range r = GetInsertionRange(doc, a.position);
            int start = r.Start;
            r.InsertAfter(string.Join(Environment.NewLine, a.items) + Environment.NewLine);
            Word.Range inserted = doc.Range(start, r.End);
            if (string.Equals(a.listType, "numbered", StringComparison.OrdinalIgnoreCase) || string.Equals(a.listType, "numerada", StringComparison.OrdinalIgnoreCase)) inserted.ListFormat.ApplyNumberDefault();
            else inserted.ListFormat.ApplyBulletDefault();
            if (HasFormatting(a)) ApplyFormat(inserted, a);
            AdvanceCursor(doc, inserted.End);
        }

        private void AddTable(Word.Document doc, OfficeAction a)
        {
            if (a.rows == null || a.rows.Count == 0) return;
            int rows = a.rows.Count; int cols = 0;
            foreach (var row in a.rows) if (row != null) cols = Math.Max(cols, row.Count);
            if (rows > 100 || cols > 30 || cols == 0) throw new InvalidOperationException("Tabla demasiado grande o inválida.");
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            int beforeCount = doc.Tables.Count;
            Word.Table table = doc.Tables.Add(r, rows, cols);
            if (doc.Tables.Count <= beforeCount) throw new InvalidOperationException("Word no confirmó la creación de la tabla.");
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    table.Cell(i + 1, j + 1).Range.Text = a.rows[i] != null && j < a.rows[i].Count ? (a.rows[i][j] ?? "") : "";
            try { table.Borders.Enable = 1; table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitContent); } catch { }
            if (HasFormatting(a)) ApplyFormat(table.Range, a);
            AdvanceCursor(doc, table.Range.End);
        }

        private static void SetMargins(Word.Document doc, OfficeAction a)
        {
            foreach (Word.Section s in doc.Sections)
            {
                if (a.marginTopCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginTopCm.Value); s.PageSetup.TopMargin = v; VerifyPoints(s.PageSetup.TopMargin, v, "margen superior"); }
                if (a.marginBottomCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginBottomCm.Value); s.PageSetup.BottomMargin = v; VerifyPoints(s.PageSetup.BottomMargin, v, "margen inferior"); }
                if (a.marginLeftCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginLeftCm.Value); s.PageSetup.LeftMargin = v; VerifyPoints(s.PageSetup.LeftMargin, v, "margen izquierdo"); }
                if (a.marginRightCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginRightCm.Value); s.PageSetup.RightMargin = v; VerifyPoints(s.PageSetup.RightMargin, v, "margen derecho"); }
            }
        }

        private static void VerifyPoints(float actual, float expected, string name)
        {
            if (Math.Abs(actual - expected) > 1.5f) throw new InvalidOperationException("Word no confirmó el " + name + ".");
        }

        private static void SetOrientation(Word.Document doc, string value)
        {
            bool landscape = string.Equals(value, "landscape", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "horizontal", StringComparison.OrdinalIgnoreCase);
            Word.WdOrientation expected = landscape ? Word.WdOrientation.wdOrientLandscape : Word.WdOrientation.wdOrientPortrait;
            foreach (Word.Section s in doc.Sections)
            {
                s.PageSetup.Orientation = expected;
                if (s.PageSetup.Orientation != expected) throw new InvalidOperationException("Word no confirmó la orientación de página.");
            }
        }

        private static void SetPaperSize(Word.Document doc, string value)
        {
            Word.WdPaperSize size = Word.WdPaperSize.wdPaperA4;
            string x = (value ?? "a4").ToLowerInvariant();
            if (x.Contains("letter") || x.Contains("carta")) size = Word.WdPaperSize.wdPaperLetter;
            else if (x.Contains("legal")) size = Word.WdPaperSize.wdPaperLegal;
            foreach (Word.Section s in doc.Sections)
            {
                s.PageSetup.PaperSize = size;
                if (s.PageSetup.PaperSize != size) throw new InvalidOperationException("Word no confirmó el tamaño de papel.");
            }
        }

        private static void AddPageNumbers(Word.Document doc, string position)
        {
            foreach (Word.Section s in doc.Sections)
            {
                Word.HeaderFooter footer = s.Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary];
                Word.WdPageNumberAlignment align = Word.WdPageNumberAlignment.wdAlignPageNumberCenter;
                string p = (position ?? "center").ToLowerInvariant();
                if (p.Contains("right") || p.Contains("derecha")) align = Word.WdPageNumberAlignment.wdAlignPageNumberRight;
                else if (p.Contains("left") || p.Contains("izquierda")) align = Word.WdPageNumberAlignment.wdAlignPageNumberLeft;
                if (footer.PageNumbers.Count == 0) footer.PageNumbers.Add(align, true);
                if (footer.PageNumbers.Count == 0) throw new InvalidOperationException("Word no confirmó la numeración de páginas.");
                try { footer.PageNumbers[1].Alignment = align; }
                catch { }
            }
        }


        private void InsertPicture(Word.Document doc, OfficeAction a)
        {
            PlanSafety.ValidatePicturePath(a.filePath);
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            int beforePictures = doc.InlineShapes.Count + doc.Shapes.Count;
            Word.InlineShape picture = doc.InlineShapes.AddPicture(a.filePath, false, true, r);
            if (doc.InlineShapes.Count + doc.Shapes.Count <= beforePictures) throw new InvalidOperationException("Word no confirmó la inserción de la imagen.");
            if (!string.IsNullOrWhiteSpace(a.altText))
            {
                try { picture.AlternativeText = a.altText; }
                catch (Exception ex) { throw new InvalidOperationException("Word insertó la imagen pero no pudo establecer el texto alternativo: " + ex.Message); }
            }
            if (a.widthCm.HasValue && a.widthCm.Value > 0 && a.widthCm.Value <= 50)
            {
                try { picture.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoTrue; } catch { }
                picture.Width = SafeHelpers.CmToPoints(a.widthCm.Value);
            }
            if (a.heightCm.HasValue && a.heightCm.Value > 0 && a.heightCm.Value <= 50 && !a.widthCm.HasValue)
            {
                try { picture.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoTrue; } catch { }
                picture.Height = SafeHelpers.CmToPoints(a.heightCm.Value);
            }
            string wrap = (a.target ?? "").ToLowerInvariant();
            if (!string.IsNullOrWhiteSpace(wrap) && !wrap.Contains("inline"))
            {
                try
                {
                    Word.Shape shape = picture.ConvertToShape();
                    if (wrap.Contains("square") || wrap.Contains("cuadr")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;
                    else if (wrap.Contains("tight") || wrap.Contains("estrech")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapTight;
                    else if (wrap.Contains("behind") || wrap.Contains("detrás") || wrap.Contains("detras")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapBehind;
                    else if (wrap.Contains("front") || wrap.Contains("delante")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapFront;
                    else throw new InvalidOperationException("Tipo de ajuste de imagen no reconocido: " + a.target);
                }
                catch (Exception ex) { throw new InvalidOperationException("Word insertó la imagen pero no pudo aplicar el ajuste solicitado: " + ex.Message); }
            }
            try { AdvanceCursor(doc, picture.Range.End); } catch { AdvanceCursor(doc, r.End); }
        }

        private static void SetColumns(Word.Document doc, int count)
        {
            count = Math.Max(1, Math.Min(4, count));
            foreach (Word.Section section in doc.Sections)
            {
                section.PageSetup.TextColumns.SetCount(count);
                if (section.PageSetup.TextColumns.Count != count) throw new InvalidOperationException("Word no confirmó el número de columnas.");
            }
        }

        private void AddTableOfContents(Word.Document doc, OfficeAction a)
        {
            int min = Math.Max(1, Math.Min(9, a.minLevel ?? 1));
            int max = Math.Max(min, Math.Min(9, a.maxLevel ?? 3));
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            try
            {
                int before = doc.TablesOfContents.Count;
                Word.TableOfContents toc = doc.TablesOfContents.Add(r, true, min, max);
                if (doc.TablesOfContents.Count <= before) throw new InvalidOperationException("Word no confirmó la tabla de contenido.");
                AdvanceCursor(doc, toc.Range.End);
            }
            catch (Exception ex) { throw new InvalidOperationException("No se pudo crear la tabla de contenido. Asegúrate de usar estilos Título 1/2/3. " + ex.Message); }
        }

        private void AddHyperlink(Word.Document doc, OfficeAction a)
        {
            PlanSafety.ValidateHttpUrl(a.url);
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            string label = string.IsNullOrWhiteSpace(a.text) ? a.url : a.text;
            int before = doc.Hyperlinks.Count;
            Word.Hyperlink link = doc.Hyperlinks.Add(r, a.url, Type.Missing, string.IsNullOrWhiteSpace(a.altText) ? Type.Missing : (object)a.altText, label, Type.Missing);
            if (doc.Hyperlinks.Count <= before) throw new InvalidOperationException("Word no confirmó la inserción del hipervínculo.");
            try { AdvanceCursor(doc, link.Range.End); } catch { AdvanceCursor(doc, r.End); }
        }

        private void InsertSectionBreak(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a.position);
            string kind = (a.breakType ?? "next_page").ToLowerInvariant();
            Word.WdBreakType type = (kind.Contains("continuous") || kind.Contains("continu")) ? Word.WdBreakType.wdSectionBreakContinuous : Word.WdBreakType.wdSectionBreakNextPage;
            int before = doc.Sections.Count;
            r.InsertBreak(type);
            if (doc.Sections.Count <= before) throw new InvalidOperationException("Word no confirmó el salto de sección.");
            AdvanceCursor(doc, r.End);
        }
        private static void SetHeader(Word.Document doc, string text)
        {
            foreach (Word.Section s in doc.Sections)
            {
                Word.Range r = s.Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                r.Text = text ?? "";
                string actual = (r.Text ?? "").TrimEnd('\r', '\a');
                if (!string.Equals(actual, (text ?? "").TrimEnd('\r'), StringComparison.Ordinal))
                    throw new InvalidOperationException("Word no confirmó el encabezado.");
            }
        }

        private static void SetFooter(Word.Document doc, string text)
        {
            foreach (Word.Section s in doc.Sections)
            {
                Word.Range r = s.Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                r.Text = text ?? "";
                string actual = (r.Text ?? "").TrimEnd('\r', '\a');
                if (!string.Equals(actual, (text ?? "").TrimEnd('\r'), StringComparison.Ordinal))
                    throw new InvalidOperationException("Word no confirmó el pie de página.");
            }
        }

        private void InsertPageBreak(Word.Document doc, string position)
        {
            Word.Range r = GetInsertionRange(doc, position);
            int beforePages = 0;
            try { beforePages = doc.ComputeStatistics(Word.WdStatistic.wdStatisticPages); } catch { }
            r.InsertBreak(Word.WdBreakType.wdPageBreak);
            AdvanceCursor(doc, r.End);
            if (beforePages > 0)
            {
                try
                {
                    int afterPages = doc.ComputeStatistics(Word.WdStatistic.wdStatisticPages);
                    if (afterPages < beforePages) throw new InvalidOperationException("Word no confirmó el salto de página.");
                }
                catch (InvalidOperationException) { throw; }
                catch { }
            }
        }

        private static void AddComment(Word.Document doc, string text)
        {
            Word.Selection sel = doc.Application.Selection;
            if (sel == null) throw new InvalidOperationException("No hay una selección disponible para agregar el comentario.");
            int before = doc.Comments.Count;
            doc.Comments.Add(sel.Range, text ?? "Comentario de Gemini");
            if (doc.Comments.Count <= before) throw new InvalidOperationException("Word no confirmó la creación del comentario.");
        }

        private static double Clamp(double v, double min, double max) { return Math.Max(min, Math.Min(max, v)); }

        public void UndoLast()
        {
            try
            {
                Word.Document doc = _app.ActiveDocument;
                if (doc == null) throw new InvalidOperationException("No hay documento abierto.");
                dynamic ddoc = doc;
                if (!(bool)ddoc.Undo(1)) throw new InvalidOperationException("Word no encontró un cambio para deshacer.");
            }
            catch (Exception ex) { throw new InvalidOperationException("Word no pudo deshacer automáticamente el último cambio de IA. " + ex.Message); }
        }

        public void WipeTemporaryData() { SafeHelpers.DeleteIfExists(_lastTempFile); _lastTempFile = null; }
    }
}
