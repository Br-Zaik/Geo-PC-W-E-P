## v0.9

- Auditoría de robustez del flujo Gemini → plan → validación → Office.
- Esquema JSON tipado y específico para Word/Excel/PowerPoint; `action` ahora es un enum de identificadores exactos y los parámetros viajan como propiedades separadas.
- Reparación automática de planes inválidos: hasta 3 intentos de planificación, con validación local antes de tocar Office.
- Normalizador seguro para el error observado `set_margins{...}` / `set_margins(...)` y otras acciones con parámetros primitivos embebidos.
- Validación semántica ampliada: parámetros obligatorios, límites, tablas/rangos, colores, márgenes, índices y valores admitidos.
- Reintentos REST con backoff para errores transitorios de Gemini (408/429/5xx y fallos temporales de red).
- Word: cursor de ejecución persistente dentro de una petición para mantener el orden real de inserción.
- Word: transacción `UndoRecord` obligatoria; ante fallo/cancelación se intenta rollback automático completo.
- Word: detección previa de documento protegido/solo lectura y verificaciones posteriores en márgenes, orientación, papel, tablas, hipervínculos, TOC, columnas y numeración.
- UI: el mensaje de Gemini y las fuentes no se muestran como éxito antes de que Office termine.
- Corregido límite inconsistente de acciones (parser 80 vs schema/safety 160).
- Corregido workflow de GitHub que todavía publicaba artefactos/rutas v0.5.
- Excel: libro solo lectura bloqueado; copia de recuperación `SaveCopyAs` obligatoria y verificada antes del primer cambio; errores por acción más claros.
- PowerPoint: presentación solo lectura bloqueada; copia de recuperación obligatoria preservando el formato/extensión; errores por acción más claros.
- Word/Excel/PowerPoint: guardas STA para impedir mutaciones COM desde un hilo inadecuado.
- QA estática ampliada y matriz de pruebas reales P0 añadida en `docs/PRUEBAS-v0.9.md`.
- Instalador actualizado a `GeoOfficeAI-Setup-v0.9.exe`.

## v0.8

- Corrige fallo intermitente de compilación VSTO en GitHub Actions: `Illegal operation attempted on a registry key that has been marked for deletion`.
- La solución VSTO ahora se compila en serie con MSBuild `/m:1` para evitar carreras entre Word, Excel y PowerPoint sobre el registro durante los targets de Office.
- Mantiene el modelo Gemini configurado en v0.7.
- Instalador actualizado a `GeoOfficeAI-Setup-v0.8.exe`.

# v0.5

- Investigación técnica enfocada en documentación oficial de Microsoft Office/VSTO y Google Gemini.
- Word: formato de documento completo, columnas, tabla de contenido, hipervínculos/fuentes, saltos de sección e imágenes con ajuste de texto/alt text.
- Excel: tablas profesionales con estilo, columnas calculadas autoexpandibles, formato condicional, validación, filtros, ordenamiento, tablas dinámicas, nombres definidos, fila de totales y modo de cálculo.
- PowerPoint: layouts, temas locales, transiciones, animaciones básicas, alineación/distribución, notas del presentador, espacios para imágenes y estilo profesional global.
- Planificador Gemini reforzado para componer múltiples acciones coordinadas en una sola petición profesional.
- Google Search grounding ampliado para peticiones con fuentes/citas/información reciente.
- Lista blanca ampliada y validaciones adicionales de URL, archivos de tema y fórmulas.
- Límite de acciones por plan ampliado de 80 a 160 para trabajos complejos, conservando presupuesto de texto y validación antes de tocar Office.
- Corregidos puntos de interoperabilidad en Excel/PowerPoint para reducir riesgo de compilación con Office Interop 15.0.

# v0.4

- Proyecto corregido a **Word + Excel + PowerPoint**, no solo Word.
- Eliminados OpenAI/Claude/Ollama y configuración multi-proveedor.
- Solo Gemini mediante OAuth de Google de escritorio.
- Panel lateral tipo chat en las tres aplicaciones.
- Botón único en Ribbon para reabrir el panel tras cerrar la X.
- Tokens OAuth solo en memoria; PKCE + state + loopback local.
- Limpieza/revocación de sesión, chat y temporales al cerrar panel/Office.
- Named pipe local restringido al usuario de Windows.
- Motor de acciones separado para Word, Excel y PowerPoint.
- Validación previa por lista blanca y límites de seguridad.
- Google Search grounding cuando el usuario pide explícitamente buscar/investigar en Internet.
- Sin generación de imágenes por API; crea prompts para Gemini web.
- Inserción de imágenes locales permitida y validada.
- 3 claves de instalación conservadas como hashes SHA-256.
- Workflow Windows/GitHub Actions + instalador Inno Setup.

## v0.6
- Corrige el inicio de sesión cuando VSTO carga el complemento desde su caché y `GeoOfficeAI.Broker.exe` no está junto a `GeoOfficeAI.Shared.dll`.
- Instala un broker compartido en `{app}\Broker` y guarda `InstallDir` en el registro.
- Añade búsqueda de respaldo en Program Files/Program Files (x86) y carpetas Word/Excel/PowerPoint.


## v0.7
- Cambiado el modelo de Gemini de `gemini-2.5-flash` a `gemini-3.6-flash`, modelo estable actual disponible para proyectos nuevos.
- Eliminados parámetros de muestreo `temperature` del planificador para evitar depender de parámetros deprecados en Gemini 3.6.
- Instalador actualizado a `GeoOfficeAI-Setup-v0.7.exe`.
