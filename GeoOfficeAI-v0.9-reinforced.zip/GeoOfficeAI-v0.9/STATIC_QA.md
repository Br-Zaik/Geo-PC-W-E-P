# Static QA — Geo Office AI v0.9

## Qué se verifica automáticamente

El script `qa-static.ps1`, ejecutado por GitHub Actions antes de compilar, comprueba regresiones estructurales de alto impacto:

- Cada acción permitida de Word, Excel y PowerPoint tiene un `case` ejecutor correspondiente.
- Gemini usa salida estructurada con schema y bloquea propiedades inesperadas.
- Existe reparación automática limitada del plan y el normalizador del patrón defectuoso `set_margins{...}`.
- `PlanParser` y seguridad usan el mismo límite de 160 acciones.
- Word exige `UndoRecord`, preflight, cursor secuencial y ruta de rollback.
- Word/Excel/PowerPoint contienen guardas STA para no mutar Office desde un hilo inadecuado.
- Excel exige una copia de recuperación antes de modificar.
- PowerPoint preserva el formato de la copia de recuperación.
- El panel solo confirma éxito después de `ApplyPlanAsync`.
- Los AssemblyVersion/FileVersion de los complementos son `0.9.0.0`.
- Instalador y artefacto de GitHub apuntan a v0.9.

## Qué NO demuestra QA estática

No demuestra que Word, Excel o PowerPoint hayan ejecutado realmente las acciones. Tampoco sustituye una compilación MSBuild/VSTO ni prueba Office x86/x64. El entorno en el que se preparó esta entrega es Linux y no tiene Microsoft Office.

El gate correcto es:

1. `qa-static.ps1` en Windows.
2. Compilación completa de `GeoOfficeAI.sln` con MSBuild/Visual Studio Office workload.
3. Creación del instalador Inno Setup.
4. Instalación en una máquina de prueba.
5. Matriz P0 real descrita en `docs/PRUEBAS-v0.9.md`.

## Resultado de la revisión de fuente

Antes de empaquetar esta versión se comprobó estáticamente que los delimitadores C# están balanceados, los XML del repositorio son parseables, las listas blancas coinciden con los handlers, y existen los mecanismos de schema/reparación/rollback/copia de recuperación/confirmación post-ejecución descritos arriba.
