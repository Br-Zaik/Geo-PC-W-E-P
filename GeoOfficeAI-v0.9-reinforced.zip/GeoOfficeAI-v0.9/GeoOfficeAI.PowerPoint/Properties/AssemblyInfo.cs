using System.Reflection; using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Geo Office AI - PowerPoint")][assembly: AssemblyDescription("Gemini integrado en Microsoft PowerPoint")][assembly: AssemblyCompany("Geo Office AI")][assembly: AssemblyProduct("Geo Office AI")][assembly: AssemblyVersion("0.9.0.0")][assembly: AssemblyFileVersion("0.9.0.0")][assembly: ComVisible(false)]
