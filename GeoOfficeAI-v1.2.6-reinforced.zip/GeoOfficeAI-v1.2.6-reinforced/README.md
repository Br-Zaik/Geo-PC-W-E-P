﻿# Geo Office AI v1.2.6 Copilot reforzado — Gemini para Word, Excel y PowerPoint
> **Parche 1.2.6:** Word usa un esquema tipado por acción para que operaciones como `set_margins` no puedan llegar sin sus parámetros obligatorios. Mantiene una llamada normal a Gemini, verificación local y fallback controlado por cuota.


> **Parche 1.2.4:** corrige el fallo detectado en Office real donde Gemini sí devolvía acciones (`insert_text`, `replace_selection`) pero Word veía `ActiveDocument = null` al ejecutar tras un `await`. Ahora todas las lecturas/escrituras COM se despachan al hilo UI/VSTO propietario, se fija el documento objetivo durante la petición, se bloquea el cambio de chat mientras trabaja y nunca se declara éxito si Office rechazó todos los lotes.
> **Parche 1.2.2:** corrigió `CS0229` en `Word.Application.NewDocument` mediante `ApplicationEvents4_Event`.
> **Parche 1.2.1:** corrigió `CS1545` de `Word.Table.Style` mediante el accessor COM `set_Style(ref object)`.

## Núcleo agente v1.2

- Gemini 3.8 Flash + Interactions API.
- Function Calling validado: Gemini ejecuta lotes pequeños, Office responde con resultado y el agente verifica/corrige antes de terminar.
- Google Search integrado cuando la orden pide investigación o datos actuales.
- Panel compacto de 350 px con prompt corto e historial por documento.
- Diagnóstico técnico local automático: registra versión de Office, etapa y errores/HRESULT sin guardar prompts, contenido del documento ni tokens; rota el archivo y elimina logs antiguos.
- Historial cifrado por archivo guardado: mismo archivo continúa; otro archivo usa chat separado; documentos descartados sin guardar no se recuperan.
- Cerrar Office conserva sesión e historial; cerrar la X del asistente borra conversaciones y revoca la sesión. La v1.2 difiere 1.2 s la decisión de cierre del panel para no confundir la X con el ocultamiento automático del task pane durante el cierre de Office.
- Refresh token cifrado con Windows DPAPI CurrentUser.
- Contexto estructurado de Word (selección, estilos, secciones, tablas, imágenes, comentarios, enlaces y más).
- Word avanzado: fuentes con enlaces, notas al pie, marcadores, cuadros de texto, ecuaciones y captions, además de las acciones anteriores.
- Si se pide generar una imagen sin ruta local, el asistente devuelve solo un prompt corto; no finge haber insertado una imagen.
- El planificador estructurado anterior queda como fallback si Interactions no está disponible.
- Orquestación reforzada para órdenes compuestas: el agente debe cumplir todos los requisitos de una sola petición antes de terminar.
- Auditoría final independiente: vuelve a leer el estado real de Office y corrige requisitos faltantes antes de mostrar “Listo”.
- Word distingue márgenes de página de márgenes internos de tabla/celdas, con control en centímetros.
- Word puede aplicar formato global por estilo (Título/Heading), estilizar tablas profesionales, crear espacios reales para imágenes y anclar inserciones antes/después de texto existente.
- El contexto de Word incluye formato de párrafos y señales de ortografía/gramática para una revisión más consistente.
- Interactions usa el endpoint estable `v1` y Function Calling en modo `validated`.


Complementos VSTO para **Microsoft Word, Excel y PowerPoint de escritorio en Windows**. El usuario trabaja en sus programas de Office normales; Geo Office AI agrega un panel lateral tipo chat conectado únicamente a **Gemini**.

## Refuerzo de fiabilidad v0.9

Esta versión prioriza que una orden termine realmente aplicada en Office antes de anunciar éxito. El planificador usa un esquema JSON tipado por aplicación, normaliza de forma segura errores simples como `set_margins{...}`, valida semánticamente el plan y pide a Gemini una reparación automática si el plan es inválido. Las llamadas REST reintentan errores transitorios con backoff limitado.

En Word, las acciones de una misma petición mantienen un cursor de ejecución que avanza entre títulos, párrafos, listas, tablas, enlaces e imágenes; esto evita que varias acciones con `position=cursor` se inserten en el mismo punto o queden en orden inverso. Los cambios se agrupan con `UndoRecord` y, si una acción o la cancelación falla a mitad, se intenta revertir el registro completo antes de informar el error. También se rechazan documentos protegidos/solo lectura antes de modificar.

El panel ya no muestra mensajes del modelo como “he creado…” antes de que Word/Excel/PowerPoint termine la ejecución. La confirmación se presenta solo después de que el host devuelve éxito.

## Experiencia de uso

1. Se instala una sola vez con la clave única autorizada.
2. Abres Word, Excel o PowerPoint.
3. Aparece **Asistente IA · Gemini** a la derecha.
4. Pulsas **Iniciar sesión con Google**. Se abre el navegador y autorizas la aplicación.
5. Escribes en lenguaje normal lo que quieres. Ejemplos:
   - Word: `Resume este texto, corrige la ortografía y pon los títulos centrados.`
   - Excel: `Calcula los promedios de esta tabla y crea un gráfico de columnas.`
   - PowerPoint: `Crea 5 diapositivas claras sobre seguridad minera.`
   - Web: `Busca en Internet los tipos de perforación minera y agrégalos aquí de forma breve.`
   - Imagen: `Dame un prompt profesional para generar una imagen sobre perforación diamantina en Gemini web.`
6. El motor principal trabaja como agente: Gemini solicita acciones seguras, Office las ejecuta realmente, devuelve el resultado y el contexto actualizado, y Gemini verifica/corrige antes de confirmar que terminó. Si Interactions no está disponible, entra el planificador estructurado de respaldo.

El chat no tiene botones separados para resumir, tabla, etc. Solo **Enviar, Cancelar y Deshacer IA**. Existe un único botón en la cinta de Office, **Abrir Asistente IA**, para volver a mostrar el panel si lo cerraste con la X.

## Solo Gemini

No incluye OpenAI, Claude, Anthropic, Ollama ni selector de proveedor. No guarda API keys porque el acceso está diseñado con **OAuth de Google** para una aplicación de escritorio.

> Importante: iniciar sesión con Google autoriza el uso de **Gemini API** asociado al proyecto OAuth de la aplicación. No convierte una suscripción Google AI Plus en crédito de API.

Modelo principal configurado: `gemini-3.8-flash` mediante Interactions API. El planificador estructurado de respaldo usa `gemini-3.7-flash` y, si fuera necesario, `gemini-3.6-flash`, para que el respaldo sea independiente del modelo principal. La búsqueda web se habilita solo cuando la instrucción requiere investigación, información actual o fuentes.

## Imágenes

La generación de imágenes dentro del complemento está desactivada para evitar el costo del modelo de imagen. Si el usuario pide **crear/generar una imagen**, Gemini prepara un prompt listo para pegar en Gemini web. El complemento sí puede **insertar una imagen local existente** en Word, Excel o PowerPoint cuando se indica una ruta válida.

## Capacidades principales

### Word
Texto, resumen, corrección y redacción; formato de selección/documento y formato global por estilos; títulos y subtítulos; listas; tablas profesionales; márgenes de página; márgenes internos de celdas; autofit y estilos de tabla; papel/orientación; columnas; secciones; encabezado/pie; números de página; tabla de contenido; hipervínculos y fuentes; comentarios; control de cambios; imágenes locales; espacios reservados para imágenes; notas al pie; marcadores; cuadros de texto; ecuaciones y captions.

### Excel
Celdas y rangos; fórmulas con filtros de seguridad; Tablas de Excel; columnas calculadas que se expanden con nuevas filas; formato y autofit; formato condicional; validación de datos; filtros y ordenamiento; gráficos; tablas dinámicas; nombres definidos; fila de totales; cálculo automático/manual; hojas nuevas/renombradas; combinar celdas; congelar fila superior; buscar/reemplazar; imágenes locales.

### PowerPoint
Crear/duplicar diapositivas; layouts; títulos y cuadros de texto; buscar/reemplazar; tablas; formas; fondos; temas locales; espacios reservados para imágenes; estilo profesional consistente; alineación/distribución; notas del presentador; transiciones discretas; animaciones básicas; imágenes locales.

## Seguridad implementada

- Una sola clave fija de instalación; en el script del instalador solo está su hash SHA-256. Las claves antiguas fueron eliminadas.
- Marcador de instalación autorizado para que los complementos no carguen si no pasaron por el instalador.
- OAuth con `state` aleatorio + PKCE y retorno únicamente por loopback `127.0.0.1`.
- El access token se mantiene en memoria. El refresh token se persiste cifrado con Windows DPAPI (`CurrentUser`) para poder continuar la sesión tras cerrar Office accidentalmente; no se crea un `token.json` en texto plano.
- Cerrar Word/Excel/PowerPoint conserva la sesión y el historial cifrado de archivos guardados. Cerrar intencionalmente la X del asistente cancela el trabajo, borra todos los historiales locales del asistente y revoca/elimina la sesión de Geo Office AI.
- El canal local entre Office y el broker usa named pipe restringido al usuario actual de Windows.
- Lista blanca de acciones; se bloquean macros, VBA, PowerShell, scripts, borrado de hojas/diapositivas/archivos y fórmulas de Excel consideradas peligrosas.
- Límites de tamaño para planes, tablas, rangos e imágenes locales.
- Word agrupa cambios con `UndoRecord`; Excel y PowerPoint exigen una copia de recuperación previa a los cambios. Esa copia protege el estado anterior, pero no equivale a rollback automático del documento activo.

### Lo que no puede garantizarse sin servidor

La clave única es una protección local sencilla, tal como se pidió. Un atacante con acceso administrativo y conocimientos de ingeniería inversa podría saltarse una validación puramente local. Para una licencia realmente revocable/multi-PC haría falta un servidor, que se dejó fuera de esta versión deliberadamente.

Tampoco se borran las cookies o el inicio de sesión global de **Chrome/Edge**: eso pertenece al navegador y borrarlo afectaría otras cuentas del usuario. Se borra y revoca la **sesión de Geo Office AI**.

## Requisito pendiente obligatorio para el inicio de sesión

Antes de poder producir un instalador funcional final, el desarrollador debe crear **una credencial OAuth 2.0 de tipo Desktop** en Google Cloud, habilitar Generative Language API y crear localmente `GeoOfficeAI.Broker/google_oauth.json` a partir de la plantilla incluida. Ese archivo real está excluido por `.gitignore`. Consulta `docs/OAUTH-GOOGLE.md`.

El repositorio contiene una plantilla, no credenciales reales. No es correcto inventar o compartir un Client ID de otra aplicación.

## Compilación

Requiere Windows + Visual Studio 2022 con herramientas de desarrollo de Office/VSTO + .NET Framework 4.8. Incluye `build.ps1` y workflow de GitHub Actions para compilar en `windows-2022` y generar el instalador con Inno Setup.

Esta entrega v1.2 fue revisada estáticamente en Linux, pero **no ha sido ejecutada dentro de Word/Excel/PowerPoint reales** en este entorno. La compilación y prueba en Windows es el siguiente gate antes de llamarla versión final de instalación.

Si una operación falla, el registro técnico queda en `%LOCALAPPDATA%\GeoOfficeAI\Logs` y puede compartirse para diagnosticar el fallo sin exponer el documento.

Consulta `docs/INVESTIGACION-Y-HOJA-DE-RUTA.md` para la especificación técnica, prioridades P0/P1/P2 y límites reales de compatibilidad.

## Diagnóstico v1.2.4

Si Gemini no puede iniciar una petición, el log `%LOCALAPPDATA%\GeoOfficeAI\Logs` incluye ahora `BrokerClient | AgentStart.Response | MESSAGE=...` con el error HTTP/OAuth/modelo sanitizado. En documentos nuevos sin guardar, el historial ya no debe desaparecer mientras el mismo documento siga abierto.
