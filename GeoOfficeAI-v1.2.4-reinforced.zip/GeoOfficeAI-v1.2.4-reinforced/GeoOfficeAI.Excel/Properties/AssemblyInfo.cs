﻿using System.Reflection; using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Geo Office AI - Excel")][assembly: AssemblyDescription("Gemini integrado en Microsoft Excel")][assembly: AssemblyCompany("Geo Office AI")][assembly: AssemblyProduct("Geo Office AI")][assembly: AssemblyVersion("1.2.4.0")][assembly: AssemblyFileVersion("1.2.4.0")][assembly: ComVisible(false)]
