﻿using GeoOfficeAI.Shared;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Office = Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;

namespace GeoOfficeAI.ExcelAddIn
{
    public sealed class ExcelAutomationService : IOfficeHost
    {
        private readonly Excel.Application _app;
        private string _lastBackup;

        public ExcelAutomationService(Excel.Application app) { _app = app; }
        public string HostName { get { return "Excel"; } }
        public string HostLabel { get { return "Microsoft Excel " + (_app.Version ?? "") + " · libro actual"; } }

        public string GetDocumentSessionId()
        {
            try { Excel.Workbook wb = _app.ActiveWorkbook; return wb == null ? "excel:none" : "excel:runtime:" + RuntimeHelpers.GetHashCode(wb).ToString(); }
            catch { return "excel:none"; }
        }

        public string GetPersistentDocumentKey()
        {
            try
            {
                Excel.Workbook wb = _app.ActiveWorkbook;
                if (wb == null || string.IsNullOrWhiteSpace(wb.Path)) return null;
                string full = wb.FullName;
                return !string.IsNullOrWhiteSpace(full) && File.Exists(full) ? "excel:" + Path.GetFullPath(full) : null;
            }
            catch { return null; }
        }

        public string GetDocumentDisplayName()
        {
            try { return _app.ActiveWorkbook == null ? "Sin libro" : (_app.ActiveWorkbook.Name ?? "Libro"); }
            catch { return "Libro"; }
        }

        public string GetContext(int maxCharacters)
        {
            Excel.Workbook wb = _app.ActiveWorkbook;
            if (wb == null) return "No hay libro abierto.";
            var sb = new StringBuilder();
            sb.AppendLine("Libro: " + wb.Name);
            sb.Append("Hojas: ");
            foreach (Excel.Worksheet s in wb.Worksheets) sb.Append(s.Name).Append("; ");
            sb.AppendLine();

            Excel.Worksheet ws = _app.ActiveSheet as Excel.Worksheet;
            if (ws == null) return SafeHelpers.Truncate(sb.ToString(), maxCharacters);
            sb.AppendLine("Hoja activa: " + ws.Name);
            try
            {
                if (ws.ListObjects.Count > 0)
                {
                    sb.Append("Tablas: ");
                    foreach (Excel.ListObject t in ws.ListObjects) sb.Append(t.Name).Append("[").Append(t.Range.get_Address(false, false, Excel.XlReferenceStyle.xlA1, Type.Missing, Type.Missing)).Append("]; ");
                    sb.AppendLine();
                }
            }
            catch { }

            Excel.Range selected = _app.Selection as Excel.Range;
            if (selected != null)
            {
                sb.AppendLine("SELECCIÓN ACTUAL " + selected.get_Address(false, false, Excel.XlReferenceStyle.xlA1, Type.Missing, Type.Missing) + ":");
                sb.AppendLine(RangeToText(selected, 40, 20));
            }

            try
            {
                Excel.Range used = ws.UsedRange;
                int rows = Math.Min(used.Rows.Count, 60);
                int cols = Math.Min(used.Columns.Count, 20);
                if (rows > 0 && cols > 0)
                {
                    Excel.Range first = (Excel.Range)used.Cells[1, 1];
                    Excel.Range sample = first.Resize[rows, cols];
                    sb.AppendLine("MUESTRA DE LA HOJA (máx. 60x20):");
                    sb.AppendLine(RangeToText(sample, rows, cols));
                }
            }
            catch { }
            return SafeHelpers.Truncate(sb.ToString(), maxCharacters);
        }

        private static string RangeToText(Excel.Range range, int maxRows, int maxCols)
        {
            var sb = new StringBuilder();
            int rows = Math.Min(range.Rows.Count, maxRows); int cols = Math.Min(range.Columns.Count, maxCols);
            for (int r = 1; r <= rows; r++)
            {
                for (int c = 1; c <= cols; c++)
                {
                    Excel.Range cell = range.Cells[r, c] as Excel.Range;
                    string v = "";
                    try
                    {
                        object f = cell.Formula;
                        object val = cell.Value2;
                        v = f is string && ((string)f).StartsWith("=") ? Convert.ToString(f) : Convert.ToString(val);
                    }
                    catch { }
                    if (c > 1) sb.Append("\t");
                    sb.Append((v ?? "").Replace("\r", " ").Replace("\n", " "));
                }
                sb.AppendLine();
            }
            return sb.ToString();
        }

        public string DescribePlan(OfficePlan plan)
        {
            var sb = new StringBuilder(); if (plan == null || plan.actions == null) return "Sin cambios.";
            foreach (var a in plan.actions) sb.AppendLine("• " + (a == null ? "acción" : a.action));
            return sb.ToString();
        }

        public Task ApplyPlanAsync(OfficePlan plan, CancellationToken token)
        {
            PlanSafety.Validate("excel", plan);
            if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA) throw new InvalidOperationException("Excel debe modificarse desde un hilo STA de Office. La operación fue bloqueada para evitar errores COM.");
            if (plan == null || plan.actions == null || plan.actions.Count == 0) return Task.CompletedTask;
            Excel.Workbook wb = _app.ActiveWorkbook;
            if (wb == null) throw new InvalidOperationException("No hay un libro de Excel abierto.");
            if (wb.ReadOnly) throw new InvalidOperationException("El libro está abierto como solo lectura y no se puede modificar.");
            CreateBackup(wb);
            try
            {
                for (int i = 0; i < plan.actions.Count; i++)
                {
                    token.ThrowIfCancellationRequested();
                    OfficeAction a = plan.actions[i];
                    if (a == null) continue;
                    try { ApplyAction(wb, a); }
                    catch (Exception ex) { throw new InvalidOperationException("Falló la acción " + (i + 1) + " (" + a.action + "): " + ex.Message, ex); }
                }
                return Task.CompletedTask;
            }
            catch (OperationCanceledException)
            {
                throw new InvalidOperationException("La operación de Excel fue cancelada. Se creó una copia de recuperación previa en: " + _lastBackup);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(ex.Message + " Se creó una copia de recuperación previa en: " + _lastBackup, ex);
            }
        }

        private void ApplyAction(Excel.Workbook wb, OfficeAction a)
        {
            string action = (a.action ?? "").ToLowerInvariant();
            switch (action)
            {
                case "set_cell":
                    SetCellValue(wb, a);
                    break;
                case "set_formula":
                    SetFormula(wb, a);
                    break;
                case "set_range_values":
                    SetRangeValues(wb, a);
                    break;
                case "format_range":
                    FormatRange(GetRange(wb, a), a);
                    break;
                case "autofit":
                    { var r = GetRange(wb, a, true); r.Columns.AutoFit(); r.Rows.AutoFit(); }
                    break;
                case "create_table":
                    CreateTable(wb, a);
                    break;
                case "create_chart":
                    CreateChart(wb, a);
                    break;
                case "add_sheet":
                    AddSheet(wb, a.name);
                    break;
                case "rename_sheet":
                    GetWorksheet(wb, a.sheet).Name = SafeSheetName(a.name);
                    break;
                case "merge_range":
                    GetRange(wb, a).Merge();
                    break;
                case "freeze_top_row":
                    if (_app.ActiveWindow != null) { _app.ActiveWindow.FreezePanes = false; _app.ActiveWindow.SplitRow = 1; _app.ActiveWindow.FreezePanes = true; }
                    break;
                case "replace_text":
                    ReplaceText(wb, a);
                    break;
                case "insert_picture":
                    InsertPicture(wb, a);
                    break;
                case "create_calculated_column":
                    CreateCalculatedColumn(wb, a);
                    break;
                case "conditional_format":
                    AddConditionalFormat(wb, a);
                    break;
                case "data_validation":
                    AddDataValidation(wb, a);
                    break;
                case "sort_range":
                    SortRange(wb, a);
                    break;
                case "filter_range":
                    FilterRange(wb, a);
                    break;
                case "create_pivot_table":
                    CreatePivotTable(wb, a);
                    break;
                case "define_name":
                    DefineName(wb, a);
                    break;
                case "set_calculation":
                    SetCalculation(a.target);
                    break;
                case "show_totals_row":
                    ShowTotalsRow(wb, a);
                    break;
                default:
                    throw new InvalidOperationException("Acción de Excel no permitida: " + a.action);
            }
        }

        private static void SetCellValue(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Range r = GetRangeStatic(wb, a.sheet, a.address);
            string expected = a.text ?? "";
            r.Value2 = expected;
            string actual = Convert.ToString(r.Value2) ?? "";
            if (!string.Equals(actual, expected, StringComparison.Ordinal))
                throw new InvalidOperationException("Excel no confirmó el valor escrito en " + a.address + ".");
        }

        private static void SetFormula(Excel.Workbook wb, OfficeAction a)
        {
            if (SafeHelpers.LooksLikeUnsafeExcelFormula(a.formula)) throw new InvalidOperationException("La fórmula fue bloqueada por seguridad.");
            Excel.Range r = GetRangeStatic(wb, a.sheet, a.address);
            string expected = a.formula ?? "";
            r.Formula = expected;
            string actual = Convert.ToString(r.Formula) ?? "";
            if (!string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Excel no confirmó la fórmula escrita en " + a.address + ".");
        }

        private static void SetRangeValues(Excel.Workbook wb, OfficeAction a)
        {
            if (a.rows == null || a.rows.Count == 0) return;
            int nr = a.rows.Count, nc = 0; foreach (var row in a.rows) if (row != null) nc = Math.Max(nc, row.Count);
            if (nr > 500 || nc > 100 || nc == 0) throw new InvalidOperationException("El bloque supera el límite de 500x100 celdas.");
            Excel.Range start = GetRangeStatic(wb, a.sheet, a.address);
            Excel.Range first = (Excel.Range)start.Cells[1, 1];
            Excel.Range target = first.Resize[nr, nc];
            object[,] values = new object[nr, nc];
            for (int r = 0; r < nr; r++) for (int c = 0; c < nc; c++) values[r, c] = a.rows[r] != null && c < a.rows[r].Count ? (object)(a.rows[r][c] ?? "") : "";
            target.Value2 = values;
        }

        private static void FormatRange(Excel.Range r, OfficeAction a)
        {
            if (!string.IsNullOrWhiteSpace(a.fontName)) r.Font.Name = a.fontName;
            if (a.fontSize.HasValue && a.fontSize.Value >= 6 && a.fontSize.Value <= 72) r.Font.Size = a.fontSize.Value;
            if (a.bold.HasValue) r.Font.Bold = a.bold.Value;
            if (a.italic.HasValue) r.Font.Italic = a.italic.Value;
            if (a.underline.HasValue) r.Font.Underline = a.underline.Value ? Excel.XlUnderlineStyle.xlUnderlineStyleSingle : Excel.XlUnderlineStyle.xlUnderlineStyleNone;
            if (!string.IsNullOrWhiteSpace(a.fontColorHex)) r.Font.Color = SafeHelpers.ParseRgb(a.fontColorHex, 0);
            if (!string.IsNullOrWhiteSpace(a.fillColorHex)) r.Interior.Color = SafeHelpers.ParseRgb(a.fillColorHex, 16777215);
            if (!string.IsNullOrWhiteSpace(a.numberFormat)) r.NumberFormat = a.numberFormat;
            string al = (a.alignment ?? "").ToLowerInvariant();
            if (al == "center" || al == "centrado") r.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            else if (al == "right" || al == "derecha") r.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
            else if (al == "left" || al == "izquierda") r.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
        }

        private static void CreateTable(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Worksheet ws = GetWorksheet(wb, a.sheet); Excel.Range r = ws.Range[a.address];
            if (Convert.ToDouble(r.CountLarge) > 50000) throw new InvalidOperationException("La tabla supera el límite de 50,000 celdas.");
            Excel.ListObject table = ws.ListObjects.Add(Excel.XlListObjectSourceType.xlSrcRange, r, Type.Missing, Excel.XlYesNoGuess.xlYes, Type.Missing);
            if (!string.IsNullOrWhiteSpace(a.name)) { try { table.Name = SafeObjectName(a.name, "TablaIA"); } catch { } }
            try { table.TableStyle = string.IsNullOrWhiteSpace(a.styleName) ? "TableStyleMedium2" : a.styleName; } catch { }
        }

        private static void CreateChart(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Worksheet ws = GetWorksheet(wb, a.sheet); string source = string.IsNullOrWhiteSpace(a.sourceRange) ? a.address : a.sourceRange;
            if (string.IsNullOrWhiteSpace(source)) throw new InvalidOperationException("create_chart requiere sourceRange.");
            Excel.Range r = ws.Range[source];
            Excel.ChartObjects objects = (Excel.ChartObjects)ws.ChartObjects(Type.Missing);
            Excel.ChartObject obj = objects.Add(60, 40, 420, 260);
            obj.Chart.SetSourceData(r, Type.Missing);
            obj.Chart.ChartType = MapChartType(a.chartType);
            if (!string.IsNullOrWhiteSpace(a.title)) { obj.Chart.HasTitle = true; obj.Chart.ChartTitle.Text = a.title; }
        }

        private static Excel.XlChartType MapChartType(string type)
        {
            string x = (type ?? "column").ToLowerInvariant();
            if (x.Contains("line") || x.Contains("línea") || x.Contains("linea")) return Excel.XlChartType.xlLine;
            if (x.Contains("pie") || x.Contains("circular")) return Excel.XlChartType.xlPie;
            if (x.Contains("bar") || x.Contains("barra")) return Excel.XlChartType.xlBarClustered;
            return Excel.XlChartType.xlColumnClustered;
        }

        private static void AddSheet(Excel.Workbook wb, string name)
        {
            Excel.Worksheet last = wb.Worksheets[wb.Worksheets.Count] as Excel.Worksheet;
            Excel.Worksheet ws = wb.Worksheets.Add(Type.Missing, last, 1, Type.Missing) as Excel.Worksheet;
            if (!string.IsNullOrWhiteSpace(name)) ws.Name = SafeSheetName(name);
        }

        private static void ReplaceText(Excel.Workbook wb, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("replace_text requiere findText.");
            bool changed = false; int sheets = 0;
            foreach (Excel.Worksheet ws in wb.Worksheets)
            {
                if (++sheets > 50) break;
                Excel.Range used = ws.UsedRange;
                if (a.replaceAll ?? false)
                {
                    bool local = used.Replace(What: a.findText, Replacement: a.replacementText ?? "", LookAt: Excel.XlLookAt.xlPart, SearchOrder: Excel.XlSearchOrder.xlByRows, MatchCase: a.matchCase ?? false);
                    changed = changed || local;
                }
                else
                {
                    Excel.Range found = used.Find(What: a.findText, After: Type.Missing, LookIn: Excel.XlFindLookIn.xlFormulas, LookAt: Excel.XlLookAt.xlPart, SearchOrder: Excel.XlSearchOrder.xlByRows, SearchDirection: Excel.XlSearchDirection.xlNext, MatchCase: a.matchCase ?? false, MatchByte: Type.Missing, SearchFormat: false);
                    if (found != null)
                    {
                        changed = found.Replace(What: a.findText, Replacement: a.replacementText ?? "", LookAt: Excel.XlLookAt.xlPart, SearchOrder: Excel.XlSearchOrder.xlByRows, MatchCase: a.matchCase ?? false);
                        if (changed) break;
                    }
                }
            }
            if (!changed) throw new InvalidOperationException("No se encontró el texto que debía reemplazarse: " + a.findText);
        }

        private Excel.Range GetRange(Excel.Workbook wb, OfficeAction a, bool allowUsed = false)
        {
            if (allowUsed && string.IsNullOrWhiteSpace(a.address)) return GetWorksheet(wb, a.sheet).UsedRange;
            return GetRangeStatic(wb, a.sheet, a.address);
        }

        private static Excel.Range GetRangeStatic(Excel.Workbook wb, string sheet, string address)
        {
            Excel.Worksheet ws = GetWorksheet(wb, sheet);
            if (string.IsNullOrWhiteSpace(address)) throw new InvalidOperationException("La acción de Excel requiere una dirección, por ejemplo A1 o A1:D10.");
            Excel.Range r = ws.Range[address];
            if (Convert.ToDouble(r.CountLarge) > 100000) throw new InvalidOperationException("El rango supera el límite de 100,000 celdas.");
            return r;
        }

        private static Excel.Worksheet GetWorksheet(Excel.Workbook wb, string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return wb.ActiveSheet as Excel.Worksheet;
            try { return wb.Worksheets[name] as Excel.Worksheet; }
            catch { throw new InvalidOperationException("No existe la hoja: " + name); }
        }

        private static string SafeSheetName(string name)
        {
            string s = string.IsNullOrWhiteSpace(name) ? "Hoja IA" : name.Trim();
            foreach (char c in new[] { ':', '\\', '/', '?', '*', '[', ']' }) s = s.Replace(c, '-');
            if (s.Length > 31) s = s.Substring(0, 31); return s;
        }
        private static string SafeObjectName(string name, string fallback)
        {
            string s = string.IsNullOrWhiteSpace(name) ? fallback : name.Trim().Replace(" ", "_");
            if (char.IsDigit(s[0])) s = "IA_" + s; return s.Length > 80 ? s.Substring(0, 80) : s;
        }



        private static Excel.ListObject GetTable(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Worksheet ws = GetWorksheet(wb, a.sheet);
            string wanted = string.IsNullOrWhiteSpace(a.tableName) ? a.name : a.tableName;
            if (!string.IsNullOrWhiteSpace(wanted))
            {
                try { return ws.ListObjects[wanted]; } catch { throw new InvalidOperationException("No existe la tabla de Excel: " + wanted); }
            }
            if (ws.ListObjects.Count == 1) return ws.ListObjects[1];
            if (ws.ListObjects.Count == 0) throw new InvalidOperationException("No hay ninguna tabla de Excel en la hoja. Crea primero una tabla.");
            throw new InvalidOperationException("Hay varias tablas. Indica tableName para elegir una.");
        }

        private static void CreateCalculatedColumn(Excel.Workbook wb, OfficeAction a)
        {
            if (SafeHelpers.LooksLikeUnsafeExcelFormula(a.formula)) throw new InvalidOperationException("La fórmula fue bloqueada por seguridad.");
            if (string.IsNullOrWhiteSpace(a.formula)) throw new InvalidOperationException("create_calculated_column requiere formula.");
            Excel.ListObject table = GetTable(wb, a);
            string columnName = string.IsNullOrWhiteSpace(a.columnName) ? (string.IsNullOrWhiteSpace(a.name) ? "Cálculo IA" : a.name) : a.columnName;
            Excel.ListColumn col = null;
            try { col = table.ListColumns[columnName]; } catch { }
            if (col == null) { col = table.ListColumns.Add(Type.Missing); col.Name = columnName; }
            Excel.Range body = col.DataBodyRange;
            if (body != null) body.Formula = a.formula;
            else
            {
                try { ((Excel.Range)table.Range.Cells[2, col.Index]).Formula = a.formula; } catch { }
            }
        }

        private static void AddConditionalFormat(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Range r = GetRangeStatic(wb, a.sheet, a.address);
            string kind = (a.target ?? "cell_value").ToLowerInvariant();
            if (kind.Contains("formula") || kind.Contains("expression") || kind.Contains("fórmula") || kind.Contains("formula"))
            {
                string f = string.IsNullOrWhiteSpace(a.formula) ? a.value1 : a.formula;
                if (string.IsNullOrWhiteSpace(f)) throw new InvalidOperationException("conditional_format por fórmula requiere formula/value1.");
                Excel.FormatCondition fc = (Excel.FormatCondition)r.FormatConditions.Add(Excel.XlFormatConditionType.xlExpression, Type.Missing, f, Type.Missing);
                ApplyConditionalStyle(fc, a);
            }
            else
            {
                Excel.XlFormatConditionOperator op = MapConditionOperator(a.operatorName);
                object v1 = string.IsNullOrWhiteSpace(a.value1) ? "0" : a.value1;
                object v2 = string.IsNullOrWhiteSpace(a.value2) ? Type.Missing : (object)a.value2;
                Excel.FormatCondition fc = (Excel.FormatCondition)r.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, op, v1, v2);
                ApplyConditionalStyle(fc, a);
            }
        }

        private static void ApplyConditionalStyle(Excel.FormatCondition fc, OfficeAction a)
        {
            try { if (!string.IsNullOrWhiteSpace(a.fillColorHex)) fc.Interior.Color = SafeHelpers.ParseRgb(a.fillColorHex, 0xFFF2CC); } catch { }
            try { if (!string.IsNullOrWhiteSpace(a.fontColorHex)) fc.Font.Color = SafeHelpers.ParseRgb(a.fontColorHex, 0); } catch { }
            try { if (a.bold.HasValue) fc.Font.Bold = a.bold.Value; } catch { }
        }

        private static Excel.XlFormatConditionOperator MapConditionOperator(string op)
        {
            string x = (op ?? "greater").ToLowerInvariant();
            if (x.Contains("less") || x.Contains("menor")) return x.Contains("equal") || x.Contains("igual") ? Excel.XlFormatConditionOperator.xlLessEqual : Excel.XlFormatConditionOperator.xlLess;
            if (x.Contains("equal") || x.Contains("igual")) return Excel.XlFormatConditionOperator.xlEqual;
            if (x.Contains("between") || x.Contains("entre")) return Excel.XlFormatConditionOperator.xlBetween;
            if (x.Contains("not") && (x.Contains("equal") || x.Contains("igual"))) return Excel.XlFormatConditionOperator.xlNotEqual;
            return x.Contains("equal") || x.Contains("igual") ? Excel.XlFormatConditionOperator.xlGreaterEqual : Excel.XlFormatConditionOperator.xlGreater;
        }

        private static void AddDataValidation(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Range r = GetRangeStatic(wb, a.sheet, a.address);
            try { r.Validation.Delete(); } catch { }
            string type = (a.target ?? "list").ToLowerInvariant();
            if (type.Contains("list") || type.Contains("lista"))
            {
                string list = a.items != null && a.items.Count > 0 ? string.Join(",", a.items.ToArray()) : a.value1;
                if (string.IsNullOrWhiteSpace(list)) throw new InvalidOperationException("data_validation tipo lista requiere items o value1.");
                r.Validation.Add(Excel.XlDVType.xlValidateList, Excel.XlDVAlertStyle.xlValidAlertStop, Excel.XlFormatConditionOperator.xlBetween, list, Type.Missing);
            }
            else
            {
                Excel.XlDVType dv = type.Contains("date") || type.Contains("fecha") ? Excel.XlDVType.xlValidateDate :
                    type.Contains("decimal") ? Excel.XlDVType.xlValidateDecimal :
                    type.Contains("text") || type.Contains("texto") ? Excel.XlDVType.xlValidateTextLength : Excel.XlDVType.xlValidateWholeNumber;
                object second = string.IsNullOrWhiteSpace(a.value2) ? Type.Missing : (object)a.value2;
                r.Validation.Add(dv, Excel.XlDVAlertStyle.xlValidAlertStop, MapConditionOperator(a.operatorName), a.value1 ?? "0", second);
            }
            try { r.Validation.IgnoreBlank = true; r.Validation.InCellDropdown = true; } catch { }
        }

        private static void SortRange(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Worksheet ws = GetWorksheet(wb, a.sheet);
            Excel.Range r = GetRangeStatic(wb, a.sheet, a.address);
            Excel.Range key = string.IsNullOrWhiteSpace(a.sortBy) ? (Excel.Range)r.Columns[1] : ws.Range[a.sortBy];
            Excel.Sort sort = ws.Sort;
            sort.SortFields.Clear();
            sort.SortFields.Add(key, Excel.XlSortOn.xlSortOnValues, (a.ascending ?? true) ? Excel.XlSortOrder.xlAscending : Excel.XlSortOrder.xlDescending, Type.Missing, Excel.XlSortDataOption.xlSortNormal);
            sort.SetRange(r); sort.Header = Excel.XlYesNoGuess.xlYes; sort.MatchCase = false; sort.Orientation = Excel.XlSortOrientation.xlSortColumns; sort.Apply();
        }

        private static void FilterRange(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Range r = GetRangeStatic(wb, a.sheet, a.address);
            int field = Math.Max(1, Math.Min(r.Columns.Count, a.fieldIndex ?? 1));
            if (string.IsNullOrWhiteSpace(a.criteria1)) r.AutoFilter(field, Type.Missing, Excel.XlAutoFilterOperator.xlAnd, Type.Missing, true);
            else r.AutoFilter(field, a.criteria1, Excel.XlAutoFilterOperator.xlAnd, Type.Missing, true);
        }

        private static void CreatePivotTable(Excel.Workbook wb, OfficeAction a)
        {
            Excel.Worksheet ws = GetWorksheet(wb, a.sheet);
            if (string.IsNullOrWhiteSpace(a.sourceRange)) throw new InvalidOperationException("create_pivot_table requiere sourceRange.");
            string dest = string.IsNullOrWhiteSpace(a.destination) ? (string.IsNullOrWhiteSpace(a.address) ? "A1" : a.address) : a.destination;
            Excel.Range source = ws.Range[a.sourceRange];
            Excel.Range destination = ws.Range[dest];
            Excel.PivotCache cache = wb.PivotCaches().Create(Excel.XlPivotTableSourceType.xlDatabase, source, Type.Missing);
            string name = SafeObjectName(a.name, "PivotIA");
            Excel.PivotTable pivot = cache.CreatePivotTable(destination, name, Type.Missing, Type.Missing);
            if (a.items != null)
            {
                int pos = 1;
                foreach (string field in a.items)
                {
                    if (string.IsNullOrWhiteSpace(field)) continue;
                    Excel.PivotField pf = pivot.PivotFields(field) as Excel.PivotField;
                    pf.Orientation = Excel.XlPivotFieldOrientation.xlRowField; pf.Position = pos++;
                }
            }
            if (!string.IsNullOrWhiteSpace(a.dataField))
            {
                Excel.PivotField data = pivot.PivotFields(a.dataField) as Excel.PivotField;
                pivot.AddDataField(data, a.dataField, MapSummaryFunction(a.summaryFunction));
            }
        }

        private static Excel.XlConsolidationFunction MapSummaryFunction(string value)
        {
            string x = (value ?? "sum").ToLowerInvariant();
            if (x.Contains("avg") || x.Contains("average") || x.Contains("promedio")) return Excel.XlConsolidationFunction.xlAverage;
            if (x.Contains("count") || x.Contains("conteo") || x.Contains("contar")) return Excel.XlConsolidationFunction.xlCount;
            if (x.Contains("max")) return Excel.XlConsolidationFunction.xlMax;
            if (x.Contains("min")) return Excel.XlConsolidationFunction.xlMin;
            return Excel.XlConsolidationFunction.xlSum;
        }

        private static void DefineName(Excel.Workbook wb, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.name)) throw new InvalidOperationException("define_name requiere name.");
            Excel.Range r = GetRangeStatic(wb, a.sheet, a.address);
            Excel.Worksheet ws = r.Worksheet as Excel.Worksheet;
            string sheetName = (ws == null ? "Sheet1" : ws.Name).Replace("'", "''");
            string address = r.Address[true, true, Excel.XlReferenceStyle.xlA1, false, Type.Missing];
            string refersTo = "='" + sheetName + "'!" + address;
            wb.Names.Add(SafeObjectName(a.name, "NombreIA"), refersTo, true, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        }

        private void SetCalculation(string value)
        {
            string x = (value ?? "automatic").ToLowerInvariant();
            _app.Calculation = (x.Contains("manual")) ? Excel.XlCalculation.xlCalculationManual : Excel.XlCalculation.xlCalculationAutomatic;
            if (_app.Calculation == Excel.XlCalculation.xlCalculationAutomatic) { try { _app.CalculateFull(); } catch { } }
        }

        private static void ShowTotalsRow(Excel.Workbook wb, OfficeAction a)
        {
            Excel.ListObject table = GetTable(wb, a);
            table.ShowTotals = a.enabled ?? true;
            if (table.ShowTotals && !string.IsNullOrWhiteSpace(a.dataField))
            {
                Excel.ListColumn col = table.ListColumns[a.dataField];
                string x = (a.summaryFunction ?? "sum").ToLowerInvariant();
                col.TotalsCalculation = x.Contains("avg") || x.Contains("promedio") ? Excel.XlTotalsCalculation.xlTotalsCalculationAverage :
                    x.Contains("count") || x.Contains("contar") ? Excel.XlTotalsCalculation.xlTotalsCalculationCount :
                    x.Contains("max") ? Excel.XlTotalsCalculation.xlTotalsCalculationMax :
                    x.Contains("min") ? Excel.XlTotalsCalculation.xlTotalsCalculationMin : Excel.XlTotalsCalculation.xlTotalsCalculationSum;
            }
        }

        private static void InsertPicture(Excel.Workbook wb, OfficeAction a)
        {
            PlanSafety.ValidatePicturePath(a.filePath);
            Excel.Worksheet ws = GetWorksheet(wb, a.sheet);
            Excel.Range anchor = string.IsNullOrWhiteSpace(a.address) ? (ws.Application.ActiveCell as Excel.Range) : ws.Range[a.address];
            if (anchor == null) anchor = ws.Range["A1"];
            float left = Convert.ToSingle(anchor.Left);
            float top = Convert.ToSingle(anchor.Top);
            float width = a.widthCm.HasValue ? SafeHelpers.CmToPoints(Math.Max(0.5, Math.Min(50, a.widthCm.Value))) : 240f;
            float height = a.heightCm.HasValue ? SafeHelpers.CmToPoints(Math.Max(0.5, Math.Min(50, a.heightCm.Value))) : 160f;
            ws.Shapes.AddPicture(a.filePath, Office.MsoTriState.msoFalse, Office.MsoTriState.msoTrue, left, top, width, height);
        }
        private void CreateBackup(Excel.Workbook wb)
        {
            try
            {
                SafeHelpers.DeleteIfExists(_lastBackup);
                string ext = Path.GetExtension(wb.Name); if (string.IsNullOrWhiteSpace(ext)) ext = ".xlsx";
                _lastBackup = Path.Combine(Path.GetTempPath(), "GeoOfficeAI_Excel_" + Guid.NewGuid().ToString("N") + ext);
                wb.SaveCopyAs(_lastBackup);
                if (!File.Exists(_lastBackup) || new FileInfo(_lastBackup).Length == 0) throw new IOException("Excel no confirmó la copia de recuperación.");
            }
            catch (Exception ex)
            {
                _lastBackup = null;
                throw new InvalidOperationException("No se aplicó ningún cambio porque Excel no pudo crear primero una copia de recuperación segura. " + ex.Message, ex);
            }
        }

        public void UndoLast()
        {
            try { _app.Undo(); return; }
            catch { }
            if (!string.IsNullOrWhiteSpace(_lastBackup) && File.Exists(_lastBackup))
                throw new InvalidOperationException("Excel no permitió deshacer automáticamente. Se conserva temporalmente una copia previa mientras esta sesión esté abierta.");
            throw new InvalidOperationException("Excel no pudo deshacer el último cambio.");
        }

        public void WipeTemporaryData() { SafeHelpers.DeleteIfExists(_lastBackup); _lastBackup = null; }
    }
}
