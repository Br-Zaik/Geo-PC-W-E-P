﻿using System;
using System.Runtime.InteropServices;
using Office = Microsoft.Office.Core;

namespace GeoOfficeAI.WordAddIn
{
    [ComVisible(true)]
    public sealed class OfficeRibbon : Office.IRibbonExtensibility
    {
        public string GetCustomUI(string ribbonID)
        {
            return @"<customUI xmlns='http://schemas.microsoft.com/office/2009/07/customui'>
  <ribbon><tabs><tab id='GeoOfficeAITab' label='Asistente IA'>
    <group id='GeoOfficeAIGroup' label='Asistente IA'>
      <button id='GeoOfficeAIShow' label='Abrir Asistente IA' size='large' onAction='OnShow' screentip='Gemini para Word' supertip='Abre el chat lateral de Gemini.'/>
    </group>
  </tab></tabs></ribbon>
</customUI>";
        }

        public void OnShow(Office.IRibbonControl control)
        {
            try { Globals.ThisAddIn.ShowAssistantPane(); } catch { }
        }
    }
}
