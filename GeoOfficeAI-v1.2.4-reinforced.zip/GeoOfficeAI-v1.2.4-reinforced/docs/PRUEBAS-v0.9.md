﻿# Matriz de pruebas reales — Geo Office AI v0.9

Registrar para cada caso: versión de Windows, versión exacta de Office, x86/x64, resultado, captura/log y si Deshacer/recuperación funcionó.

## Word — gate P0

| # | Prueba | Resultado esperado |
|---|---|---|
| W01 | Documento vacío; informe 1 página con título, texto, tabla y márgenes | Contenido aparece en orden; no queda hoja blanca; éxito solo al terminar |
| W02 | Plan con `set_margins{...}` simulado | Se normaliza/repara antes de Office o se rechaza sin tocar el documento |
| W03 | 20 acciones con `position=cursor` | Orden visual idéntico al plan; sin texto invertido/solapado |
| W04 | Documento con texto, imagen y tabla; modificar solo selección | Elementos no solicitados permanecen intactos |
| W05 | Buscar/reemplazar objetivo inexistente | Preflight falla antes de cambiar otras partes |
| W06 | Acción intermedia forzada a fallar | Se intenta rollback del UndoRecord y se informa claramente |
| W07 | Cancelar durante ejecución | No se anuncia éxito; se intenta rollback |
| W08 | Documento protegido | No modifica |
| W09 | Documento solo lectura | No modifica |
| W10 | Márgenes/orientación/papel/columnas | Valores finales coinciden con lo pedido dentro de tolerancia |
| W11 | Encabezado/pie/número de página | Objetos realmente existen después de aplicar |
| W12 | TOC + hipervínculos/fuentes | Objetos insertados y orden correcto |
| W13 | Imagen local válida e inválida | Válida se inserta; inválida falla sin éxito falso |

## Gemini/red — gate P0

| # | Prueba | Resultado esperado |
|---|---|---|
| G01 | JSON correcto | Se aplica una sola vez |
| G02 | JSON inválido reparable | Hasta 3 intentos de plan; Office se toca solo tras validar |
| G03 | Acción desconocida | Bloqueada; nunca normalizada a una acción permitida |
| G04 | HTTP 429 | Backoff limitado; no bucle infinito |
| G05 | HTTP 503 / timeout temporal | Reintento limitado con jitter |
| G06 | 400/403 | Sin reintentos inútiles; error claro |
| G07 | Internet cortado | Documento no cambia si no existe plan válido |

## Excel — gate P0

| # | Prueba | Resultado esperado |
|---|---|---|
| E01 | Celdas, fórmulas, tabla y gráfico | Cambios reales y verificables |
| E02 | Libro solo lectura | No modifica |
| E03 | Forzar fallo intermedio | Existe copia de recuperación previa y se informa su ruta |
| E04 | Fórmula insegura | Bloqueada antes de escribirla |
| E05 | Buscar/reemplazar inexistente | Error explícito, no éxito falso |

## PowerPoint — gate P0

| # | Prueba | Resultado esperado |
|---|---|---|
| P01 | Crear 5 diapositivas con texto/tabla/forma/notas | Objetos realmente creados |
| P02 | Presentación solo lectura | No modifica |
| P03 | Forzar fallo intermedio | Existe copia previa en el formato correspondiente |
| P04 | Layout/transición/alineación | Operación aplicada o error explícito; no `catch` silencioso de éxito |

## Compatibilidad mínima antes de distribuir

Probar como mínimo Microsoft 365 x64 y una versión perpetua x64. Si se anuncia soporte de Office 2010/2013 o x86, esos entornos deben ejecutar el gate Word/Excel/PowerPoint correspondiente antes de publicarlo como compatible.
