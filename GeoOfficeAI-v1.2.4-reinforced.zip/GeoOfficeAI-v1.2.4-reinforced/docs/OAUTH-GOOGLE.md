﻿# Configuración única de Google OAuth

Geo Office AI usa inicio de sesión de Google mediante OAuth; no pide una API key al usuario final.

## Una sola vez como desarrollador

1. Crear/usar un proyecto en Google Cloud.
2. Habilitar **Generative Language API**.
3. En Google Auth Platform, configurar la pantalla de consentimiento.
4. Mientras esté en modo de pruebas, agregar como usuarios de prueba las cuentas Google que podrán iniciar sesión.
5. Crear un cliente OAuth 2.0 con tipo **Desktop app**.
6. Descargar el JSON del cliente y copiar `GeoOfficeAI.Broker/google_oauth.template.json` como `GeoOfficeAI.Broker/google_oauth.json` y completar ese archivo local. `google_oauth.json` está en `.gitignore`.

La aplicación abre el navegador, usa PKCE y recibe el código en un puerto aleatorio de `127.0.0.1`. Los tokens resultantes se mantienen solo en memoria y se borran/revocan al cerrar el panel/Office.

## GitHub Actions

Para no subir el JSON al repositorio, convertirlo a Base64 y guardarlo como secreto de GitHub:

`GOOGLE_OAUTH_JSON_B64`

El workflow lo reconstruye únicamente durante la compilación.

## Nota sobre Google AI Plus

OAuth autentica al usuario para Gemini API. La cuota/facturación corresponde al proyecto de Gemini API, no a la cuota de la app/web Gemini de una suscripción personal Google AI Plus.
