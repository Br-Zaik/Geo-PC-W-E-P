﻿# Matriz de pruebas reales — Geo Office AI v1.1

Estas pruebas deben ejecutarse después de compilar e instalar en Windows con Microsoft Office real.

## P0 — Word agentic

1. **Orden compuesta sobre documento existente**
   - Petición: `Corrige la ortografía. Pon todos los títulos a 12 centrados, subtítulos a 11, subraya palabras clave y deja el documento bien presentado.`
   - Esperado: se cumplen todas las condiciones, no solo la primera. El asistente realiza auditoría final antes de decir Listo.

2. **Documento vacío**
   - Petición: `Haz un informe de una página sobre seguridad minera, con título, subtítulos, conclusión y palabras clave subrayadas.`
   - Esperado: Word deja de estar vacío y el contenido queda estructurado/formateado.

3. **Investigación + tabla + márgenes de página**
   - Petición: `Busca en Internet los principales riesgos de minería, crea un cuadro de 4 columnas y pon márgenes de la hoja de 0.7 cm en todos los lados.`
   - Esperado: contenido investigado, tabla real y PageSetup = 0.7 cm; no confundir con padding de celdas. Incluir fuentes.

4. **Márgenes internos de tabla**
   - Petición sobre una tabla: `Deja 0.7 cm de margen interno en todos los lados de las celdas, encabezado en negrita y estilo profesional.`
   - Esperado: Top/Bottom/Left/RightPadding ≈ 0.7 cm; no modifica los márgenes de la página.

5. **Estilos globales**
   - Documento con estilos Title/Heading 1/Heading 2.
   - Petición: `Título principal a 12 centrado; todos los subtítulos Heading 2 a 11.`
   - Esperado: todas las coincidencias reciben el formato solicitado.

6. **Encabezados sin estilos Word**
   - Documento con encabezados escritos manualmente, sin Heading.
   - Petición equivalente a la prueba 5.
   - Esperado: el agente usa el contexto para identificar encabezados y aplicar formato por coincidencia exacta sin modificar párrafos normales.

7. **Espacios para imágenes**
   - Petición: `Deja dos espacios de 12 x 5 cm para imágenes, uno después del segundo subtítulo y otro antes de la conclusión.`
   - Esperado: crea placeholders visibles en flujo del documento y no llama a un modelo de imagen de pago.

8. **Generación de imagen sin API de pago**
   - Petición: `Créame una imagen de una perforadora minera moderna.`
   - Esperado: devuelve solamente un prompt corto y útil; no afirma que insertó una imagen.

9. **Corrección ortográfica conservadora**
   - Documento con faltas intencionales y nombres técnicos.
   - Petición: `Corrige ortografía sin cambiar términos técnicos correctos.`
   - Esperado: corrige errores evidentes y conserva términos técnicos dudosos cuando no hay seguridad suficiente.

10. **Fallo a mitad**
    - Forzar una acción inválida o un documento protegido.
    - Esperado: no afirma éxito; Word intenta rollback del lote; el agente recibe el error y corrige o se detiene de forma clara.

## P0 — sesión e historial

11. Guardar un Word, conversar, cerrar Word y abrir el mismo archivo: debe recuperar su historial y sesión.
12. Abrir otro Word guardado: debe mostrar chat independiente/limpio.
13. Crear documento nuevo, conversar, cerrar y elegir **No guardar**: no debe existir historial recuperable de ese documento.
14. Cerrar la X del asistente: debe borrar historiales locales y revocar/eliminar la sesión de Geo Office AI.

## P1 — regresión Excel/PowerPoint

15. Excel: tabla + fórmula + gráfico, verificando copia de recuperación previa.
16. PowerPoint: crear varias diapositivas, texto y elementos visuales, verificando copia de recuperación previa.
