﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (!(Test-Path "$root\GeoOfficeAI.Broker\google_oauth.json")) { throw 'Falta GeoOfficeAI.Broker\google_oauth.json real. Consulta docs/OAUTH-GOOGLE.md.' }
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (!(Test-Path $vswhere)) { throw 'Visual Studio/VSWhere no encontrado.' }
$msbuild = & $vswhere -latest -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe | Select-Object -First 1
if (!$msbuild) { throw 'MSBuild no encontrado.' }

# Compila solución VSTO/Framework.
& $msbuild "$root\GeoOfficeAI.sln" /m:1 /t:Rebuild /p:Configuration=Release /p:Platform="Any CPU" /p:VisualStudioVersion=17.0
if ($LASTEXITCODE -ne 0) { throw "MSBuild falló: $LASTEXITCODE" }

# Preparar paquete. El flujo de GitHub reemplaza google_oauth.json con un secreto real antes de este paso.
$stage = "$root\dist\package"
Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force "$stage\Word", "$stage\Excel", "$stage\PowerPoint", "$stage\Broker" | Out-Null

$broker = "$root\GeoOfficeAI.Broker\bin\Release"
$shared = "$root\GeoOfficeAI.Shared\bin\Release\GeoOfficeAI.Shared.dll"
# Broker compartido: ubicación estable que no depende de la caché VSTO.
Copy-Item "$broker\GeoOfficeAI.Broker.exe" "$stage\Broker" -Force
Copy-Item "$broker\GeoOfficeAI.Broker.exe.config" "$stage\Broker" -Force -ErrorAction SilentlyContinue
Copy-Item "$broker\google_oauth.json" "$stage\Broker" -Force
Copy-Item $shared "$stage\Broker" -Force
$hosts = @{
  Word = "$root\GeoOfficeAI.Word\bin\Release";
  Excel = "$root\GeoOfficeAI.Excel\bin\Release";
  PowerPoint = "$root\GeoOfficeAI.PowerPoint\bin\Release"
}
foreach ($name in $hosts.Keys) {
  Copy-Item "$($hosts[$name])\*" "$stage\$name" -Recurse -Force
  Copy-Item "$broker\GeoOfficeAI.Broker.exe" "$stage\$name" -Force
  Copy-Item "$broker\GeoOfficeAI.Broker.exe.config" "$stage\$name" -Force -ErrorAction SilentlyContinue
  Copy-Item "$broker\google_oauth.json" "$stage\$name" -Force
  Copy-Item $shared "$stage\$name" -Force
}
Write-Host "Stage listo: $stage"
