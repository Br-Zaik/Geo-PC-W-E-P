﻿using System;
using System.Threading;

namespace GeoOfficeAI.Broker
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            bool created;
            using (var mutex = new Mutex(true, @"Local\GeoOfficeAI.Broker.v1", out created))
            {
                if (!created) return;
                try
                {
                    var server = new BrokerServer();
                    server.Run();
                }
                catch { }
            }
        }
    }
}
