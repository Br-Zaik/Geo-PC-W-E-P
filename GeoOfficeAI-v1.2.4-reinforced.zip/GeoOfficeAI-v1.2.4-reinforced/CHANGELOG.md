﻿## v1.2.4 — ejecución COM en hilo correcto y fin de falsos “Listo”

- Corregido fallo real visto en Word: Gemini entregaba `insert_text`, pero `WordAutomationService` recibía `ActiveDocument = null` después de la espera de red.
- Todas las operaciones del host Office posteriores a `await` se vuelven a ejecutar en el hilo UI/VSTO dueño del complemento mediante `RunOnOfficeUiAsync`.
- La petición fija el identificador del documento al empezar y se detiene si el usuario cambia a otro archivo mientras Gemini trabaja, evitando editar el documento equivocado.
- El temporizador de cambio de documento no puede cambiar/vaciar la conversación mientras existe una petición activa.
- Word usa el HWND de su ventana como identidad de sesión para documentos no guardados, con fallback por nombre, evitando cambios espurios de RCW COM.
- Si todos los lotes fueron rechazados, el asistente ya no acepta un `completed` de Gemini como éxito: muestra un error real y conserva diagnóstico.
- Añadido log `Conversation.Bind` para detectar cambios inesperados de documento/chat.
- Se mantienen las correcciones 1.2.3 de cuota/diagnóstico y los fallbacks de Gemini.

## v1.2.2 — corrección de compilación de eventos Word

- Corrige GitHub Actions #18 / `CS0229` en `ThisAddIn.cs`: `Application.NewDocument` era ambiguo entre el miembro COM y `ApplicationEvents4_Event.NewDocument`.
- Word ahora mantiene una referencia explícita `ApplicationEvents4_Event` para sus eventos y desuscribe los handlers al cerrar.
- QA estática nueva que bloquea la forma ambigua `this.Application.NewDocument += ...`.
- Workflow conserva `actions/checkout@v5` para evitar la advertencia de Node 20.
- Versionado de binarios, artefacto e instalador actualizado a 1.2.2.

## v1.2.1 — corrección de compilación Word

- Corregido `CS1545` de `Word.Table.Style` observado en GitHub Actions #16. Los estilos de tabla ahora usan el accessor COM compatible `Table.set_Style(ref object)` en lugar de asignar la propiedad directamente.
- Añadida regresión en `qa-static.ps1` para impedir que vuelva a introducirse `table.Style = ...`.
- `actions/checkout` actualizado a v5 para eliminar la advertencia de Node.js 20 del workflow.
- Versionado de binarios e instalador actualizado a 1.2.1.

## v1.2 Copilot reforzado

- Instalador reducido a una sola clave autorizada; se eliminaron las dos claves antiguas y solo se conserva el hash SHA-256 de la clave solicitada.
- Separación X del asistente / cierre de Office reforzada: el ocultamiento del task pane se evalúa con una pequeña demora para evitar borrar sesión e historial durante el cierre normal de Word/Excel/PowerPoint.
- Cerrar Office conserva login e historial cifrado de archivos guardados; la X del asistente sigue revocando sesión y borrando conversaciones.
- Nuevo `DiagnosticLogger` local: registra aplicación/versión de Office, documento visible, etapa, HRESULT, mensaje y stack técnico; no registra prompts, texto del documento ni tokens.
- Rotación de logs a 2 MB y limpieza automática de registros mayores de 14 días.
- El flujo agentic registra lotes aplicados/fallidos y deja diagnóstico si Office rechaza una acción, facilitando corregir fallos reales de VSTO/Interop.
- Se mantiene Gemini 3.8 Flash + Interactions API + Function Calling validado + auditoría final obligatoria + fallback estructurado.
- Versionado actualizado a 1.2.0.0, instalador `GeoOfficeAI-Setup-v1.2.exe` y artefacto GitHub v1.2.

## v1.1 Copilot-style Agent

- Orquestador reforzado para peticiones compuestas: Gemini recibe la obligación de cumplir todos los requisitos antes de terminar.
- Segunda auditoría agentic independiente después de aplicar cambios: vuelve a leer Office, compara contra la petición original y corrige faltantes antes de aceptar el resultado.
- Word: nueva acción `format_style` para aplicar reglas a todos los párrafos de un estilo/título detectado.
- Word: nuevas acciones `set_table_cell_margins` y `style_table` para márgenes internos de celdas, estilos profesionales, encabezados, bandas, autofit y ancho.
- Word: `add_table` admite opciones de estilo/márgenes desde la misma acción.
- Word: nueva acción `add_image_placeholder` para dejar espacios reales y ordenados para imágenes sin usar generación de pago.
- Word: anclajes `anchorText` + `anchorPlacement` para insertar tablas, espacios, texto, fuentes y otros elementos antes/después de una referencia concreta del documento.
- Word: contexto estructurado ampliado con tamaño/negrita/cursiva/alineación/nivel de esquema por párrafo, padding/autofit de tablas y conteo/muestra de errores ortográficos de Word.
- Gemini: reglas explícitas para distinguir márgenes de página frente a márgenes internos de cuadros/tablas y para no abandonar órdenes largas después de un solo cambio.
- Gemini: búsqueda web se activa también para “si falta información”, “lo que falte” y formulaciones equivalentes.
- Interactions API migrada al endpoint estable `v1`; se conserva `store=false` y Function Calling `validated`.
- Panel compacto, historial por documento y sesión cifrada mantienen el comportamiento definido en v1.0. Al cerrar la X se intenta revocar primero el refresh token persistente de Google antes de eliminarlo localmente.
- Versiones e instalador actualizados a 1.1.

## v1.0 Agentic

- Migrado el núcleo principal a Gemini Interactions API con `gemini-3.8-flash`.
- Añadido Function Calling `apply_office_actions` con esquema validado y lotes de máximo 12 acciones.
- Bucle agente: ejecutar -> verificar contexto real de Office -> corregir/continuar -> confirmar solo al finalizar.
- Google Search se habilita para solicitudes de investigación/actualidad y Word puede insertar una sección de fuentes con enlaces reales.
- Panel reducido a 350 px y prompt compacto.
- Historial por documento guardado, cifrado con DPAPI. El mismo archivo reanuda su chat; otro archivo usa otro historial.
- Cerrar Office conserva sesión e historial. Cerrar la X del asistente elimina conversaciones y revoca la sesión.
- OAuth refresh token persistente cifrado con DPAPI CurrentUser.
- Contexto estructurado de Word ampliado y nuevas acciones: `add_sources`, `add_footnote`, `add_bookmark`, `add_textbox`, `insert_equation`, `add_caption`.
- Se mantiene el planificador estructurado reforzado como fallback.
- Versiones e instalador actualizados a 1.0.

## v0.9

- Auditoría de robustez del flujo Gemini → plan → validación → Office.
- Esquema JSON tipado y específico para Word/Excel/PowerPoint; `action` ahora es un enum de identificadores exactos y los parámetros viajan como propiedades separadas.
- Reparación automática de planes inválidos: hasta 3 intentos de planificación, con validación local antes de tocar Office.
- Normalizador seguro para el error observado `set_margins{...}` / `set_margins(...)` y otras acciones con parámetros primitivos embebidos.
- Validación semántica ampliada: parámetros obligatorios, límites, tablas/rangos, colores, márgenes, índices y valores admitidos.
- Reintentos REST con backoff para errores transitorios de Gemini (408/429/5xx y fallos temporales de red).
- Word: cursor de ejecución persistente dentro de una petición para mantener el orden real de inserción.
- Word: transacción `UndoRecord` obligatoria; ante fallo/cancelación se intenta rollback automático completo.
- Word: detección previa de documento protegido/solo lectura y verificaciones posteriores en márgenes, orientación, papel, tablas, hipervínculos, TOC, columnas y numeración.
- UI: el mensaje de Gemini y las fuentes no se muestran como éxito antes de que Office termine.
- Corregido límite inconsistente de acciones (parser 80 vs schema/safety 160).
- Corregido workflow de GitHub que todavía publicaba artefactos/rutas v0.5.
- Excel: libro solo lectura bloqueado; copia de recuperación `SaveCopyAs` obligatoria y verificada antes del primer cambio; errores por acción más claros.
- PowerPoint: presentación solo lectura bloqueada; copia de recuperación obligatoria preservando el formato/extensión; errores por acción más claros.
- Word/Excel/PowerPoint: guardas STA para impedir mutaciones COM desde un hilo inadecuado.
- QA estática ampliada y matriz de pruebas reales P0 añadida en `docs/PRUEBAS-v0.9.md`.
- Instalador actualizado a `GeoOfficeAI-Setup-v0.9.exe`.

## v0.8

- Corrige fallo intermitente de compilación VSTO en GitHub Actions: `Illegal operation attempted on a registry key that has been marked for deletion`.
- La solución VSTO ahora se compila en serie con MSBuild `/m:1` para evitar carreras entre Word, Excel y PowerPoint sobre el registro durante los targets de Office.
- Mantiene el modelo Gemini configurado en v0.7.
- Instalador actualizado a `GeoOfficeAI-Setup-v0.8.exe`.

# v0.5

- Investigación técnica enfocada en documentación oficial de Microsoft Office/VSTO y Google Gemini.
- Word: formato de documento completo, columnas, tabla de contenido, hipervínculos/fuentes, saltos de sección e imágenes con ajuste de texto/alt text.
- Excel: tablas profesionales con estilo, columnas calculadas autoexpandibles, formato condicional, validación, filtros, ordenamiento, tablas dinámicas, nombres definidos, fila de totales y modo de cálculo.
- PowerPoint: layouts, temas locales, transiciones, animaciones básicas, alineación/distribución, notas del presentador, espacios para imágenes y estilo profesional global.
- Planificador Gemini reforzado para componer múltiples acciones coordinadas en una sola petición profesional.
- Google Search grounding ampliado para peticiones con fuentes/citas/información reciente.
- Lista blanca ampliada y validaciones adicionales de URL, archivos de tema y fórmulas.
- Límite de acciones por plan ampliado de 80 a 160 para trabajos complejos, conservando presupuesto de texto y validación antes de tocar Office.
- Corregidos puntos de interoperabilidad en Excel/PowerPoint para reducir riesgo de compilación con Office Interop 15.0.

# v0.4

- Proyecto corregido a **Word + Excel + PowerPoint**, no solo Word.
- Eliminados OpenAI/Claude/Ollama y configuración multi-proveedor.
- Solo Gemini mediante OAuth de Google de escritorio.
- Panel lateral tipo chat en las tres aplicaciones.
- Botón único en Ribbon para reabrir el panel tras cerrar la X.
- Tokens OAuth solo en memoria; PKCE + state + loopback local.
- Limpieza/revocación de sesión, chat y temporales al cerrar panel/Office.
- Named pipe local restringido al usuario de Windows.
- Motor de acciones separado para Word, Excel y PowerPoint.
- Validación previa por lista blanca y límites de seguridad.
- Google Search grounding cuando el usuario pide explícitamente buscar/investigar en Internet.
- Sin generación de imágenes por API; crea prompts para Gemini web.
- Inserción de imágenes locales permitida y validada.
- 3 claves de instalación conservadas como hashes SHA-256.
- Workflow Windows/GitHub Actions + instalador Inno Setup.

## v0.6
- Corrige el inicio de sesión cuando VSTO carga el complemento desde su caché y `GeoOfficeAI.Broker.exe` no está junto a `GeoOfficeAI.Shared.dll`.
- Instala un broker compartido en `{app}\Broker` y guarda `InstallDir` en el registro.
- Añade búsqueda de respaldo en Program Files/Program Files (x86) y carpetas Word/Excel/PowerPoint.


## v0.7
- Cambiado el modelo de Gemini de `gemini-2.5-flash` a `gemini-3.6-flash`, modelo estable actual disponible para proyectos nuevos.
- Eliminados parámetros de muestreo `temperature` del planificador para evitar depender de parámetros deprecados en Gemini 3.6.
- Instalador actualizado a `GeoOfficeAI-Setup-v0.7.exe`.
