﻿using GeoOfficeAI.Shared;
using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Office = Microsoft.Office.Core;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;

namespace GeoOfficeAI.PowerPointAddIn
{
    public sealed class PowerPointAutomationService : IOfficeHost
    {
        private readonly PowerPoint.Application _app;
        private string _lastBackup;

        public PowerPointAutomationService(PowerPoint.Application app) { _app = app; }
        public string HostName { get { return "PowerPoint"; } }
        public string HostLabel { get { return "Microsoft PowerPoint " + (_app.Version ?? "") + " · presentación actual"; } }

        public string GetDocumentSessionId()
        {
            try { PowerPoint.Presentation p = _app.ActivePresentation; return p == null ? "powerpoint:none" : "powerpoint:runtime:" + RuntimeHelpers.GetHashCode(p).ToString(); }
            catch { return "powerpoint:none"; }
        }

        public string GetPersistentDocumentKey()
        {
            try
            {
                PowerPoint.Presentation p = _app.ActivePresentation;
                if (p == null || string.IsNullOrWhiteSpace(p.Path)) return null;
                string full = p.FullName;
                return !string.IsNullOrWhiteSpace(full) && File.Exists(full) ? "powerpoint:" + Path.GetFullPath(full) : null;
            }
            catch { return null; }
        }

        public string GetDocumentDisplayName()
        {
            try { return _app.ActivePresentation == null ? "Sin presentación" : (_app.ActivePresentation.Name ?? "Presentación"); }
            catch { return "Presentación"; }
        }

        public string GetContext(int maxCharacters)
        {
            PowerPoint.Presentation p = _app.ActivePresentation;
            if (p == null) return "No hay presentación abierta.";
            var sb = new StringBuilder();
            sb.AppendLine("Presentación: " + p.Name);
            sb.AppendLine("Diapositivas: " + p.Slides.Count);
            try { sb.AppendLine("Tamaño: " + Math.Round(p.PageSetup.SlideWidth / 28.3464567, 1) + " x " + Math.Round(p.PageSetup.SlideHeight / 28.3464567, 1) + " cm"); } catch { }
            int current = 0;
            try { if (_app.ActiveWindow != null && _app.ActiveWindow.View.Slide != null) current = ((PowerPoint.Slide)_app.ActiveWindow.View.Slide).SlideIndex; } catch { }
            sb.AppendLine("Diapositiva actual: " + current);
            int maxSlides = Math.Min(p.Slides.Count, 80);
            for (int i = 1; i <= maxSlides; i++)
            {
                PowerPoint.Slide slide = p.Slides[i];
                sb.AppendLine("\n[DIAPOSITIVA " + i + "]");
                foreach (PowerPoint.Shape shape in slide.Shapes)
                {
                    try
                    {
                        if (shape.HasTextFrame == Office.MsoTriState.msoTrue && shape.TextFrame.HasText == Office.MsoTriState.msoTrue)
                        {
                            string text = shape.TextFrame.TextRange.Text;
                            if (!string.IsNullOrWhiteSpace(text)) sb.AppendLine(text.Replace("\r", "\n"));
                        }
                    }
                    catch { }
                    if (sb.Length >= maxCharacters) break;
                }
                if (sb.Length >= maxCharacters) break;
            }
            return SafeHelpers.Truncate(sb.ToString(), maxCharacters);
        }

        public string DescribePlan(OfficePlan plan)
        {
            var sb = new StringBuilder(); if (plan == null || plan.actions == null) return "Sin cambios.";
            foreach (var a in plan.actions) sb.AppendLine("• " + (a == null ? "acción" : a.action));
            return sb.ToString();
        }

        public Task ApplyPlanAsync(OfficePlan plan, CancellationToken token)
        {
            PlanSafety.Validate("powerpoint", plan);
            if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA) throw new InvalidOperationException("PowerPoint debe modificarse desde un hilo STA de Office. La operación fue bloqueada para evitar errores COM.");
            if (plan == null || plan.actions == null || plan.actions.Count == 0) return Task.CompletedTask;
            PowerPoint.Presentation p = _app.ActivePresentation;
            if (p == null) throw new InvalidOperationException("No hay una presentación de PowerPoint abierta.");
            if (p.ReadOnly == Office.MsoTriState.msoTrue) throw new InvalidOperationException("La presentación está abierta como solo lectura y no se puede modificar.");
            CreateBackup(p);
            try
            {
                for (int i = 0; i < plan.actions.Count; i++)
                {
                    token.ThrowIfCancellationRequested();
                    OfficeAction a = plan.actions[i];
                    if (a == null) continue;
                    try { ApplyAction(p, a); }
                    catch (Exception ex) { throw new InvalidOperationException("Falló la acción " + (i + 1) + " (" + a.action + "): " + ex.Message, ex); }
                }
                return Task.CompletedTask;
            }
            catch (OperationCanceledException)
            {
                throw new InvalidOperationException("La operación de PowerPoint fue cancelada. Se creó una copia de recuperación previa en: " + _lastBackup);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(ex.Message + " Se creó una copia de recuperación previa en: " + _lastBackup, ex);
            }
        }

        private void ApplyAction(PowerPoint.Presentation p, OfficeAction a)
        {
            string action = (a.action ?? "").ToLowerInvariant();
            switch (action)
            {
                case "add_slide": AddSlide(p, a); break;
                case "set_slide_title": SetSlideTitle(GetSlide(p, a.slideIndex), a.title ?? a.text ?? ""); break;
                case "add_textbox": AddTextBox(GetSlide(p, a.slideIndex), a); break;
                case "replace_text": ReplaceText(p, a); break;
                case "format_text": FormatText(p, a); break;
                case "add_table": AddTable(GetSlide(p, a.slideIndex), a); break;
                case "add_shape": AddShape(GetSlide(p, a.slideIndex), a); break;
                case "set_background": SetBackground(GetSlide(p, a.slideIndex), a.fillColorHex); break;
                case "duplicate_slide": GetSlide(p, a.slideIndex).Duplicate(); break;
                case "insert_picture": InsertPicture(GetSlide(p, a.slideIndex), a); break;
                case "apply_theme": ApplyTheme(p, a); break;
                case "set_transition": SetTransition(p, a); break;
                case "add_animation": AddAnimation(GetSlide(p, a.slideIndex), a); break;
                case "align_shapes": AlignShapes(p, GetSlide(p, a.slideIndex), a); break;
                case "distribute_shapes": DistributeShapes(GetSlide(p, a.slideIndex), a); break;
                case "set_notes": SetNotes(GetSlide(p, a.slideIndex), a.notesText ?? a.text ?? ""); break;
                case "add_image_placeholder": AddImagePlaceholder(GetSlide(p, a.slideIndex), a); break;
                case "set_slide_layout": SetSlideLayout(GetSlide(p, a.slideIndex), a.layoutType ?? a.target); break;
                case "apply_professional_style": ApplyProfessionalStyle(p, a); break;
                default: throw new InvalidOperationException("Acción de PowerPoint no permitida: " + a.action);
            }
        }

        private static void AddSlide(PowerPoint.Presentation p, OfficeAction a)
        {
            int index = p.Slides.Count + 1;
            if (!string.IsNullOrWhiteSpace(a.position) && a.position.StartsWith("after:", StringComparison.OrdinalIgnoreCase))
            {
                int n; if (int.TryParse(a.position.Substring(6), out n)) index = Math.Max(1, Math.Min(p.Slides.Count + 1, n + 1));
            }
            PowerPoint.Slide slide = p.Slides.Add(index, PowerPoint.PpSlideLayout.ppLayoutText);
            SetSlideTitle(slide, a.title ?? "");
            string body = a.text ?? a.subtitle ?? "";
            try
            {
                if (slide.Shapes.Placeholders.Count >= 2) slide.Shapes.Placeholders[2].TextFrame.TextRange.Text = body;
                else if (!string.IsNullOrWhiteSpace(body)) AddDefaultTextBox(slide, body);
            }
            catch { if (!string.IsNullOrWhiteSpace(body)) AddDefaultTextBox(slide, body); }
        }

        private static void SetSlideTitle(PowerPoint.Slide slide, string title)
        {
            try
            {
                PowerPoint.Shape s = slide.Shapes.Title;
                if (s != null) { s.TextFrame.TextRange.Text = title; return; }
            }
            catch { }
            PowerPoint.Shape box = slide.Shapes.AddTextbox(Office.MsoTextOrientation.msoTextOrientationHorizontal, SafeHelpers.CmToPoints(1.2), SafeHelpers.CmToPoints(0.7), SafeHelpers.CmToPoints(22), SafeHelpers.CmToPoints(1.8));
            box.TextFrame.TextRange.Text = title; box.TextFrame.TextRange.Font.Size = 26; box.TextFrame.TextRange.Font.Bold = Office.MsoTriState.msoTrue;
        }

        private static void AddDefaultTextBox(PowerPoint.Slide slide, string text)
        {
            PowerPoint.Shape box = slide.Shapes.AddTextbox(Office.MsoTextOrientation.msoTextOrientationHorizontal, SafeHelpers.CmToPoints(1.5), SafeHelpers.CmToPoints(3.0), SafeHelpers.CmToPoints(21), SafeHelpers.CmToPoints(10));
            box.TextFrame.TextRange.Text = text; box.TextFrame.TextRange.Font.Size = 18;
        }

        private static void AddTextBox(PowerPoint.Slide slide, OfficeAction a)
        {
            float left = SafeHelpers.CmToPoints(a.leftCm ?? 1.5), top = SafeHelpers.CmToPoints(a.topCm ?? 3.0), width = SafeHelpers.CmToPoints(a.widthCm ?? 21), height = SafeHelpers.CmToPoints(a.heightCm ?? 6);
            PowerPoint.Shape box = slide.Shapes.AddTextbox(Office.MsoTextOrientation.msoTextOrientationHorizontal, left, top, width, height);
            box.TextFrame.TextRange.Text = a.text ?? ""; ApplyTextFormat(box.TextFrame.TextRange, a);
        }

        private static void ReplaceText(PowerPoint.Presentation p, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("replace_text requiere findText.");
            int changed = 0;
            foreach (PowerPoint.Slide slide in p.Slides)
            {
                foreach (PowerPoint.Shape shape in slide.Shapes)
                {
                    if (shape.HasTextFrame != Office.MsoTriState.msoTrue || shape.TextFrame.HasText != Office.MsoTriState.msoTrue) continue;
                    string oldText = shape.TextFrame.TextRange.Text ?? ""; string newText = ReplaceString(oldText, a.findText, a.replacementText ?? "", a.matchCase ?? false, a.replaceAll ?? false);
                    if (!string.Equals(oldText, newText, StringComparison.Ordinal)) { shape.TextFrame.TextRange.Text = newText; changed++; }
                    if (changed > 0 && !(a.replaceAll ?? false)) return;
                }
            }
            if (changed == 0) throw new InvalidOperationException("No se encontró el texto que debía reemplazarse: " + a.findText);
        }

        private static string ReplaceString(string source, string find, string replacement, bool matchCase, bool all)
        {
            StringComparison cmp = matchCase ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            int index = source.IndexOf(find, cmp); if (index < 0) return source;
            if (!all) return source.Substring(0, index) + replacement + source.Substring(index + find.Length);
            var sb = new StringBuilder(); int pos = 0;
            while (index >= 0)
            {
                sb.Append(source, pos, index - pos).Append(replacement); pos = index + find.Length; index = source.IndexOf(find, pos, cmp);
            }
            sb.Append(source, pos, source.Length - pos); return sb.ToString();
        }

        private static void FormatText(PowerPoint.Presentation p, OfficeAction a)
        {
            int start = a.slideIndex.HasValue ? a.slideIndex.Value : 1, end = a.slideIndex.HasValue ? a.slideIndex.Value : p.Slides.Count;
            int touched = 0;
            for (int i = Math.Max(1, start); i <= Math.Min(p.Slides.Count, end); i++)
            {
                PowerPoint.Slide slide = p.Slides[i];
                foreach (PowerPoint.Shape shape in slide.Shapes)
                {
                    if (shape.HasTextFrame != Office.MsoTriState.msoTrue || shape.TextFrame.HasText != Office.MsoTriState.msoTrue) continue;
                    string t = shape.TextFrame.TextRange.Text ?? "";
                    if (string.IsNullOrWhiteSpace(a.findText) || t.IndexOf(a.findText, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        ApplyTextFormat(shape.TextFrame.TextRange, a); touched++;
                    }
                }
            }
            if (touched == 0) throw new InvalidOperationException(string.IsNullOrWhiteSpace(a.findText) ? "No hay texto para formatear en las diapositivas indicadas." : "No se encontró el texto que debía formatearse: " + a.findText);
        }

        private static void ApplyTextFormat(PowerPoint.TextRange tr, OfficeAction a)
        {
            if (!string.IsNullOrWhiteSpace(a.fontName)) tr.Font.Name = a.fontName;
            if (a.fontSize.HasValue && a.fontSize.Value >= 6 && a.fontSize.Value <= 96) tr.Font.Size = (float)a.fontSize.Value;
            if (a.bold.HasValue) tr.Font.Bold = a.bold.Value ? Office.MsoTriState.msoTrue : Office.MsoTriState.msoFalse;
            if (a.italic.HasValue) tr.Font.Italic = a.italic.Value ? Office.MsoTriState.msoTrue : Office.MsoTriState.msoFalse;
            if (a.underline.HasValue) tr.Font.Underline = a.underline.Value ? Office.MsoTriState.msoTrue : Office.MsoTriState.msoFalse;
            if (!string.IsNullOrWhiteSpace(a.fontColorHex)) tr.Font.Color.RGB = SafeHelpers.ParseRgb(a.fontColorHex, 0);
            string al = (a.alignment ?? "").ToLowerInvariant();
            if (al == "center" || al == "centrado") tr.ParagraphFormat.Alignment = PowerPoint.PpParagraphAlignment.ppAlignCenter;
            else if (al == "right" || al == "derecha") tr.ParagraphFormat.Alignment = PowerPoint.PpParagraphAlignment.ppAlignRight;
            else if (al == "left" || al == "izquierda") tr.ParagraphFormat.Alignment = PowerPoint.PpParagraphAlignment.ppAlignLeft;
        }

        private static void AddTable(PowerPoint.Slide slide, OfficeAction a)
        {
            if (a.rows == null || a.rows.Count == 0) return;
            int nr = a.rows.Count, nc = 0; foreach (var row in a.rows) if (row != null) nc = Math.Max(nc, row.Count);
            if (nr > 30 || nc > 12 || nc == 0) throw new InvalidOperationException("La tabla de PowerPoint supera el límite de 30x12.");
            float left = SafeHelpers.CmToPoints(a.leftCm ?? 1.5), top = SafeHelpers.CmToPoints(a.topCm ?? 4), width = SafeHelpers.CmToPoints(a.widthCm ?? 21), height = SafeHelpers.CmToPoints(a.heightCm ?? 8);
            PowerPoint.Shape shape = slide.Shapes.AddTable(nr, nc, left, top, width, height);
            for (int r = 0; r < nr; r++) for (int c = 0; c < nc; c++) shape.Table.Cell(r + 1, c + 1).Shape.TextFrame.TextRange.Text = a.rows[r] != null && c < a.rows[r].Count ? (a.rows[r][c] ?? "") : "";
        }

        private static void AddShape(PowerPoint.Slide slide, OfficeAction a)
        {
            Office.MsoAutoShapeType type = Office.MsoAutoShapeType.msoShapeRoundedRectangle;
            string x = (a.shapeType ?? "rounded_rectangle").ToLowerInvariant();
            if (x.Contains("rect") && !x.Contains("rounded")) type = Office.MsoAutoShapeType.msoShapeRectangle;
            else if (x.Contains("oval") || x.Contains("circle") || x.Contains("círc")) type = Office.MsoAutoShapeType.msoShapeOval;
            else if (x.Contains("arrow") || x.Contains("flecha")) type = Office.MsoAutoShapeType.msoShapeRightArrow;
            PowerPoint.Shape shape = slide.Shapes.AddShape(type, SafeHelpers.CmToPoints(a.leftCm ?? 2), SafeHelpers.CmToPoints(a.topCm ?? 4), SafeHelpers.CmToPoints(a.widthCm ?? 6), SafeHelpers.CmToPoints(a.heightCm ?? 3));
            if (!string.IsNullOrWhiteSpace(a.fillColorHex)) shape.Fill.ForeColor.RGB = SafeHelpers.ParseRgb(a.fillColorHex, 0xEEEEEE);
            shape.TextFrame.TextRange.Text = a.text ?? ""; if (!string.IsNullOrWhiteSpace(a.fontColorHex)) shape.TextFrame.TextRange.Font.Color.RGB = SafeHelpers.ParseRgb(a.fontColorHex, 0);
        }

        private static void SetBackground(PowerPoint.Slide slide, string color)
        {
            slide.FollowMasterBackground = Office.MsoTriState.msoFalse; slide.Background.Fill.Solid(); slide.Background.Fill.ForeColor.RGB = SafeHelpers.ParseRgb(color, 16777215);
        }

        private PowerPoint.Slide GetSlide(PowerPoint.Presentation p, int? requested)
        {
            int index = requested ?? 0;
            if (index <= 0)
            {
                try { if (_app.ActiveWindow != null && _app.ActiveWindow.View.Slide != null) index = ((PowerPoint.Slide)_app.ActiveWindow.View.Slide).SlideIndex; } catch { }
            }
            if (index <= 0) index = 1;
            if (index > p.Slides.Count) throw new InvalidOperationException("No existe la diapositiva " + index + ".");
            return p.Slides[index];
        }


        private static void InsertPicture(PowerPoint.Slide slide, OfficeAction a)
        {
            PlanSafety.ValidatePicturePath(a.filePath);
            float left = SafeHelpers.CmToPoints(a.leftCm ?? 2.0);
            float top = SafeHelpers.CmToPoints(a.topCm ?? 3.0);
            float width = SafeHelpers.CmToPoints(Math.Max(0.5, Math.Min(50, a.widthCm ?? 12.0)));
            float height = SafeHelpers.CmToPoints(Math.Max(0.5, Math.Min(50, a.heightCm ?? 8.0)));
            slide.Shapes.AddPicture(a.filePath, Office.MsoTriState.msoFalse, Office.MsoTriState.msoTrue, left, top, width, height);
        }

        private static void ApplyTheme(PowerPoint.Presentation p, OfficeAction a)
        {
            PlanSafety.ValidateThemePath(a.filePath);
            p.ApplyTheme(a.filePath);
        }

        private static void SetTransition(PowerPoint.Presentation p, OfficeAction a)
        {
            int start = a.slideIndex.HasValue ? Math.Max(1, a.slideIndex.Value) : 1;
            int end = a.slideIndex.HasValue ? Math.Min(p.Slides.Count, a.slideIndex.Value) : p.Slides.Count;
            PowerPoint.PpEntryEffect effect = MapTransitionEffect(a.effect ?? a.target);
            PowerPoint.PpTransitionSpeed speed = MapTransitionSpeed(a.speed);
            for (int i = start; i <= end; i++)
            {
                PowerPoint.SlideShowTransition tr = p.Slides[i].SlideShowTransition;
                tr.EntryEffect = effect;
                tr.Speed = speed;
                tr.AdvanceOnClick = Office.MsoTriState.msoTrue;
                tr.AdvanceOnTime = Office.MsoTriState.msoFalse;
                if (tr.EntryEffect != effect) throw new InvalidOperationException("PowerPoint no confirmó la transición en la diapositiva " + i + ".");
            }
        }

        private static PowerPoint.PpEntryEffect MapTransitionEffect(string value)
        {
            string x = (value ?? "fade").ToLowerInvariant();
            if (x.Contains("push") || x.Contains("empuj")) return PowerPoint.PpEntryEffect.ppEffectPushLeft;
            if (x.Contains("wipe") || x.Contains("barr")) return PowerPoint.PpEntryEffect.ppEffectWipeLeft;
            if (x.Contains("split") || x.Contains("divid")) return PowerPoint.PpEntryEffect.ppEffectSplitHorizontalIn;
            if (x.Contains("none") || x.Contains("ningun") || x.Contains("ningún")) return PowerPoint.PpEntryEffect.ppEffectNone;
            return PowerPoint.PpEntryEffect.ppEffectFade;
        }

        private static PowerPoint.PpTransitionSpeed MapTransitionSpeed(string value)
        {
            string x = (value ?? "fast").ToLowerInvariant();
            if (x.Contains("slow") || x.Contains("lenta")) return PowerPoint.PpTransitionSpeed.ppTransitionSpeedSlow;
            if (x.Contains("medium") || x.Contains("media")) return PowerPoint.PpTransitionSpeed.ppTransitionSpeedMedium;
            return PowerPoint.PpTransitionSpeed.ppTransitionSpeedFast;
        }

        private static void AddAnimation(PowerPoint.Slide slide, OfficeAction a)
        {
            PowerPoint.Shape shape = FindTargetShape(slide, a.target ?? a.findText);
            if (shape == null) throw new InvalidOperationException("No se encontró una forma para animar en la diapositiva.");
            PowerPoint.MsoAnimEffect effect = MapAnimationEffect(a.effect);
            try
            {
                PowerPoint.Effect e = slide.TimeLine.MainSequence.AddEffect(shape, effect, PowerPoint.MsoAnimateByLevel.msoAnimateLevelNone, PowerPoint.MsoAnimTriggerType.msoAnimTriggerOnPageClick, -1);
                string timing = (a.position ?? "").ToLowerInvariant();
                if (timing.Contains("after") || timing.Contains("después") || timing.Contains("despues")) e.Timing.TriggerType = PowerPoint.MsoAnimTriggerType.msoAnimTriggerAfterPrevious;
                else if (timing.Contains("with") || timing.Contains("con anterior")) e.Timing.TriggerType = PowerPoint.MsoAnimTriggerType.msoAnimTriggerWithPrevious;
            }
            catch (Exception ex) { throw new InvalidOperationException("PowerPoint no pudo aplicar la animación: " + ex.Message); }
        }

        private static PowerPoint.MsoAnimEffect MapAnimationEffect(string value)
        {
            string x = (value ?? "fade").ToLowerInvariant();
            if (x.Contains("appear") || x.Contains("apare")) return PowerPoint.MsoAnimEffect.msoAnimEffectAppear;
            if (x.Contains("fly") || x.Contains("volar") || x.Contains("entrar")) return PowerPoint.MsoAnimEffect.msoAnimEffectFly;
            if (x.Contains("wipe") || x.Contains("barr")) return PowerPoint.MsoAnimEffect.msoAnimEffectWipe;
            if (x.Contains("zoom")) return PowerPoint.MsoAnimEffect.msoAnimEffectFadedZoom;
            return PowerPoint.MsoAnimEffect.msoAnimEffectFade;
        }

        private static PowerPoint.Shape FindTargetShape(PowerPoint.Slide slide, string target)
        {
            if (!string.IsNullOrWhiteSpace(target))
            {
                foreach (PowerPoint.Shape s in slide.Shapes)
                {
                    try
                    {
                        if (string.Equals(s.Name, target, StringComparison.OrdinalIgnoreCase)) return s;
                        if (s.HasTextFrame == Office.MsoTriState.msoTrue && s.TextFrame.HasText == Office.MsoTriState.msoTrue && (s.TextFrame.TextRange.Text ?? "").IndexOf(target, StringComparison.OrdinalIgnoreCase) >= 0) return s;
                    }
                    catch { }
                }
            }
            try { if (slide.Shapes.Title != null) return slide.Shapes.Title; } catch { }
            foreach (PowerPoint.Shape s in slide.Shapes) return s;
            return null;
        }

        private static List<PowerPoint.Shape> SelectShapes(PowerPoint.Slide slide, OfficeAction a)
        {
            var result = new List<PowerPoint.Shape>();
            if (a.items != null && a.items.Count > 0)
            {
                foreach (string name in a.items)
                {
                    foreach (PowerPoint.Shape s in slide.Shapes)
                    {
                        try { if (string.Equals(s.Name, name, StringComparison.OrdinalIgnoreCase)) { result.Add(s); break; } } catch { }
                    }
                }
            }
            else
            {
                foreach (PowerPoint.Shape s in slide.Shapes) result.Add(s);
            }
            return result;
        }

        private static void AlignShapes(PowerPoint.Presentation presentation, PowerPoint.Slide slide, OfficeAction a)
        {
            List<PowerPoint.Shape> shapes = SelectShapes(slide, a);
            if (shapes.Count == 0) throw new InvalidOperationException("No se encontraron formas para alinear.");
            if (a.items != null && a.items.Count > 0 && shapes.Count != a.items.Count) throw new InvalidOperationException("No se encontraron todas las formas solicitadas para alinear.");
            string x = (a.alignment ?? a.target ?? "left").ToLowerInvariant();
            float slideW = presentation.PageSetup.SlideWidth, slideH = presentation.PageSetup.SlideHeight;
            foreach (PowerPoint.Shape s in shapes)
            {
                if (x.Contains("center") || x.Contains("centro")) s.Left = (slideW - s.Width) / 2f;
                else if (x.Contains("right") || x.Contains("derecha")) s.Left = slideW - s.Width;
                else if (x.Contains("top") || x.Contains("arriba")) s.Top = 0f;
                else if (x.Contains("bottom") || x.Contains("abajo")) s.Top = slideH - s.Height;
                else if (x.Contains("middle") || x.Contains("medio")) s.Top = (slideH - s.Height) / 2f;
                else s.Left = 0f;
            }
        }

        private static void DistributeShapes(PowerPoint.Slide slide, OfficeAction a)
        {
            List<PowerPoint.Shape> shapes = SelectShapes(slide, a);
            if (a.items != null && a.items.Count > 0 && shapes.Count != a.items.Count) throw new InvalidOperationException("No se encontraron todas las formas solicitadas para distribuir.");
            if (shapes.Count < 3) throw new InvalidOperationException("Se necesitan al menos 3 formas para distribuirlas.");
            bool vertical = (a.target ?? a.alignment ?? "horizontal").ToLowerInvariant().Contains("vertical");
            shapes.Sort((x, y) => vertical ? x.Top.CompareTo(y.Top) : x.Left.CompareTo(y.Left));
            float first = vertical ? shapes[0].Top : shapes[0].Left;
            float last = vertical ? shapes[shapes.Count - 1].Top : shapes[shapes.Count - 1].Left;
            float step = (last - first) / (shapes.Count - 1);
            for (int i = 1; i < shapes.Count - 1; i++)
            {
                if (vertical) shapes[i].Top = first + step * i; else shapes[i].Left = first + step * i;
            }
        }

        private static void SetNotes(PowerPoint.Slide slide, string text)
        {
            try
            {
                foreach (PowerPoint.Shape s in slide.NotesPage.Shapes)
                {
                    if (s.Type == Office.MsoShapeType.msoPlaceholder && s.PlaceholderFormat.Type == PowerPoint.PpPlaceholderType.ppPlaceholderBody)
                    {
                        s.TextFrame.TextRange.Text = text ?? "";
                        if (!string.Equals(s.TextFrame.TextRange.Text ?? "", text ?? "", StringComparison.Ordinal)) throw new InvalidOperationException("PowerPoint no confirmó las notas del presentador.");
                        return;
                    }
                }
                throw new InvalidOperationException("La diapositiva no tiene un área de notas editable.");
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex) { throw new InvalidOperationException("No se pudieron editar las notas del presentador: " + ex.Message, ex); }
        }

        private static void AddImagePlaceholder(PowerPoint.Slide slide, OfficeAction a)
        {
            float left = SafeHelpers.CmToPoints(a.leftCm ?? 13.5), top = SafeHelpers.CmToPoints(a.topCm ?? 3.2), width = SafeHelpers.CmToPoints(a.widthCm ?? 10.0), height = SafeHelpers.CmToPoints(a.heightCm ?? 7.0);
            PowerPoint.Shape box = slide.Shapes.AddShape(Office.MsoAutoShapeType.msoShapeRectangle, left, top, width, height);
            box.Fill.Visible = Office.MsoTriState.msoFalse;
            box.Line.DashStyle = Office.MsoLineDashStyle.msoLineDash;
            box.Line.ForeColor.RGB = SafeHelpers.ParseRgb(a.fontColorHex, 0x777777);
            box.TextFrame.TextRange.Text = string.IsNullOrWhiteSpace(a.text) ? "ESPACIO PARA IMAGEN" : a.text;
            box.TextFrame.TextRange.Font.Size = 13; box.TextFrame.TextRange.Font.Color.RGB = SafeHelpers.ParseRgb(a.fontColorHex, 0x777777);
            box.TextFrame.TextRange.ParagraphFormat.Alignment = PowerPoint.PpParagraphAlignment.ppAlignCenter;
            try { box.TextFrame.VerticalAnchor = Office.MsoVerticalAnchor.msoAnchorMiddle; } catch { }
        }

        private static void SetSlideLayout(PowerPoint.Slide slide, string value)
        {
            string x = (value ?? "text").ToLowerInvariant();
            PowerPoint.PpSlideLayout layout = PowerPoint.PpSlideLayout.ppLayoutText;
            if (x.Contains("blank") || x.Contains("blanco")) layout = PowerPoint.PpSlideLayout.ppLayoutBlank;
            else if (x.Contains("title_only") || x.Contains("solo título") || x.Contains("solo titulo")) layout = PowerPoint.PpSlideLayout.ppLayoutTitleOnly;
            else if (x.Contains("title") && !x.Contains("text")) layout = PowerPoint.PpSlideLayout.ppLayoutTitle;
            else if (x.Contains("two") || x.Contains("dos")) layout = PowerPoint.PpSlideLayout.ppLayoutTwoColumnText;
            slide.Layout = layout;
            if (slide.Layout != layout) throw new InvalidOperationException("PowerPoint no confirmó el diseño de diapositiva solicitado.");
        }

        private static void ApplyProfessionalStyle(PowerPoint.Presentation p, OfficeAction a)
        {
            string font = string.IsNullOrWhiteSpace(a.fontName) ? "Calibri" : a.fontName;
            int textColor = SafeHelpers.ParseRgb(a.fontColorHex, 0x222222);
            int background = SafeHelpers.ParseRgb(a.fillColorHex, 0xFFFFFF);
            foreach (PowerPoint.Slide slide in p.Slides)
            {
                try { slide.FollowMasterBackground = Office.MsoTriState.msoFalse; slide.Background.Fill.Solid(); slide.Background.Fill.ForeColor.RGB = background; } catch { }
                foreach (PowerPoint.Shape shape in slide.Shapes)
                {
                    try
                    {
                        if (shape.HasTextFrame != Office.MsoTriState.msoTrue || shape.TextFrame.HasText != Office.MsoTriState.msoTrue) continue;
                        PowerPoint.TextRange tr = shape.TextFrame.TextRange; tr.Font.Name = font; tr.Font.Color.RGB = textColor;
                        bool isTitle = false; try { isTitle = slide.Shapes.Title != null && shape.Id == slide.Shapes.Title.Id; } catch { }
                        if (isTitle) { tr.Font.Size = (float)(a.fontSize ?? 28); tr.Font.Bold = Office.MsoTriState.msoTrue; }
                        else { if (!a.fontSize.HasValue) tr.Font.Size = 18; }
                    }
                    catch { }
                }
            }
        }

        private void CreateBackup(PowerPoint.Presentation p)
        {
            try
            {
                SafeHelpers.DeleteIfExists(_lastBackup);
                string ext = Path.GetExtension(p.Name); if (string.IsNullOrWhiteSpace(ext)) ext = ".pptx";
                _lastBackup = Path.Combine(Path.GetTempPath(), "GeoOfficeAI_PowerPoint_" + Guid.NewGuid().ToString("N") + ext);
                p.SaveCopyAs(_lastBackup, BackupFormatForExtension(ext), Office.MsoTriState.msoFalse);
                if (!File.Exists(_lastBackup) || new FileInfo(_lastBackup).Length == 0) throw new IOException("PowerPoint no confirmó la copia de recuperación.");
            }
            catch (Exception ex)
            {
                _lastBackup = null;
                throw new InvalidOperationException("No se aplicó ningún cambio porque PowerPoint no pudo crear primero una copia de recuperación segura. " + ex.Message, ex);
            }
        }

        private static PowerPoint.PpSaveAsFileType BackupFormatForExtension(string extension)
        {
            string ext = (extension ?? "").ToLowerInvariant();
            if (ext == ".pptm") return PowerPoint.PpSaveAsFileType.ppSaveAsOpenXMLPresentationMacroEnabled;
            if (ext == ".ppsx") return PowerPoint.PpSaveAsFileType.ppSaveAsOpenXMLShow;
            if (ext == ".ppsm") return PowerPoint.PpSaveAsFileType.ppSaveAsOpenXMLShowMacroEnabled;
            if (ext == ".potx") return PowerPoint.PpSaveAsFileType.ppSaveAsOpenXMLTemplate;
            if (ext == ".potm") return PowerPoint.PpSaveAsFileType.ppSaveAsOpenXMLTemplateMacroEnabled;
            if (ext == ".ppt") return PowerPoint.PpSaveAsFileType.ppSaveAsPresentation;
            if (ext == ".pps") return PowerPoint.PpSaveAsFileType.ppSaveAsShow;
            if (ext == ".pot") return PowerPoint.PpSaveAsFileType.ppSaveAsTemplate;
            return PowerPoint.PpSaveAsFileType.ppSaveAsOpenXMLPresentation;
        }

        public void UndoLast()
        {
            try { _app.CommandBars.ExecuteMso("Undo"); return; }
            catch { }
            if (!string.IsNullOrWhiteSpace(_lastBackup) && File.Exists(_lastBackup)) throw new InvalidOperationException("PowerPoint no permitió deshacer automáticamente. Se conserva temporalmente una copia previa durante esta sesión.");
            throw new InvalidOperationException("PowerPoint no pudo deshacer el último cambio.");
        }

        public void WipeTemporaryData() { SafeHelpers.DeleteIfExists(_lastBackup); _lastBackup = null; }
    }
}
