﻿using System.Threading;
using System.Threading.Tasks;

namespace GeoOfficeAI.Shared
{
    public interface IOfficeHost
    {
        string HostName { get; }
        string HostLabel { get; }
        string GetContext(int maxCharacters);
        string DescribePlan(OfficePlan plan);
        Task ApplyPlanAsync(OfficePlan plan, CancellationToken token);
        void UndoLast();
        void WipeTemporaryData();

        // Identidad del archivo activo para mantener un chat por documento.
        // SessionId solo necesita ser estable durante la ejecución actual de Office.
        string GetDocumentSessionId();
        // Devuelve una clave persistente solo cuando el archivo ya existe en disco.
        string GetPersistentDocumentKey();
        string GetDocumentDisplayName();
    }
}
