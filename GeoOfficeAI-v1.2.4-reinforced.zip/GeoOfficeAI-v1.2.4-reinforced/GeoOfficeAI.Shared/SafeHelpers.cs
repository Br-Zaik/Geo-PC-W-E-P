﻿using System;
using System.Drawing;
using System.Globalization;
using System.IO;

namespace GeoOfficeAI.Shared
{
    public static class SafeHelpers
    {
        public static float CmToPoints(double cm) { return (float)(cm * 28.3464566929); }

        public static int ParseRgb(string hex, int fallback)
        {
            if (string.IsNullOrWhiteSpace(hex)) return fallback;
            string h = hex.Trim().TrimStart('#');
            if (h.Length != 6) return fallback;
            int r, g, b;
            if (!int.TryParse(h.Substring(0, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out r)) return fallback;
            if (!int.TryParse(h.Substring(2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out g)) return fallback;
            if (!int.TryParse(h.Substring(4, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out b)) return fallback;
            return ColorTranslator.ToOle(Color.FromArgb(r, g, b));
        }

        public static string Truncate(string value, int max)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= max) return value ?? "";
            return value.Substring(0, max) + "\n[CONTENIDO RECORTADO POR SEGURIDAD]";
        }

        public static bool LooksLikeUnsafeExcelFormula(string formula)
        {
            if (string.IsNullOrWhiteSpace(formula)) return false;
            string f = formula.ToUpperInvariant();
            // Bloquea vectores de ejecución/DDE y funciones capaces de invocar o recuperar contenido externo.
            // Las fórmulas normales y las referencias estructuradas de Tablas de Excel siguen permitidas.
            return f.Contains("|") ||
                   f.Contains("POWERSHELL") || f.Contains("CMD.EXE") || f.Contains("MSHTA") ||
                   f.Contains("WSCRIPT") || f.Contains("CSCRIPT") || f.Contains("RUNDLL32") ||
                   f.Contains("WEBSERVICE(") || f.Contains("FILTERXML(") || f.Contains("RTD(") ||
                   f.Contains("CALL(") || f.Contains("EXEC(") || f.Contains("REGISTER.ID(");
        }

        public static void DeleteIfExists(string path)
        {
            try { if (!string.IsNullOrWhiteSpace(path) && File.Exists(path)) File.Delete(path); } catch { }
        }
    }
}
