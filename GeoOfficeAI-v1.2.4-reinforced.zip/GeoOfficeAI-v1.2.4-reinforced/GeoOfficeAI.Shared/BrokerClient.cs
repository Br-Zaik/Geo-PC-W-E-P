﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Win32;

namespace GeoOfficeAI.Shared
{
    public sealed class BrokerClient
    {
        private const string PipeName = "GeoOfficeAI.Session.v1";
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };

        public async Task<BrokerResponse> StatusAsync(CancellationToken token)
        {
            return await SendAsync(new BrokerRequest { command = "status" }, token, false);
        }

        public async Task<BrokerResponse> LoginAsync(CancellationToken token)
        {
            return await SendAsync(new BrokerRequest { command = "login" }, token, true);
        }

        public async Task<BrokerResponse> AgentStartAsync(string host, string instruction, string context, string history, CancellationToken token)
        {
            var response = await SendAsync(new BrokerRequest
            {
                command = "agent_start",
                host = host,
                instruction = instruction,
                context = context,
                history = history
            }, token, true);
            if (!response.ok)
            {
                DiagnosticLogger.ExternalError("BrokerClient", "AgentStart.Response", response.error ?? "No se pudo iniciar el agente Gemini.");
                throw new InvalidOperationException(response.error ?? "No se pudo iniciar el agente Gemini.");
            }
            if (!response.connected) throw new InvalidOperationException("Primero inicia sesión con Google.");
            return response;
        }

        public async Task<BrokerResponse> AgentContinueAsync(string agentSessionId, string callId, string functionName, string toolResult, CancellationToken token)
        {
            var response = await SendAsync(new BrokerRequest
            {
                command = "agent_continue",
                agentSessionId = agentSessionId,
                callId = callId,
                functionName = functionName,
                toolResult = toolResult
            }, token, true);
            if (!response.ok)
            {
                DiagnosticLogger.ExternalError("BrokerClient", "AgentContinue.Response", response.error ?? "No se pudo continuar el agente Gemini.");
                throw new InvalidOperationException(response.error ?? "No se pudo continuar el agente Gemini.");
            }
            if (!response.connected) throw new InvalidOperationException("La sesión de Google terminó.");
            return response;
        }

        public async Task<OfficePlan> PlanAsync(string host, string instruction, string context, CancellationToken token)
        {
            var response = await SendAsync(new BrokerRequest
            {
                command = "plan",
                host = host,
                instruction = instruction,
                context = context
            }, token, true);

            if (!response.ok)
            {
                DiagnosticLogger.ExternalError("BrokerClient", "Plan.Response", response.error ?? "No se pudo consultar Gemini.");
                throw new InvalidOperationException(response.error ?? "No se pudo consultar Gemini.");
            }
            if (!response.connected) throw new InvalidOperationException("Primero inicia sesión con Google.");
            return PlanParser.Parse(response.planJson);
        }

        public async Task WipeAsync()
        {
            try { await SendAsync(new BrokerRequest { command = "wipe" }, CancellationToken.None, false); }
            catch { }
        }

        private async Task<BrokerResponse> SendAsync(BrokerRequest request, CancellationToken token, bool startBroker)
        {
            if (startBroker) EnsureBrokerStarted();

            Exception last = null;
            int attempts = startBroker ? 20 : 2;
            for (int i = 0; i < attempts; i++)
            {
                token.ThrowIfCancellationRequested();
                try
                {
                    using (var pipe = new NamedPipeClientStream(".", PipeName, PipeDirection.InOut, PipeOptions.Asynchronous))
                    {
                        pipe.Connect(500);
                        string payload = _json.Serialize(request);
                        byte[] data = Encoding.UTF8.GetBytes(payload);
                        byte[] len = BitConverter.GetBytes(data.Length);
                        await pipe.WriteAsync(len, 0, len.Length, token);
                        await pipe.WriteAsync(data, 0, data.Length, token);
                        await pipe.FlushAsync(token);

                        byte[] rlen = await ReadExactAsync(pipe, 4, token);
                        int count = BitConverter.ToInt32(rlen, 0);
                        if (count <= 0 || count > 8 * 1024 * 1024) throw new IOException("Respuesta IPC inválida.");
                        byte[] rdata = await ReadExactAsync(pipe, count, token);
                        var response = _json.Deserialize<BrokerResponse>(Encoding.UTF8.GetString(rdata));
                        return response ?? new BrokerResponse { ok = false, error = "Respuesta vacía del servicio Gemini." };
                    }
                }
                catch (Exception ex)
                {
                    last = ex;
                    if (!startBroker) break;
                    await Task.Delay(200, token);
                }
            }

            return new BrokerResponse { ok = false, connected = false, error = "No se pudo iniciar el servicio local de Gemini. " + (last == null ? "" : last.Message) };
        }

        private async Task<byte[]> ReadExactAsync(Stream stream, int count, CancellationToken token)
        {
            byte[] buffer = new byte[count];
            int offset = 0;
            while (offset < count)
            {
                int read = await stream.ReadAsync(buffer, offset, count - offset, token);
                if (read <= 0) throw new EndOfStreamException();
                offset += read;
            }
            return buffer;
        }

        private static void EnsureBrokerStarted()
        {
            string exe = FindBrokerExe();
            if (string.IsNullOrWhiteSpace(exe) || !File.Exists(exe))
            {
                throw new FileNotFoundException(
                    "No se encontró GeoOfficeAI.Broker.exe en la instalación de Geo Office AI. Reinstala la versión más reciente.");
            }

            string dir = Path.GetDirectoryName(exe);
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = exe,
                    WorkingDirectory = dir,
                    UseShellExecute = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                });
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("No se pudo iniciar el servicio Gemini: " + ex.Message);
            }
        }

        private static string FindBrokerExe()
        {
            var candidates = new List<string>();

            AddCandidate(candidates, Path.GetDirectoryName(typeof(BrokerClient).Assembly.Location));
            AddCandidate(candidates, AppDomain.CurrentDomain.BaseDirectory);
            AddCandidate(candidates, Environment.CurrentDirectory);

            string installDir = ReadInstallDirFromRegistry();
            if (!string.IsNullOrWhiteSpace(installDir))
            {
                AddCandidate(candidates, Path.Combine(installDir, "Broker"));
                AddCandidate(candidates, Path.Combine(installDir, "Word"));
                AddCandidate(candidates, Path.Combine(installDir, "Excel"));
                AddCandidate(candidates, Path.Combine(installDir, "PowerPoint"));
            }

            AddProgramFilesCandidates(candidates, Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
            AddProgramFilesCandidates(candidates, Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86));

            foreach (string dir in candidates)
            {
                try
                {
                    string path = Path.Combine(dir, "GeoOfficeAI.Broker.exe");
                    if (File.Exists(path)) return path;
                }
                catch { }
            }

            return null;
        }

        private static void AddProgramFilesCandidates(List<string> candidates, string baseDir)
        {
            if (string.IsNullOrWhiteSpace(baseDir)) return;
            string root = Path.Combine(baseDir, "GeoOfficeAI");
            AddCandidate(candidates, Path.Combine(root, "Broker"));
            AddCandidate(candidates, Path.Combine(root, "Word"));
            AddCandidate(candidates, Path.Combine(root, "Excel"));
            AddCandidate(candidates, Path.Combine(root, "PowerPoint"));
        }

        private static void AddCandidate(List<string> candidates, string dir)
        {
            if (string.IsNullOrWhiteSpace(dir)) return;
            foreach (string existing in candidates)
            {
                if (string.Equals(existing, dir, StringComparison.OrdinalIgnoreCase)) return;
            }
            candidates.Add(dir);
        }

        private static string ReadInstallDirFromRegistry()
        {
            string subkey = @"SOFTWARE\GeoOfficeAI\OfficeSuite";
            RegistryView[] views = Environment.Is64BitOperatingSystem
                ? new[] { RegistryView.Registry64, RegistryView.Registry32 }
                : new[] { RegistryView.Registry32 };

            foreach (RegistryView view in views)
            {
                try
                {
                    using (RegistryKey baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view))
                    using (RegistryKey key = baseKey.OpenSubKey(subkey))
                    {
                        if (key == null) continue;
                        string value = key.GetValue("InstallDir") as string;
                        if (!string.IsNullOrWhiteSpace(value)) return value;
                    }
                }
                catch { }
            }

            return null;
        }
    }
}
