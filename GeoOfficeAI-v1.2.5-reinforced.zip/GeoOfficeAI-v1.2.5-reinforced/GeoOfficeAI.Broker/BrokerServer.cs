﻿using GeoOfficeAI.Shared;
using System;
using System.IO;
using System.IO.Pipes;
using System.Security.Principal;
using System.Security.AccessControl;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Broker
{
    internal sealed class BrokerServer
    {
        private const string PipeName = "GeoOfficeAI.Session.v1";
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        private readonly OAuthSession _session = new OAuthSession();
        private readonly GeminiPlanner _planner;
        private readonly GeminiAgent _agent;
        private volatile bool _stop;

        public BrokerServer() { _planner = new GeminiPlanner(_session); _agent = new GeminiAgent(_session); }

        public void Run()
        {
            while (!_stop)
            {
                using (var pipe = CreateSecurePipe())
                {
                    try
                    {
                        pipe.WaitForConnection();
                        BrokerRequest req = ReadRequest(pipe);
                        BrokerResponse resp = Process(req);
                        WriteResponse(pipe, resp);
                    }
                    catch { }
                }
            }
        }


        private static NamedPipeServerStream CreateSecurePipe()
        {
            var security = new PipeSecurity();
            SecurityIdentifier sid = WindowsIdentity.GetCurrent().User;
            if (sid == null) throw new InvalidOperationException("No se pudo identificar al usuario de Windows.");
            security.SetOwner(sid);
            security.AddAccessRule(new PipeAccessRule(sid, PipeAccessRights.ReadWrite | PipeAccessRights.CreateNewInstance, AccessControlType.Allow));
            return new NamedPipeServerStream(PipeName, PipeDirection.InOut, 4, PipeTransmissionMode.Byte, PipeOptions.Asynchronous, 8192, 8192, security);
        }
        private BrokerResponse Process(BrokerRequest req)
        {
            try
            {
                string cmd = (req == null ? null : req.command) ?? "";
                if (cmd == "status") return new BrokerResponse { ok = true, connected = _session.IsConnected, displayName = _session.DisplayName };
                if (cmd == "login")
                {
                    using (var cts = new CancellationTokenSource(TimeSpan.FromMinutes(4))) _session.LoginAsync(cts.Token).GetAwaiter().GetResult();
                    return new BrokerResponse { ok = true, connected = _session.IsConnected, displayName = _session.DisplayName };
                }
                if (cmd == "agent_start")
                {
                    if (!_session.IsConnected) return new BrokerResponse { ok = false, connected = false, error = "Primero inicia sesión con Google." };
                    try
                    {
                        using (var cts = new CancellationTokenSource(TimeSpan.FromMinutes(4)))
                            return _agent.StartAsync(req.host, req.instruction, req.context, req.history, cts.Token).GetAwaiter().GetResult();
                    }
                    catch (Exception agentError)
                    {
                        // v1.2.5: no encadenar modelos/endpoints por cuota o fallos transitorios.
                        // GeminiAgent ya gestiona Retry-After y un único fallback Interactions.
                        if (!ShouldUseLegacyPlannerFallback(agentError.Message))
                        {
                            string detail = SafeError(agentError.Message);
                            DiagnosticLogger.ExternalError("Broker", "AgentStart.Failed", detail);
                            return new BrokerResponse { ok = false, connected = _session.IsConnected, displayName = _session.DisplayName, error = detail };
                        }

                        try
                        {
                            using (var cts = new CancellationTokenSource(TimeSpan.FromMinutes(3)))
                            {
                                string plan = _planner.CreatePlanJsonAsync(req.host, req.instruction, req.context, cts.Token).GetAwaiter().GetResult();
                                OfficePlan parsed = PlanParser.Parse(plan);
                                return new BrokerResponse
                                {
                                    ok = true, connected = true, usingFallback = true, completed = false,
                                    planJson = plan, finalMessage = parsed.message, displayName = _session.DisplayName,
                                    error = "Interactions no estuvo disponible por compatibilidad; se usó el planificador de respaldo. " + SafeError(agentError.Message)
                                };
                            }
                        }
                        catch (Exception fallbackError)
                        {
                            string detail = "Agente Interactions: " + SafeError(agentError.Message) +
                                            " | Motor de respaldo: " + SafeError(fallbackError.Message);
                            DiagnosticLogger.ExternalError("Broker", "AgentStart.BothFailed", detail);
                            return new BrokerResponse { ok = false, connected = _session.IsConnected, displayName = _session.DisplayName, error = detail };
                        }
                    }
                }
                if (cmd == "agent_continue")
                {
                    if (!_session.IsConnected) return new BrokerResponse { ok = false, connected = false, error = "La sesión de Google terminó." };
                    using (var cts = new CancellationTokenSource(TimeSpan.FromMinutes(4)))
                        return _agent.ContinueAsync(req.agentSessionId, req.callId, req.functionName, req.toolResult, cts.Token).GetAwaiter().GetResult();
                }
                if (cmd == "plan")
                {
                    if (!_session.IsConnected) return new BrokerResponse { ok = false, connected = false, error = "Primero inicia sesión con Google." };
                    using (var cts = new CancellationTokenSource(TimeSpan.FromMinutes(3)))
                    {
                        string plan = _planner.CreatePlanJsonAsync(req.host, req.instruction, req.context, cts.Token).GetAwaiter().GetResult();
                        return new BrokerResponse { ok = true, connected = true, displayName = _session.DisplayName, planJson = plan };
                    }
                }
                if (cmd == "wipe")
                {
                    _agent.ClearSessions();
                    _session.WipeAsync().GetAwaiter().GetResult();
                    _stop = true;
                    return new BrokerResponse { ok = true, connected = false };
                }
                return new BrokerResponse { ok = false, connected = _session.IsConnected, error = "Comando IPC no reconocido." };
            }
            catch (Exception ex)
            {
                return new BrokerResponse { ok = false, connected = _session.IsConnected, error = ex.Message };
            }
        }


        private static bool ShouldUseLegacyPlannerFallback(string message)
        {
            string x = (message ?? "").ToLowerInvariant();
            if (x.Contains("429") || x.Contains("quota") || x.Contains("resource_exhausted") ||
                x.Contains("401") || x.Contains("403") || x.Contains("permission_denied") ||
                x.Contains("timeout") || x.Contains("tiempo de espera") || x.Contains("500") || x.Contains("502") || x.Contains("503") || x.Contains("504"))
                return false;
            return x.Contains("404") || x.Contains("405") || x.Contains("501") || x.Contains("unimplemented") || x.Contains("method not found");
        }

        private static string SafeError(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return "Error desconocido";
            string x = text.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ").Trim();
            if (x.Length > 1400) x = x.Substring(0, 1400);
            return x;
        }

        private BrokerRequest ReadRequest(Stream stream)
        {
            byte[] len = ReadExact(stream, 4); int count = BitConverter.ToInt32(len, 0);
            if (count <= 0 || count > 8 * 1024 * 1024) throw new IOException("Solicitud IPC inválida.");
            return _json.Deserialize<BrokerRequest>(Encoding.UTF8.GetString(ReadExact(stream, count)));
        }

        private void WriteResponse(Stream stream, BrokerResponse response)
        {
            byte[] data = Encoding.UTF8.GetBytes(_json.Serialize(response)); byte[] len = BitConverter.GetBytes(data.Length);
            stream.Write(len, 0, len.Length); stream.Write(data, 0, data.Length); stream.Flush();
        }

        private static byte[] ReadExact(Stream stream, int count)
        {
            byte[] b = new byte[count]; int o = 0;
            while (o < count) { int r = stream.Read(b, o, count - o); if (r <= 0) throw new EndOfStreamException(); o += r; }
            return b;
        }
    }
}
