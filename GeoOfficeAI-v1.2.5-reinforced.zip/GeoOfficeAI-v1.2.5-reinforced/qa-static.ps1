﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Require-Text([string]$Path, [string]$Pattern, [string]$Message) {
  $text = Get-Content (Join-Path $root $Path) -Raw
  if ($text -notmatch $Pattern) { throw $Message }
}
function Forbid-Text([string]$Path, [string]$Pattern, [string]$Message) {
  $text = Get-Content (Join-Path $root $Path) -Raw
  if ($text -match $Pattern) { throw $Message }
}
function Get-Allowed([string]$Host) {
  $text = Get-Content (Join-Path $root 'GeoOfficeAI.Shared\PlanSafety.cs') -Raw
  $m = [regex]::Match($text, '\{\s*"' + [regex]::Escape($Host) + '"\s*,\s*new HashSet<string>\([^\)]*\)\s*\{(?<body>.*?)\}\s*\}', 'Singleline')
  if (!$m.Success) { throw "No se encontró whitelist para $Host" }
  return [regex]::Matches($m.Groups['body'].Value, '"(?<a>[a-z0-9_]+)"') | ForEach-Object { $_.Groups['a'].Value } | Sort-Object -Unique
}
function Get-Handlers([string]$Path) {
  $text = Get-Content (Join-Path $root $Path) -Raw
  return [regex]::Matches($text, 'case\s+"(?<a>[a-z0-9_]+)"\s*:') | ForEach-Object { $_.Groups['a'].Value } | Sort-Object -Unique
}

$map = @{ word='GeoOfficeAI.Word\WordAutomationService.cs'; excel='GeoOfficeAI.Excel\ExcelAutomationService.cs'; powerpoint='GeoOfficeAI.PowerPoint\PowerPointAutomationService.cs' }
foreach ($host in $map.Keys) {
  $allowed = Get-Allowed $host; $handlers = Get-Handlers $map[$host]
  $missing = $allowed | Where-Object { $_ -notin $handlers }
  if ($missing) { throw "${host}: acciones permitidas sin handler: $($missing -join ', ')" }
}

# Motor agente y fallback
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'gemini-3\.8-flash' 'El agente no usa Gemini 3.8 Flash.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'v1/interactions' 'Falta Interactions API estable v1.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'apply_office_actions' 'Falta function calling de Office.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' '"tool_choice", "validated"' 'Function Calling no usa modo validated.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' '"type", "google_search"' 'Falta Google Search integrado.'
Require-Text 'GeoOfficeAI.Broker\BrokerServer.cs' 'usingFallback = true' 'Falta fallback del agente.'
Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'responseJsonSchema' 'El fallback perdió structured output.'
Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'MaxPlanAttempts\s*=\s*3' 'El fallback perdió reparación limitada.'

# Seguridad/ejecución real
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'StartCustomRecord\("Geo Office AI"\)' 'Word no inicia UndoRecord.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'TryRollback\(doc\)' 'Word no intenta rollback.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'PreflightPlan\(doc, plan\)' 'Word no pre-valida el lote.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' '_executionCursor' 'Word no mantiene cursor entre acciones.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'GetDocumentSessionId' 'Word no expone identidad de documento.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'add_sources' 'Word no tiene fuentes insertables.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'add_footnote' 'Word no tiene notas al pie.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'insert_equation' 'Word no tiene ecuaciones.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'case "format_style"' 'Word no ejecuta format_style.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'case "set_table_cell_margins"' 'Word no ejecuta márgenes internos de tabla.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'case "style_table"' 'Word no ejecuta estilo profesional de tabla.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'case "add_image_placeholder"' 'Word no crea espacios para imágenes.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'action\.anchorText' 'Word no soporta inserción anclada.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'WORD ANCLAJES:' 'Gemini no recibió reglas para inserción anclada.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'SpellingErrors\.Count' 'El contexto Word no incluye señales ortográficas.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'ApplyTableMargins' 'Word no distingue/aplica márgenes internos de tabla.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'finalAuditStarted' 'Falta auditoría final agentic.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'AUDITORÍA FINAL OBLIGATORIA' 'Falta instrucción de auditoría final.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'ORQUESTACIÓN:' 'Faltan reglas de orquestación compuesta.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'No confundas margen de página con margen interno de celdas' 'Falta distinción semántica de márgenes.'
Require-Text 'GeoOfficeAI.Excel\ExcelAutomationService.cs' 'CreateBackup\(wb\)' 'Excel no crea copia de recuperación.'
Require-Text 'GeoOfficeAI.PowerPoint\PowerPointAutomationService.cs' 'CreateBackup\(p\)' 'PowerPoint no crea copia de recuperación.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'ApartmentState\.STA' 'Word no protege COM STA.'
Require-Text 'GeoOfficeAI.Excel\ExcelAutomationService.cs' 'ApartmentState\.STA' 'Excel no protege COM STA.'
Require-Text 'GeoOfficeAI.PowerPoint\PowerPointAutomationService.cs' 'ApartmentState\.STA' 'PowerPoint no protege COM STA.'

# Diagnóstico local sin contenido sensible
Require-Text 'GeoOfficeAI.Shared\GeoOfficeAI.Shared.csproj' 'DiagnosticLogger\.cs' 'DiagnosticLogger no está incluido en Shared.'
Require-Text 'GeoOfficeAI.Shared\DiagnosticLogger.cs' 'DataProtectionScope|REDACTED' 'El diagnóstico no incluye protección/redacción esperada.'
Require-Text 'GeoOfficeAI.Shared\DiagnosticLogger.cs' 'MaxLogBytes' 'Falta rotación del diagnóstico.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'Request\.BatchFailed' 'Los fallos de lotes no se registran en diagnóstico.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'Request\.Failed' 'Los fallos finales no se registran en diagnóstico.'

# Sesión, historial y UI compacta
Require-Text 'GeoOfficeAI.Shared\ConversationStore.cs' 'ProtectedData\.Protect' 'El historial no está cifrado con DPAPI.'
Require-Text 'GeoOfficeAI.Shared\ConversationStore.cs' 'DataProtectionScope\.CurrentUser' 'El historial no está ligado al usuario Windows.'
Require-Text 'GeoOfficeAI.Broker\OAuthSession.cs' 'PersistRefreshToken' 'No se persiste de forma segura la sesión Google.'
Require-Text 'GeoOfficeAI.Broker\OAuthSession.cs' 'ProtectedData\.Protect' 'El refresh token no está cifrado.'
Require-Text 'GeoOfficeAI.Broker\OAuthSession.cs' 'tokenToRevoke' 'La X no intenta revocar la concesión persistente.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'ConversationStore\.Load' 'La UI no restaura historial por documento.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'SuspendForOfficeShutdown' 'La UI no distingue cierre de Office.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'ConversationStore\.DeleteAll' 'La X no elimina historiales.'
Require-Text 'GeoOfficeAI.Word\ThisAddIn.cs' '_pane\.Width = 350' 'El panel Word no quedó compacto.'
Require-Text 'GeoOfficeAI.Excel\ThisAddIn.cs' '_pane\.Width = 350' 'El panel Excel no quedó compacto.'
Require-Text 'GeoOfficeAI.PowerPoint\ThisAddIn.cs' '_pane\.Width = 350' 'El panel PowerPoint no quedó compacto.'
Require-Text 'GeoOfficeAI.Word\ThisAddIn.cs' '_assistantCloseDecisionTimer' 'Word no difiere la decisión X/cierre de Office.'
Require-Text 'GeoOfficeAI.Excel\ThisAddIn.cs' '_assistantCloseDecisionTimer' 'Excel no difiere la decisión X/cierre de Office.'
Require-Text 'GeoOfficeAI.PowerPoint\ThisAddIn.cs' '_assistantCloseDecisionTimer' 'PowerPoint no difiere la decisión X/cierre de Office.'
Forbid-Text 'GeoOfficeAI.Word\ThisAddIn.cs' 'ThisAddIn_Shutdown[\s\S]{0,250}WipeSensitiveSession' 'Cerrar Word todavía borra la sesión.'
Forbid-Text 'GeoOfficeAI.Excel\ThisAddIn.cs' 'ThisAddIn_Shutdown[\s\S]{0,250}WipeSensitiveSession' 'Cerrar Excel todavía borra la sesión.'
Forbid-Text 'GeoOfficeAI.PowerPoint\ThisAddIn.cs' 'ThisAddIn_Shutdown[\s\S]{0,250}WipeSensitiveSession' 'Cerrar PowerPoint todavía borra la sesión.'

# Clave única de instalación
$iss = Get-Content (Join-Path $root 'installer\GeoOfficeAI.iss') -Raw
if ($iss -notmatch "KeyHash\s*=\s*'468D033ED1220225776BD98829D0A3051D729049677172176DA0BEBC555F6D30'") { throw 'La clave única de instalación no coincide con la solicitada.' }
if ($iss -match 'KeyHash2|KeyHash3|KeyHash1') { throw 'Aún quedan múltiples claves de instalación.' }
if ($iss -notmatch 'Result := \(H = KeyHash\);') { throw 'El instalador no valida únicamente la clave autorizada.' }

# Versionado
Require-Text 'GeoOfficeAI.Word\Properties\AssemblyInfo.cs' 'AssemblyVersion\("1\.2\.5\.0"\)' 'AssemblyVersion Word != 1.2.4.'
Require-Text 'GeoOfficeAI.Excel\Properties\AssemblyInfo.cs' 'AssemblyVersion\("1\.2\.5\.0"\)' 'AssemblyVersion Excel != 1.2.4.'
Require-Text 'GeoOfficeAI.PowerPoint\Properties\AssemblyInfo.cs' 'AssemblyVersion\("1\.2\.5\.0"\)' 'AssemblyVersion PowerPoint != 1.2.4.'
if ($iss -notmatch '#define MyAppVersion "1\.2\.5"' -or $iss -notmatch 'OutputBaseFilename=GeoOfficeAI-Setup-v1\.2\.5') { throw 'Instalador no es v1.2.5.' }
$wf = Get-Content (Join-Path $root '.github\workflows\build-windows.yml') -Raw
if ($wf -notmatch 'GeoOfficeAI-v1\.2\.5-Reforzado-Windows' -or $wf -notmatch 'GeoOfficeAI-Setup-v1\.2\.5\.exe') { throw 'Workflow no apunta a v1.2.5.' }


# Regresión GitHub Actions #16: Word.Table.Style no puede usarse como propiedad
# con los PIAs de Office que exponen set_Style(ref object); provocaba CS1545.
$wordAutomation = Get-Content 'GeoOfficeAI.Word\WordAutomationService.cs' -Raw
if ($wordAutomation -match '\btable\.Style\s*=') { throw 'Table.Style = puede romper la compilación (CS1545). Usar set_Style(ref object).' }
if ($wordAutomation -notmatch 'table\.set_Style\(ref value\)') { throw 'Falta accessor COM seguro para estilos de tabla.' }


# Regresión GitHub Actions #18: Application.NewDocument puede ser ambiguo (CS0229)
# porque Word.Application hereda _Application y ApplicationEvents4_Event.
$wordAddIn = Get-Content 'GeoOfficeAI.Word\ThisAddIn.cs' -Raw
if ($wordAddIn -match 'this\.Application\.NewDocument\s*\+=') { throw 'Suscripción ambigua a Application.NewDocument (CS0229). Usar ApplicationEvents4_Event.' }
if ($wordAddIn -notmatch 'Word\.ApplicationEvents4_Event\s+_wordEvents') { throw 'Falta interfaz explícita ApplicationEvents4_Event para eventos Word.' }
if ($wordAddIn -notmatch '_wordEvents\.NewDocument\s*\+=\s*Application_NewDocument') { throw 'NewDocument no está suscrito mediante ApplicationEvents4_Event.' }

# Evitar aviso de Node 20 en GitHub Actions.
if ($wf -notmatch 'actions/checkout@v5') { throw 'Workflow debe usar actions/checkout@v5.' }


# Regresiones de ejecución real detectadas en Word (10/09/2026)
Forbid-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'RuntimeHelpers\.GetHashCode\(doc\)' 'Documento Word nuevo sigue usando hash inestable del RCW.'
Require-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'win\.Hwnd' 'Falta identidad estable de ventana para documento Word no guardado.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'RunOnOfficeUiAsync' 'Las llamadas COM no se fuerzan al hilo UI de VSTO.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'Office rechazó todas las acciones' 'Falta bloqueo de falso éxito cuando Office no aplicó ningún lote.'
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'if \(!force && _cts != null\) return;' 'El cambio de conversación puede ocurrir mientras una petición está activa.'
Require-Text 'GeoOfficeAI.Shared\DiagnosticLogger.cs' 'ExternalError' 'Falta diagnóstico sanitizado de errores externos.'
Require-Text 'GeoOfficeAI.Shared\BrokerClient.cs' 'AgentStart\.Response' 'BrokerClient no registra el mensaje real del fallo AgentStart.'
Require-Text 'GeoOfficeAI.Broker\BrokerServer.cs' 'AgentStart\.BothFailed' 'Broker no conserva el fallo conjunto agente + fallback.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'v1beta/interactions' 'Falta fallback de endpoint Interactions v1beta.'
Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'gemini-3\.7-flash' 'Fallback no usa Gemini 3.7 Flash.'
Require-Text 'GeoOfficeAI.Broker\GeminiPlanner.cs' 'gemini-3\.6-flash' 'Fallback no usa Gemini 3.6 Flash.'

# v1.2.5: cuota y una llamada normal.
Require-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'Request\.CompletedLocal' 'Falta finalización local tras un lote correcto.'
Forbid-Text 'GeoOfficeAI.Shared\AssistantPane.cs' 'AUDITORÍA FINAL OBLIGATORIA' 'La auditoría final con segunda llamada a Gemini sigue activa.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'MaxActionsPerBatch = 48' 'El agente no permite hasta 48 acciones en un lote.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'QuotaFallbackModel = "gemini-3\.5-flash-lite"' 'Falta fallback Interactions Flash-Lite.'
Require-Text 'GeoOfficeAI.Broker\GeminiAgent.cs' 'RateLimit\.Wait' 'Falta espera Retry-After.'
Require-Text 'GeoOfficeAI.Broker\BrokerServer.cs' 'ShouldUseLegacyPlannerFallback' 'Broker no limita planner legacy.'
Forbid-Text 'GeoOfficeAI.Word\WordAutomationService.cs' 'SetOrientation\(doc, a\.orientation\);\s*SetOrientation\(doc, a\.orientation\);' 'set_orientation duplicado.'

Write-Host 'Static QA v1.2.5 Copilot reforzado: PASS' -ForegroundColor Green
