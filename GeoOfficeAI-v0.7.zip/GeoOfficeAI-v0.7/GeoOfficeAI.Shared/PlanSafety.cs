using System;
using System.Collections.Generic;
using System.IO;

namespace GeoOfficeAI.Shared
{
    public static class PlanSafety
    {
        private static readonly Dictionary<string, HashSet<string>> Allowed = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase)
        {
            { "word", new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                "replace_selection","insert_text","replace_text","format_selection","format_document","format_find","add_heading","add_list","add_table",
                "set_margins","set_orientation","set_paper_size","set_header","set_footer","add_page_numbers","page_break","add_comment","track_changes","insert_picture",
                "set_columns","add_toc","add_hyperlink","insert_section_break"
            }},
            { "excel", new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                "set_cell","set_formula","set_range_values","format_range","autofit","create_table","create_chart","add_sheet","rename_sheet",
                "merge_range","freeze_top_row","replace_text","insert_picture",
                "create_calculated_column","conditional_format","data_validation","sort_range","filter_range","create_pivot_table","define_name","set_calculation","show_totals_row"
            }},
            { "powerpoint", new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                "add_slide","set_slide_title","add_textbox","replace_text","format_text","add_table","add_shape","set_background","duplicate_slide","insert_picture",
                "apply_theme","set_transition","add_animation","align_shapes","distribute_shapes","set_notes","add_image_placeholder","set_slide_layout","apply_professional_style"
            }}
        };

        public static void Validate(string host, OfficePlan plan)
        {
            if (plan == null) throw new InvalidOperationException("Gemini devolvió un plan vacío.");
            if (plan.actions == null) plan.actions = new List<OfficeAction>();
            if (plan.actions.Count > 160) throw new InvalidOperationException("Gemini intentó ejecutar demasiadas acciones en una sola petición.");

            HashSet<string> allowed;
            if (!Allowed.TryGetValue(host ?? "", out allowed)) throw new InvalidOperationException("Aplicación de Office no reconocida.");

            long textBudget = 0;
            foreach (OfficeAction a in plan.actions)
            {
                if (a == null) continue;
                string action = (a.action ?? "").Trim();
                if (!allowed.Contains(action)) throw new InvalidOperationException("Acción bloqueada por seguridad: " + action);

                textBudget += Len(a.text) + Len(a.replacementText) + Len(a.headerText) + Len(a.footerText) + Len(a.commentText) + Len(a.title) + Len(a.subtitle)
                    + Len(a.formula) + Len(a.notesText) + Len(a.value1) + Len(a.value2) + Len(a.criteria1) + Len(a.url);
                if (a.items != null) foreach (string s in a.items) textBudget += Len(s);
                if (a.rows != null) foreach (var row in a.rows) if (row != null) foreach (string s in row) textBudget += Len(s);
                if (textBudget > 500000) throw new InvalidOperationException("La petición intenta insertar demasiado contenido de una sola vez.");

                if ((string.Equals(action, "set_formula", StringComparison.OrdinalIgnoreCase) || string.Equals(action, "create_calculated_column", StringComparison.OrdinalIgnoreCase)) && SafeHelpers.LooksLikeUnsafeExcelFormula(a.formula))
                    throw new InvalidOperationException("La fórmula fue bloqueada por seguridad.");

                if (string.Equals(action, "add_hyperlink", StringComparison.OrdinalIgnoreCase)) ValidateHttpUrl(a.url);
                if (string.Equals(action, "apply_theme", StringComparison.OrdinalIgnoreCase)) ValidateThemePath(a.filePath);

                if (string.Equals(action, "insert_picture", StringComparison.OrdinalIgnoreCase)) ValidatePicturePath(a.filePath);
            }
        }

        public static void ValidatePicturePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new InvalidOperationException("Para insertar una imagen debes indicar una ruta local existente.");
            string full;
            try { full = Path.GetFullPath(path); } catch { throw new InvalidOperationException("La ruta de la imagen no es válida."); }
            if (!File.Exists(full)) throw new FileNotFoundException("No se encontró la imagen indicada.", full);
            string ext = Path.GetExtension(full).ToLowerInvariant();
            string[] allowed = { ".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff" };
            bool ok = false; foreach (string x in allowed) if (ext == x) { ok = true; break; }
            if (!ok) throw new InvalidOperationException("Formato de imagen no permitido. Usa PNG, JPG, BMP, GIF o TIFF.");
            if (new FileInfo(full).Length > 25L * 1024L * 1024L) throw new InvalidOperationException("La imagen supera el límite de 25 MB.");
        }


        public static void ValidateThemePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new InvalidOperationException("Para aplicar un tema debes indicar un archivo local .thmx, .pot o .potx.");
            string full;
            try { full = Path.GetFullPath(path); } catch { throw new InvalidOperationException("La ruta del tema no es válida."); }
            if (!File.Exists(full)) throw new FileNotFoundException("No se encontró el tema indicado.", full);
            string ext = Path.GetExtension(full).ToLowerInvariant();
            if (ext != ".thmx" && ext != ".pot" && ext != ".potx") throw new InvalidOperationException("Formato de tema no permitido. Usa THMX, POT o POTX.");
            if (new FileInfo(full).Length > 50L * 1024L * 1024L) throw new InvalidOperationException("El archivo de tema supera 50 MB.");
        }

        public static void ValidateHttpUrl(string url)
        {
            Uri uri;
            if (string.IsNullOrWhiteSpace(url) || !Uri.TryCreate(url, UriKind.Absolute, out uri) ||
                !(uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps))
                throw new InvalidOperationException("Solo se permiten hipervínculos http/https válidos.");
        }

        private static int Len(string s) { return string.IsNullOrEmpty(s) ? 0 : s.Length; }
    }
}
