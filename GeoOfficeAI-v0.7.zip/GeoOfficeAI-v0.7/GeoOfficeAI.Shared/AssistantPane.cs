using System;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GeoOfficeAI.Shared
{
    public sealed class AssistantPane : UserControl
    {
        private readonly IOfficeHost _host;
        private readonly BrokerClient _broker;
        private readonly RichTextBox _chat;
        private readonly TextBox _prompt;
        private readonly Button _send;
        private readonly Button _login;
        private readonly Button _cancel;
        private readonly Button _undo;
        private readonly Label _status;
        private CancellationTokenSource _cts;
        private readonly System.Windows.Forms.Timer _statusTimer;
        private bool _connected;

        public AssistantPane(IOfficeHost host)
        {
            _host = host;
            _broker = new BrokerClient();
            BackColor = Color.White;
            Padding = new Padding(12);

            var header = new Label
            {
                Text = "Gemini · " + host.HostName,
                Font = new Font("Segoe UI", 15.5f, FontStyle.Bold),
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 2)
            };
            var sub = new Label
            {
                Text = "Pide lo que quieras en lenguaje normal. El complemento modifica este " + host.HostName + " directamente.",
                Font = new Font("Segoe UI", 9f), ForeColor = Color.DimGray,
                AutoSize = true, MaximumSize = new Size(390, 0), Margin = new Padding(0, 0, 0, 8)
            };
            var hostLabel = new Label
            {
                Text = host.HostLabel,
                Font = new Font("Segoe UI", 8.2f), ForeColor = Color.Gray,
                AutoSize = true, MaximumSize = new Size(390, 0), Margin = new Padding(0, 0, 0, 8)
            };

            _login = ButtonOf("Iniciar sesión con Google", 210, 36);
            _login.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            _login.Click += async (s, e) => await LoginAsync();

            _chat = new RichTextBox
            {
                ReadOnly = true, Width = 390, Height = 250, BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 9.5f),
                DetectUrls = true, Margin = new Padding(0, 8, 0, 8)
            };

            _prompt = new TextBox
            {
                Multiline = true, Width = 390, Height = 105, ScrollBars = ScrollBars.Vertical,
                Font = new Font("Segoe UI", 10f), Margin = new Padding(0, 0, 0, 7)
            };
            _prompt.KeyDown += Prompt_KeyDown;

            var row = new FlowLayoutPanel { AutoSize = true, Width = 400, FlowDirection = FlowDirection.LeftToRight, WrapContents = true, Margin = new Padding(0) };
            _send = ButtonOf("Enviar", 155, 36);
            _send.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            _send.Click += async (s, e) => await SendAsync();
            _cancel = ButtonOf("Cancelar", 92, 36);
            _cancel.Enabled = false;
            _cancel.Click += (s, e) => { try { if (_cts != null) _cts.Cancel(); } catch { } };
            _undo = ButtonOf("Deshacer IA", 110, 36);
            _undo.Click += (s, e) => Safe(() => _host.UndoLast());
            row.Controls.Add(_send); row.Controls.Add(_cancel); row.Controls.Add(_undo);

            _status = new Label
            {
                Text = "Sin sesión.", Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                ForeColor = Color.DarkOrange, AutoSize = true, MaximumSize = new Size(390, 0), Margin = new Padding(0, 9, 0, 0)
            };

            var privacy = new Label
            {
                Text = "Privacidad: la sesión de Google y el chat no se guardan. Al cerrar este panel o la aplicación de Office, se borran y se revoca el token cuando es posible.",
                Font = new Font("Segoe UI", 7.8f), ForeColor = Color.Gray,
                AutoSize = true, MaximumSize = new Size(390, 0), Margin = new Padding(0, 8, 0, 0)
            };

            var layout = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false,
                AutoScroll = true, BackColor = Color.White, Padding = new Padding(2)
            };
            layout.Controls.Add(header); layout.Controls.Add(sub); layout.Controls.Add(hostLabel); layout.Controls.Add(_login);
            layout.Controls.Add(_chat); layout.Controls.Add(_prompt); layout.Controls.Add(row); layout.Controls.Add(_status); layout.Controls.Add(privacy);
            Controls.Add(layout);

            SetConnected(false, "Sin sesión. Inicia sesión con Google para usar Gemini.");
            _statusTimer = new System.Windows.Forms.Timer { Interval = 8000 };
            _statusTimer.Tick += async (s, e) => await RefreshConnectionStatusAsync();
            _statusTimer.Start();
        }

        public void ResumeAfterShow()
        {
            try { _statusTimer.Start(); } catch { }
            _ = InitializeStatusAsync();
        }

        public async Task InitializeStatusAsync()
        {
            try
            {
                var r = await _broker.StatusAsync(CancellationToken.None);
                SetConnected(r.ok && r.connected, r.ok && r.connected ? "Gemini conectado." : "Sin sesión. Inicia sesión con Google.");
            }
            catch { SetConnected(false, "Sin sesión. Inicia sesión con Google."); }
        }

        private async Task RefreshConnectionStatusAsync()
        {
            if (_cts != null) return;
            try
            {
                var r = await _broker.StatusAsync(CancellationToken.None);
                if (!r.ok || !r.connected) SetConnected(false, "Sin sesión. Inicia sesión con Google.");
            }
            catch { if (_connected) SetConnected(false, "Sin sesión. Inicia sesión con Google."); }
        }

        private async Task LoginAsync()
        {
            SetBusy(true, "Abriendo inicio de sesión de Google...");
            _cts = new CancellationTokenSource(TimeSpan.FromMinutes(4));
            try
            {
                var r = await _broker.LoginAsync(_cts.Token);
                if (!r.ok) throw new InvalidOperationException(r.error ?? "No se pudo iniciar sesión.");
                SetConnected(r.connected, r.connected ? "Gemini conectado." : "No se completó el inicio de sesión.");
                if (r.connected) { _statusTimer.Start(); AppendAssistant("Sesión temporal iniciada. Cuando cierres el panel o Office se eliminará."); }
            }
            catch (OperationCanceledException) { _status.Text = "Inicio de sesión cancelado."; }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Geo Office AI", MessageBoxButtons.OK, MessageBoxIcon.Error); _status.Text = "No se pudo iniciar sesión."; }
            finally { DisposeCts(); SetBusy(false, _status.Text); }
        }

        private async Task SendAsync()
        {
            string instruction = (_prompt.Text ?? "").Trim();
            if (instruction.Length == 0) return;
            if (!_connected)
            {
                MessageBox.Show("Primero inicia sesión con Google.", "Geo Office AI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            AppendUser(instruction);
            _prompt.Clear();
            _cts = new CancellationTokenSource(TimeSpan.FromMinutes(3));
            SetBusy(true, "Gemini está analizando " + _host.HostName + "...");
            try
            {
                string context = _host.GetContext(70000);
                OfficePlan plan = await _broker.PlanAsync(_host.HostName.ToLowerInvariant(), instruction, context, _cts.Token);
                _cts.Token.ThrowIfCancellationRequested();

                if (!string.IsNullOrWhiteSpace(plan.message)) AppendAssistant(plan.message.Trim());
                if (plan.sources != null && plan.sources.Count > 0)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine("Fuentes:");
                    foreach (var s in plan.sources)
                    {
                        if (s == null || string.IsNullOrWhiteSpace(s.url)) continue;
                        sb.Append("• ").Append(string.IsNullOrWhiteSpace(s.title) ? s.url : s.title).Append(" — ").AppendLine(s.url);
                    }
                    AppendAssistant(sb.ToString().Trim());
                }

                if (plan.actions != null && plan.actions.Count > 0)
                {
                    _status.Text = "Aplicando " + plan.actions.Count + " cambio(s)...";
                    await _host.ApplyPlanAsync(plan, _cts.Token);
                    AppendAssistant("Cambios aplicados en " + _host.HostName + ".");
                }
                else if (string.IsNullOrWhiteSpace(plan.message))
                {
                    AppendAssistant("No fue necesario modificar el archivo.");
                }
                _status.Text = "Listo.";
            }
            catch (OperationCanceledException) { _status.Text = "Operación cancelada."; }
            catch (Exception ex)
            {
                _status.Text = "Error.";
                AppendAssistant("Error: " + ex.Message);
            }
            finally { DisposeCts(); SetBusy(false, _status.Text); }
        }

        private void Prompt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && e.Control)
            {
                e.SuppressKeyPress = true;
                _ = SendAsync();
            }
        }

        public void WipeSensitiveSession()
        {
            try { if (_statusTimer != null) _statusTimer.Stop(); } catch { }
            try { if (_cts != null && !_cts.IsCancellationRequested) _cts.Cancel(); } catch { }
            try
            {
                Task.Run(async () => await _broker.WipeAsync()).Wait(1800);
            }
            catch { }
            try { _host.WipeTemporaryData(); } catch { }
            try { _chat.Clear(); _prompt.Clear(); } catch { }
            SetConnected(false, "Sesión eliminada.");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                try { if (_statusTimer != null) { _statusTimer.Stop(); _statusTimer.Dispose(); } } catch { }
                DisposeCts();
            }
            base.Dispose(disposing);
        }

        private void SetConnected(bool value, string text)
        {
            _connected = value;
            _login.Visible = !value;
            _prompt.Enabled = value;
            _send.Enabled = value;
            _undo.Enabled = true;
            _status.Text = text;
            _status.ForeColor = value ? Color.DarkGreen : Color.DarkOrange;
        }

        private void SetBusy(bool busy, string text)
        {
            _login.Enabled = !busy;
            _send.Enabled = !busy && _connected;
            _prompt.Enabled = !busy && _connected;
            _cancel.Enabled = busy;
            _undo.Enabled = !busy;
            UseWaitCursor = busy;
            _status.Text = text;
        }

        private void AppendUser(string text) { Append("Tú", text, Color.FromArgb(30, 80, 150)); }
        private void AppendAssistant(string text) { Append("Gemini", text, Color.FromArgb(25, 115, 70)); }

        private void Append(string who, string text, Color color)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            _chat.SelectionStart = _chat.TextLength;
            _chat.SelectionColor = color;
            _chat.SelectionFont = new Font(_chat.Font, FontStyle.Bold);
            _chat.AppendText(who + ":\n");
            _chat.SelectionColor = Color.Black;
            _chat.SelectionFont = _chat.Font;
            _chat.AppendText(text.Trim() + "\n\n");
            _chat.ScrollToCaret();
        }

        private static Button ButtonOf(string text, int width, int height)
        {
            return new Button { Text = text, Width = width, Height = height, Font = new Font("Segoe UI", 9f), Margin = new Padding(0, 0, 7, 6), UseVisualStyleBackColor = true };
        }

        private void DisposeCts()
        {
            try { if (_cts != null) _cts.Dispose(); } catch { }
            _cts = null;
        }

        private static void Safe(Action a)
        {
            try { a(); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Geo Office AI", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
