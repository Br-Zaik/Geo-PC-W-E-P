using System.Threading;
using System.Threading.Tasks;

namespace GeoOfficeAI.Shared
{
    public interface IOfficeHost
    {
        string HostName { get; }
        string HostLabel { get; }
        string GetContext(int maxCharacters);
        string DescribePlan(OfficePlan plan);
        Task ApplyPlanAsync(OfficePlan plan, CancellationToken token);
        void UndoLast();
        void WipeTemporaryData();
    }
}
