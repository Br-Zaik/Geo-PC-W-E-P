using Microsoft.Win32;

namespace GeoOfficeAI.Shared
{
    public static class LicenseGuard
    {
        public static bool IsInstallAuthorized()
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\GeoOfficeAI\OfficeSuite"))
                    return string.Equals(key == null ? null : key.GetValue("InstallAuthorized") as string, "1", System.StringComparison.Ordinal);
            }
            catch { return false; }
        }
    }
}
