using GeoOfficeAI.Shared;
using Microsoft.Office.Tools;
using System;
using System.Net;
using Office = Microsoft.Office.Core;

namespace GeoOfficeAI.WordAddIn
{
    public partial class ThisAddIn
    {
        private AssistantPane _paneControl;
        private CustomTaskPane _pane;

        private void ThisAddIn_Startup(object sender, EventArgs e)
        {
            try
            {
                if (!LicenseGuard.IsInstallAuthorized()) return;
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                _paneControl = new AssistantPane(new WordAutomationService(this.Application));
                _pane = this.CustomTaskPanes.Add(_paneControl, "Asistente IA · Gemini");
                _pane.DockPosition = Microsoft.Office.Core.MsoCTPDockPosition.msoCTPDockPositionRight;
                _pane.Width = 430;
                _pane.VisibleChanged += Pane_VisibleChanged;
                _pane.Visible = true;
                _ = _paneControl.InitializeStatusAsync();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, "Geo Office AI · Word");
            }
        }

        private void Pane_VisibleChanged(object sender, EventArgs e)
        {
            if (_pane != null && !_pane.Visible && _paneControl != null) _paneControl.WipeSensitiveSession();
        }

        private void ThisAddIn_Shutdown(object sender, EventArgs e)
        {
            if (_paneControl != null) { _paneControl.WipeSensitiveSession(); _paneControl.Dispose(); }
        }

        internal void ShowAssistantPane()
        {
            if (_pane == null || _paneControl == null) return;
            _pane.Visible = true;
            _paneControl.ResumeAfterShow();
        }

        protected override Office.IRibbonExtensibility CreateRibbonExtensibilityObject()
        {
            return new OfficeRibbon();
        }

        private void InternalStartup()
        {
            this.Startup += new EventHandler(ThisAddIn_Startup);
            this.Shutdown += new EventHandler(ThisAddIn_Shutdown);
        }
    }
}
