using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Geo Office AI - Word")]
[assembly: AssemblyDescription("Gemini integrado en Microsoft Word")]
[assembly: AssemblyCompany("Geo Office AI")]
[assembly: AssemblyProduct("Geo Office AI")]
[assembly: AssemblyVersion("0.5.0.0")]
[assembly: AssemblyFileVersion("0.5.0.0")]
[assembly: ComVisible(false)]
