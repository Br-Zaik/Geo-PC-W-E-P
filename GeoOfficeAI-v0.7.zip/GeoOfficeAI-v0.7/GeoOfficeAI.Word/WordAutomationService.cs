using GeoOfficeAI.Shared;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Word = Microsoft.Office.Interop.Word;

namespace GeoOfficeAI.WordAddIn
{
    public sealed class WordAutomationService : IOfficeHost
    {
        private readonly Word.Application _app;
        private string _lastTempFile;

        public WordAutomationService(Word.Application app) { _app = app; }
        public string HostName { get { return "Word"; } }
        public string HostLabel { get { return "Microsoft Word " + (_app.Version ?? "") + " · documento actual"; } }

        public string GetContext(int maxCharacters)
        {
            var sb = new StringBuilder();
            Word.Document doc = _app.ActiveDocument;
            if (doc == null) return "No hay documento abierto.";
            sb.AppendLine("Documento: " + (doc.Name ?? "Sin nombre"));
            try { sb.AppendLine("Páginas: " + doc.ComputeStatistics(Word.WdStatistic.wdStatisticPages) + " · Secciones: " + doc.Sections.Count + " · Tablas: " + doc.Tables.Count); } catch { }
            try
            {
                Word.Selection sel = _app.Selection;
                string selected = sel == null ? "" : (sel.Text ?? "").Trim();
                if (selected.Length > 0)
                {
                    sb.AppendLine("SELECCIÓN ACTUAL:");
                    sb.AppendLine(SafeHelpers.Truncate(selected, Math.Min(20000, maxCharacters / 2)));
                }
            }
            catch { }
            sb.AppendLine("CONTENIDO DEL DOCUMENTO:");
            string body = "";
            try { body = doc.Content.Text ?? ""; } catch { }
            sb.AppendLine(SafeHelpers.Truncate(body, Math.Max(1000, maxCharacters - sb.Length)));
            return SafeHelpers.Truncate(sb.ToString(), maxCharacters);
        }

        public string DescribePlan(OfficePlan plan)
        {
            var sb = new StringBuilder();
            if (plan == null || plan.actions == null) return "Sin cambios.";
            foreach (var a in plan.actions) sb.AppendLine("• " + (a == null ? "acción" : a.action));
            return sb.ToString();
        }

        public Task ApplyPlanAsync(OfficePlan plan, CancellationToken token)
        {
            PlanSafety.Validate("word", plan);
            if (plan == null || plan.actions == null || plan.actions.Count == 0) return Task.CompletedTask;
            Word.Document doc = _app.ActiveDocument;
            if (doc == null) throw new InvalidOperationException("No hay un documento de Word abierto.");

            Word.UndoRecord undo = null;
            try { undo = _app.UndoRecord; undo.StartCustomRecord("Geo Office AI"); } catch { undo = null; }
            try
            {
                foreach (var action in plan.actions)
                {
                    token.ThrowIfCancellationRequested();
                    if (action != null) ApplyAction(doc, action);
                }
            }
            finally
            {
                try { if (undo != null) undo.EndCustomRecord(); } catch { }
            }
            return Task.CompletedTask;
        }

        private void ApplyAction(Word.Document doc, OfficeAction a)
        {
            string action = (a.action ?? "").Trim().ToLowerInvariant();
            switch (action)
            {
                case "replace_selection":
                    _app.Selection.Range.Text = a.text ?? "";
                    break;
                case "insert_text":
                    InsertText(doc, a.text ?? "", a.position);
                    break;
                case "replace_text":
                    ReplaceText(doc, a);
                    break;
                case "format_selection":
                    ApplyFormat(_app.Selection.Range, a);
                    break;
                case "format_document":
                    ApplyFormat(doc.Content, a);
                    break;
                case "format_find":
                    FormatFind(doc, a);
                    break;
                case "add_heading":
                    AddHeading(doc, a);
                    break;
                case "add_list":
                    AddList(doc, a);
                    break;
                case "add_table":
                    AddTable(doc, a);
                    break;
                case "set_margins":
                    SetMargins(doc, a);
                    break;
                case "set_orientation":
                    SetOrientation(doc, a.orientation);
                    break;
                case "set_paper_size":
                    SetPaperSize(doc, a.paperSize);
                    break;
                case "set_header":
                    foreach (Word.Section s in doc.Sections) s.Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range.Text = a.headerText ?? a.text ?? "";
                    break;
                case "set_footer":
                    foreach (Word.Section s in doc.Sections) s.Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range.Text = a.footerText ?? a.text ?? "";
                    break;
                case "add_page_numbers":
                    AddPageNumbers(doc, a.pageNumberPosition);
                    break;
                case "page_break":
                    GetInsertionRange(doc, a.position).InsertBreak(Word.WdBreakType.wdPageBreak);
                    break;
                case "add_comment":
                    doc.Comments.Add(_app.Selection.Range, a.commentText ?? a.text ?? "Comentario de Gemini");
                    break;
                case "track_changes":
                    doc.TrackRevisions = a.enabled ?? true;
                    break;
                case "insert_picture":
                    InsertPicture(doc, a);
                    break;
                case "set_columns":
                    SetColumns(doc, a.columnsCount ?? 1);
                    break;
                case "add_toc":
                    AddTableOfContents(doc, a);
                    break;
                case "add_hyperlink":
                    AddHyperlink(doc, a);
                    break;
                case "insert_section_break":
                    InsertSectionBreak(doc, a);
                    break;
                default:
                    throw new InvalidOperationException("Acción de Word no permitida: " + a.action);
            }
        }

        private void InsertText(Word.Document doc, string text, string position)
        {
            Word.Range r = GetInsertionRange(doc, position);
            r.InsertAfter(text);
        }

        private Word.Range GetInsertionRange(Word.Document doc, string position)
        {
            string p = (position ?? "cursor").ToLowerInvariant();
            if (p == "start" || p == "inicio") { Word.Range r = doc.Range(0, 0); return r; }
            if (p == "end" || p == "final") { int end = Math.Max(0, doc.Content.End - 1); return doc.Range(end, end); }
            return _app.Selection.Range;
        }

        private static void ReplaceText(Word.Document doc, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("replace_text requiere findText.");
            Word.Range r = doc.Content.Duplicate;
            dynamic find = r.Find;
            find.ClearFormatting();
            find.Replacement.ClearFormatting();
            object replace = (a.replaceAll ?? false) ? Word.WdReplace.wdReplaceAll : Word.WdReplace.wdReplaceOne;
            find.Execute(FindText: a.findText, MatchCase: a.matchCase ?? false, ReplaceWith: a.replacementText ?? "", Replace: replace);
        }

        private static void FormatFind(Word.Document doc, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("format_find requiere findText.");
            Word.Range search = doc.Content.Duplicate;
            int applied = 0;
            while (applied < 100)
            {
                dynamic find = search.Find;
                find.ClearFormatting();
                bool found = find.Execute(FindText: a.findText, MatchCase: a.matchCase ?? false, Forward: true, Wrap: Word.WdFindWrap.wdFindStop);
                if (!found) break;
                ApplyFormat(search, a);
                applied++;
                int next = search.End;
                if (next >= doc.Content.End) break;
                search.SetRange(next, doc.Content.End);
                if (!(a.replaceAll ?? false)) break;
            }
        }

        private static void ApplyFormat(Word.Range r, OfficeAction a)
        {
            if (r == null) return;
            if (!string.IsNullOrWhiteSpace(a.styleName)) { try { dynamic dr = r; dr.Style = a.styleName; } catch { } }
            if (!string.IsNullOrWhiteSpace(a.fontName)) r.Font.Name = a.fontName;
            if (a.fontSize.HasValue && a.fontSize.Value >= 6 && a.fontSize.Value <= 96) r.Font.Size = (float)a.fontSize.Value;
            if (a.bold.HasValue) r.Font.Bold = a.bold.Value ? 1 : 0;
            if (a.italic.HasValue) r.Font.Italic = a.italic.Value ? 1 : 0;
            if (a.underline.HasValue) r.Font.Underline = a.underline.Value ? Word.WdUnderline.wdUnderlineSingle : Word.WdUnderline.wdUnderlineNone;
            if (!string.IsNullOrWhiteSpace(a.fontColorHex)) r.Font.Color = (Word.WdColor)SafeHelpers.ParseRgb(a.fontColorHex, (int)Word.WdColor.wdColorAutomatic);
            if (!string.IsNullOrWhiteSpace(a.alignment))
            {
                string x = a.alignment.ToLowerInvariant();
                if (x == "center" || x == "centrado") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                else if (x == "right" || x == "derecha") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                else if (x == "justify" || x == "justificado") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                else if (x == "left" || x == "izquierda") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            }
            if (a.spaceBeforePt.HasValue) r.ParagraphFormat.SpaceBefore = (float)Math.Max(0, Math.Min(72, a.spaceBeforePt.Value));
            if (a.spaceAfterPt.HasValue) r.ParagraphFormat.SpaceAfter = (float)Math.Max(0, Math.Min(72, a.spaceAfterPt.Value));
            if (!string.IsNullOrWhiteSpace(a.lineSpacing))
            {
                string ls = a.lineSpacing.ToLowerInvariant();
                if (ls.Contains("1.5")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpace1pt5;
                else if (ls.Contains("double") || ls.Contains("doble")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceDouble;
                else if (ls.Contains("single") || ls.Contains("sencillo")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
            }
        }

        private void AddHeading(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a.position);
            string text = (a.text ?? "").TrimEnd() + Environment.NewLine;
            r.InsertAfter(text);
            int start = Math.Max(0, r.End - text.Length);
            Word.Range inserted = doc.Range(start, r.End);
            int level = Math.Max(1, Math.Min(9, a.headingLevel ?? 1));
            try
            {
                Word.WdBuiltinStyle style;
                switch (level)
                {
                    case 1: style = Word.WdBuiltinStyle.wdStyleHeading1; break;
                    case 2: style = Word.WdBuiltinStyle.wdStyleHeading2; break;
                    case 3: style = Word.WdBuiltinStyle.wdStyleHeading3; break;
                    case 4: style = Word.WdBuiltinStyle.wdStyleHeading4; break;
                    case 5: style = Word.WdBuiltinStyle.wdStyleHeading5; break;
                    case 6: style = Word.WdBuiltinStyle.wdStyleHeading6; break;
                    case 7: style = Word.WdBuiltinStyle.wdStyleHeading7; break;
                    case 8: style = Word.WdBuiltinStyle.wdStyleHeading8; break;
                    default: style = Word.WdBuiltinStyle.wdStyleHeading9; break;
                }
                dynamic d = inserted;
                d.Style = style;
            }
            catch { inserted.Font.Bold = 1; inserted.Font.Size = level == 1 ? 18 : (level == 2 ? 15 : 12); }
            ApplyFormat(inserted, a);
        }

        private void AddList(Word.Document doc, OfficeAction a)
        {
            if (a.items == null || a.items.Count == 0) return;
            if (a.items.Count > 200) throw new InvalidOperationException("La lista supera el límite de 200 elementos.");
            Word.Range r = GetInsertionRange(doc, a.position);
            int start = r.Start;
            r.InsertAfter(string.Join(Environment.NewLine, a.items) + Environment.NewLine);
            Word.Range inserted = doc.Range(start, r.End);
            if (string.Equals(a.listType, "numbered", StringComparison.OrdinalIgnoreCase) || string.Equals(a.listType, "numerada", StringComparison.OrdinalIgnoreCase)) inserted.ListFormat.ApplyNumberDefault();
            else inserted.ListFormat.ApplyBulletDefault();
        }

        private void AddTable(Word.Document doc, OfficeAction a)
        {
            if (a.rows == null || a.rows.Count == 0) return;
            int rows = a.rows.Count; int cols = 0;
            foreach (var row in a.rows) if (row != null) cols = Math.Max(cols, row.Count);
            if (rows > 100 || cols > 30 || cols == 0) throw new InvalidOperationException("Tabla demasiado grande o inválida.");
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            Word.Table table = doc.Tables.Add(r, rows, cols);
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    table.Cell(i + 1, j + 1).Range.Text = a.rows[i] != null && j < a.rows[i].Count ? (a.rows[i][j] ?? "") : "";
            try { table.Borders.Enable = 1; table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitContent); } catch { }
        }

        private static void SetMargins(Word.Document doc, OfficeAction a)
        {
            foreach (Word.Section s in doc.Sections)
            {
                if (a.marginTopCm.HasValue) s.PageSetup.TopMargin = SafeHelpers.CmToPoints(Clamp(a.marginTopCm.Value, 0.3, 8));
                if (a.marginBottomCm.HasValue) s.PageSetup.BottomMargin = SafeHelpers.CmToPoints(Clamp(a.marginBottomCm.Value, 0.3, 8));
                if (a.marginLeftCm.HasValue) s.PageSetup.LeftMargin = SafeHelpers.CmToPoints(Clamp(a.marginLeftCm.Value, 0.3, 8));
                if (a.marginRightCm.HasValue) s.PageSetup.RightMargin = SafeHelpers.CmToPoints(Clamp(a.marginRightCm.Value, 0.3, 8));
            }
        }

        private static void SetOrientation(Word.Document doc, string value)
        {
            bool landscape = string.Equals(value, "landscape", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "horizontal", StringComparison.OrdinalIgnoreCase);
            foreach (Word.Section s in doc.Sections) s.PageSetup.Orientation = landscape ? Word.WdOrientation.wdOrientLandscape : Word.WdOrientation.wdOrientPortrait;
        }

        private static void SetPaperSize(Word.Document doc, string value)
        {
            Word.WdPaperSize size = Word.WdPaperSize.wdPaperA4;
            string x = (value ?? "a4").ToLowerInvariant();
            if (x.Contains("letter") || x.Contains("carta")) size = Word.WdPaperSize.wdPaperLetter;
            else if (x.Contains("legal")) size = Word.WdPaperSize.wdPaperLegal;
            foreach (Word.Section s in doc.Sections) s.PageSetup.PaperSize = size;
        }

        private static void AddPageNumbers(Word.Document doc, string position)
        {
            foreach (Word.Section s in doc.Sections)
            {
                Word.HeaderFooter footer = s.Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary];
                Word.WdPageNumberAlignment align = Word.WdPageNumberAlignment.wdAlignPageNumberCenter;
                string p = (position ?? "center").ToLowerInvariant();
                if (p.Contains("right") || p.Contains("derecha")) align = Word.WdPageNumberAlignment.wdAlignPageNumberRight;
                else if (p.Contains("left") || p.Contains("izquierda")) align = Word.WdPageNumberAlignment.wdAlignPageNumberLeft;
                try { footer.PageNumbers.Add(align, true); } catch { }
            }
        }


        private void InsertPicture(Word.Document doc, OfficeAction a)
        {
            PlanSafety.ValidatePicturePath(a.filePath);
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            Word.InlineShape picture = doc.InlineShapes.AddPicture(a.filePath, false, true, r);
            if (!string.IsNullOrWhiteSpace(a.altText)) { try { picture.AlternativeText = a.altText; } catch { } }
            if (a.widthCm.HasValue && a.widthCm.Value > 0 && a.widthCm.Value <= 50)
            {
                try { picture.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoTrue; } catch { }
                picture.Width = SafeHelpers.CmToPoints(a.widthCm.Value);
            }
            if (a.heightCm.HasValue && a.heightCm.Value > 0 && a.heightCm.Value <= 50 && !a.widthCm.HasValue)
            {
                try { picture.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoTrue; } catch { }
                picture.Height = SafeHelpers.CmToPoints(a.heightCm.Value);
            }
            string wrap = (a.target ?? "").ToLowerInvariant();
            if (!string.IsNullOrWhiteSpace(wrap) && !wrap.Contains("inline"))
            {
                try
                {
                    Word.Shape shape = picture.ConvertToShape();
                    if (wrap.Contains("square") || wrap.Contains("cuadr")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;
                    else if (wrap.Contains("tight") || wrap.Contains("estrech")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapTight;
                    else if (wrap.Contains("behind") || wrap.Contains("detrás") || wrap.Contains("detras")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapBehind;
                    else if (wrap.Contains("front") || wrap.Contains("delante")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapFront;
                }
                catch { }
            }
        }

        private static void SetColumns(Word.Document doc, int count)
        {
            count = Math.Max(1, Math.Min(4, count));
            foreach (Word.Section section in doc.Sections)
            {
                try { section.PageSetup.TextColumns.SetCount(count); } catch { }
            }
        }

        private void AddTableOfContents(Word.Document doc, OfficeAction a)
        {
            int min = Math.Max(1, Math.Min(9, a.minLevel ?? 1));
            int max = Math.Max(min, Math.Min(9, a.maxLevel ?? 3));
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            try { doc.TablesOfContents.Add(r, true, min, max); }
            catch (Exception ex) { throw new InvalidOperationException("No se pudo crear la tabla de contenido. Asegúrate de usar estilos Título 1/2/3. " + ex.Message); }
        }

        private void AddHyperlink(Word.Document doc, OfficeAction a)
        {
            PlanSafety.ValidateHttpUrl(a.url);
            Word.Range r = GetInsertionRange(doc, a.position);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            string label = string.IsNullOrWhiteSpace(a.text) ? a.url : a.text;
            doc.Hyperlinks.Add(r, a.url, Type.Missing, string.IsNullOrWhiteSpace(a.altText) ? Type.Missing : (object)a.altText, label, Type.Missing);
        }

        private void InsertSectionBreak(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a.position);
            string kind = (a.breakType ?? "next_page").ToLowerInvariant();
            Word.WdBreakType type = (kind.Contains("continuous") || kind.Contains("continu")) ? Word.WdBreakType.wdSectionBreakContinuous : Word.WdBreakType.wdSectionBreakNextPage;
            r.InsertBreak(type);
        }
        private static double Clamp(double v, double min, double max) { return Math.Max(min, Math.Min(max, v)); }

        public void UndoLast()
        {
            try { dynamic app = _app; app.Undo(1); }
            catch { throw new InvalidOperationException("Word no pudo deshacer automáticamente el último cambio de IA."); }
        }

        public void WipeTemporaryData() { SafeHelpers.DeleteIfExists(_lastTempFile); _lastTempFile = null; }
    }
}
