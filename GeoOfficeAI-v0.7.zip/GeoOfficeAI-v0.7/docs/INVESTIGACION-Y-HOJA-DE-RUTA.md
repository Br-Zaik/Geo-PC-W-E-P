# Investigación técnica y hoja de ruta — Geo Office AI v0.5

## Conclusión

Sí es viable construir un “Copilot propio” útil dentro de Word, Excel y PowerPoint de escritorio usando VSTO/C#/.NET Framework/Interop y Gemini. No es realista afirmar que tendrá literalmente todas las funciones de Office en todas las versiones. La arquitectura correcta es un núcleo compartido que interpreta una orden en un plan de acciones seguras y tres adaptadores especializados que ejecutan esas acciones en Word, Excel o PowerPoint.

## Arquitectura recomendada

1. **Panel VSTO por aplicación**: Word, Excel y PowerPoint mantienen su propio Task Pane y Ribbon mínimo.
2. **Broker local compartido**: gestiona OAuth de Google, Gemini, búsqueda web, sesión temporal y coordinación.
3. **Planificador Gemini**: convierte lenguaje natural en un plan JSON de acciones permitidas.
4. **PlanSafety**: valida lista blanca, tamaños, URLs, rutas locales y fórmulas antes de ejecutar.
5. **Adaptadores Office**: traducen cada acción a Word/Excel/PowerPoint Interop.
6. **Rollback/Undo**: Word usa UndoRecord; Excel y PowerPoint mantienen copia temporal porque el Undo nativo no es fiable tras automatización programática.

## Por qué no darle “control libre” a Gemini

Gemini no debe generar VBA, PowerShell, CMD ni C# y ejecutarlo. Eso sería más potente pero también mucho más inseguro y difícil de recuperar. La estrategia profesional es exponer funciones pequeñas y conocidas, permitir que Gemini combine muchas en un plan y volver a validar el plan localmente.

## Word — mapa de capacidades

### P0 implementado/fortalecido en v0.5
- Insertar/reemplazar texto y selección.
- Formato de selección y documento completo.
- Estilos/títulos, listas y tablas.
- Márgenes, orientación, papel, columnas y saltos de sección.
- Encabezados, pies y números de página.
- Tabla de contenido automática basada en estilos.
- Hipervínculos para fuentes web.
- Comentarios y Track Changes.
- Imágenes locales con tamaño, texto alternativo y ajuste de texto.

### P1 recomendado
- Campos avanzados, captions y referencias cruzadas.
- Bibliografía/citas nativas de Word cuando sea estable entre versiones.
- Secciones con encabezado/pie “primera página” y pares/impares.
- Tablas avanzadas: combinación, sombreado, estilos, repetición de encabezado.
- Exportación controlada a PDF y DOCX con confirmación de destino.

### P2
- Automatización de características muy específicas o dependientes de versión, detrás de comprobaciones de capacidad.

## Excel — mapa de capacidades

### P0 implementado/fortalecido en v0.5
- Celdas/rangos y bloques de datos.
- Fórmulas seguras.
- Tablas de Excel (ListObjects) con estilo.
- Columnas calculadas: una fórmula de tabla se propaga y las nuevas filas heredan el cálculo.
- Formato/AutoFit, formato condicional y validación de datos.
- Filtros y ordenamiento.
- Gráficos comunes.
- Tablas dinámicas básicas.
- Nombres definidos.
- Fila de totales y cálculo automático/manual.

### P1 recomendado
- PivotTables con filtros/columnas/campos de página más completos.
- Slicers solo cuando la versión lo soporte.
- Series de gráficos, ejes, etiquetas, leyendas y estilos avanzados.
- Importación de CSV/TXT con vista previa y confirmación.
- Limpieza de datos segura (duplicados, espacios, tipos, fechas) mediante acciones explícitas.
- Protección de hoja/rangos sin guardar contraseñas del usuario.

### P2
- Power Query/Model/Data Types y otras funciones modernas, habilitadas solo si la versión de Excel las soporta.

## PowerPoint — mapa de capacidades

### P0 implementado/fortalecido en v0.5
- Crear/duplicar diapositivas y cambiar layout.
- Títulos, textos, tablas, formas, fondos e imágenes locales.
- Espacios reservados para imágenes cuando no hay archivo local.
- Aplicar tema local THMX/POT/POTX.
- Estilo tipográfico global consistente.
- Alinear/distribuir formas.
- Notas del presentador.
- Transiciones clásicas discretas.
- Animaciones básicas sobre formas o texto identificado.

### P1 recomendado
- Gráficos PowerPoint/Excel embebidos de forma controlada.
- SmartArt solo si la automatización demuestra ser estable en versiones objetivo.
- Rejilla/composición automática más inteligente para 16:9 y 4:3.
- Patrones de diapositivas y variantes de tema con comprobación de versión.
- Más controles de animación: duración, retraso y secuencia.

### P2
- Funciones modernas exclusivas de Microsoft 365/Office recientes, sin hacerlas requisito para Office antiguo.

## Gemini e Internet

- Gemini debe planificar con salida JSON estructurada; la aplicación ejecuta las acciones, no el modelo.
- Cuando el usuario diga “busca en Internet”, “investiga”, “con fuentes”, “actualizado”, etc., se activa Google Search grounding.
- Se conservan título/URL de fuentes en el plan; Word puede crear hipervínculos y los otros hosts pueden insertar una sección de fuentes como texto si se solicita.
- Modelo base de esta versión: `gemini-2.5-flash`, buscando equilibrio entre capacidad, velocidad y disponibilidad de nivel gratuito.
- Google AI Plus es una suscripción de productos de consumidor y no debe tratarse como saldo de Gemini API.
- Generación de imágenes por API permanece desactivada; si se pide una imagen, el asistente produce un prompt profesional y puede insertar después un archivo local.

## Ejemplos que v0.5 debe poder planificar

### PowerPoint
“Crea una presentación profesional de 6 diapositivas sobre EPP en minería, con portada, poco texto, diseño consistente, transición Fade y espacios para imágenes.”

Plan esperado: crear slides/layouts → títulos/textos → placeholders → estilo profesional → alineación → transición discreta → notas si se piden.

### Excel
“Convierte A1:D30 en una tabla. Agrega una columna Total = Cantidad*Precio que siga funcionando cuando agregue filas, resalta totales altos y crea un gráfico.”

Plan esperado: create_table → create_calculated_column con referencias estructuradas → conditional_format → show_totals_row → create_chart → autofit.

### Word
“Haz un informe profesional de una página sobre seguridad minera, investiga información reciente y cita las fuentes.”

Plan esperado: Google Search grounding → redactar contenido breve → format_document → set_margins → add_heading + texto/listas → hipervínculos de fuentes → numeración si se solicita.

## Seguridad mínima obligatoria

- Lista blanca de acciones y validación doble (broker/host).
- Sin macros, VBA, scripts, CMD/PowerShell ni ejecución arbitraria.
- Fórmulas con patrones peligrosos bloqueadas.
- Archivos locales validados por extensión/tamaño.
- URLs solo HTTP/HTTPS.
- OAuth Desktop con PKCE/state/loopback.
- Tokens solo en memoria y limpieza/revocación al cerrar sesión/panel según la política actual.
- Named pipe limitado al usuario Windows.
- Las 3 claves locales son solo una barrera sencilla; sin servidor no hay licencia revocable fuerte.

## Pruebas requeridas antes de llamarlo “final”

1. Compilar Release en Windows/Visual Studio con workload VSTO.
2. Instalar con Inno Setup y probar registro x86/x64.
3. Probar login Google real y revocación.
4. Matriz mínima: Office 2010/2013 x86 + Office 2016/2021/Microsoft 365 x64.
5. Casos de documento vacío, grande, solo lectura/protegido y formato antiguo `.doc/.xls/.ppt`.
6. Cortes de Internet, timeout Gemini, JSON inválido, acción bloqueada y cancelación a mitad.
7. Verificar rollback/Undo y que no se modifique contenido no pedido.
8. Verificar ejemplos profesionales de Word/Excel/PowerPoint de extremo a extremo.

## Qué sigue faltando después de v0.5

v0.5 amplía mucho el conjunto de herramientas, pero todavía no equivale a Microsoft Copilot completo. Faltan especialmente referencias/citas nativas avanzadas en Word, Excel analítico más profundo, composición/temas avanzados de PowerPoint y, sobre todo, **compilación y pruebas reales en Windows Office**. La prioridad siguiente no debe ser añadir cientos de acciones sin probar: primero debe validarse P0 de extremo a extremo y después ampliar P1 por bloques.
