# Privacidad y seguridad de sesión

- Geo Office AI no persiste access tokens ni refresh tokens de Google en archivos o registro.
- El chat vive solo en memoria de la interfaz.
- El broker local mantiene la sesión en memoria mientras se usa.
- La X del panel provoca limpieza global de esa sesión compartida; Word/Excel/PowerPoint restantes detectan la desconexión.
- Al cerrar Office también se solicita la limpieza.
- Se intenta revocar el token ante Google y, en cualquier caso, primero se elimina de memoria.
- Se borran copias/archivos temporales creados por Geo Office AI.
- No se borran ni modifican automáticamente los documentos guardados por el usuario.
- No se borran cookies ni sesiones generales del navegador.
- El named pipe del broker se limita al SID del usuario actual de Windows.
- El modelo solo puede solicitar acciones incluidas en una lista blanca; el host vuelve a validarlas antes de tocar Office.
