# Compatibilidad prevista — Geo Office AI v0.5

Objetivo: Office de escritorio en Windows mediante VSTO + .NET Framework 4.8 + Office Interop con tipos embebidos.

- Word / Excel / PowerPoint 2010: objetivo compatible si no se invocan APIs exclusivas de versiones posteriores; requiere prueba física.
- 2013, 2016, 2019, 2021 y Microsoft 365 de escritorio: objetivo compatible, igualmente sujeto a prueba real.
- Office de 32 y 64 bits: el instalador registra ambas vistas del registro en Windows x64.
- No compatible con Word/Excel/PowerPoint Web, Android, iPhone o macOS mediante este mismo VSTO.

## Estrategia de compatibilidad

El núcleo usa acciones propias (`create_table`, `set_transition`, etc.) y cada adaptador las traduce a Interop. Las funciones nuevas deben usar primero APIs presentes desde Office 2010/2013. Una capacidad moderna que no exista en una versión antigua debe quedar detrás de una comprobación de capacidad y no romper el resto del complemento.

Se evitan deliberadamente características modernas como Morph como requisito básico. Para PowerPoint se usan transiciones y animaciones clásicas del Object Model; para Excel se priorizan ListObjects, fórmulas, validación, formato condicional y PivotTables; para Word, Range/Styles/Sections/Tables/Fields/Hyperlinks.

Esta es una matriz de **objetivo**, no una afirmación de certificación. Antes de una versión final deben probarse como mínimo Office 2010/2013 de 32 bits y Office 2016/2021/Microsoft 365 de 64 bits en Windows.
