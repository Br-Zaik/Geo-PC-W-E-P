# Instalación y uso

## Claves de instalación

El instalador acepta tres claves privadas. **No se incluyen en el código fuente ni en la documentación del paquete**; se entregan por separado al propietario. El instalador conserva únicamente hashes SHA-256 y no guarda la clave introducida.

## Uso final esperado

1. Ejecutar `GeoOfficeAI-Setup-v0.5.exe` como administrador.
2. Introducir una clave.
3. Abrir Word, Excel o PowerPoint de escritorio.
4. El panel `Asistente IA · Gemini` aparece a la derecha.
5. Pulsar `Iniciar sesión con Google`; autorizar en el navegador.
6. Escribir directamente lo que se quiere hacer.
7. Cerrar la X del panel cuando se termine. Esa acción limpia la sesión del complemento.
8. Para volver a usarlo, abrir la pestaña `Asistente IA` de la cinta y pulsar `Abrir Asistente IA`; será necesario iniciar sesión otra vez.

## Qué permanece después de cerrar

- El complemento sigue instalado.
- Los documentos/hojas/presentaciones que el usuario guardó permanecen.
- La sesión de Geo Office AI, chat y temporales no deben permanecer.
- La sesión general de Google del navegador no se modifica.
