# v0.5

- Investigación técnica enfocada en documentación oficial de Microsoft Office/VSTO y Google Gemini.
- Word: formato de documento completo, columnas, tabla de contenido, hipervínculos/fuentes, saltos de sección e imágenes con ajuste de texto/alt text.
- Excel: tablas profesionales con estilo, columnas calculadas autoexpandibles, formato condicional, validación, filtros, ordenamiento, tablas dinámicas, nombres definidos, fila de totales y modo de cálculo.
- PowerPoint: layouts, temas locales, transiciones, animaciones básicas, alineación/distribución, notas del presentador, espacios para imágenes y estilo profesional global.
- Planificador Gemini reforzado para componer múltiples acciones coordinadas en una sola petición profesional.
- Google Search grounding ampliado para peticiones con fuentes/citas/información reciente.
- Lista blanca ampliada y validaciones adicionales de URL, archivos de tema y fórmulas.
- Límite de acciones por plan ampliado de 80 a 160 para trabajos complejos, conservando presupuesto de texto y validación antes de tocar Office.
- Corregidos puntos de interoperabilidad en Excel/PowerPoint para reducir riesgo de compilación con Office Interop 15.0.

# v0.4

- Proyecto corregido a **Word + Excel + PowerPoint**, no solo Word.
- Eliminados OpenAI/Claude/Ollama y configuración multi-proveedor.
- Solo Gemini mediante OAuth de Google de escritorio.
- Panel lateral tipo chat en las tres aplicaciones.
- Botón único en Ribbon para reabrir el panel tras cerrar la X.
- Tokens OAuth solo en memoria; PKCE + state + loopback local.
- Limpieza/revocación de sesión, chat y temporales al cerrar panel/Office.
- Named pipe local restringido al usuario de Windows.
- Motor de acciones separado para Word, Excel y PowerPoint.
- Validación previa por lista blanca y límites de seguridad.
- Google Search grounding cuando el usuario pide explícitamente buscar/investigar en Internet.
- Sin generación de imágenes por API; crea prompts para Gemini web.
- Inserción de imágenes locales permitida y validada.
- 3 claves de instalación conservadas como hashes SHA-256.
- Workflow Windows/GitHub Actions + instalador Inno Setup.

## v0.6
- Corrige el inicio de sesión cuando VSTO carga el complemento desde su caché y `GeoOfficeAI.Broker.exe` no está junto a `GeoOfficeAI.Shared.dll`.
- Instala un broker compartido en `{app}\Broker` y guarda `InstallDir` en el registro.
- Añade búsqueda de respaldo en Program Files/Program Files (x86) y carpetas Word/Excel/PowerPoint.


## v0.7
- Cambiado el modelo de Gemini de `gemini-2.5-flash` a `gemini-3.6-flash`, modelo estable actual disponible para proyectos nuevos.
- Eliminados parámetros de muestreo `temperature` del planificador para evitar depender de parámetros deprecados en Gemini 3.6.
- Instalador actualizado a `GeoOfficeAI-Setup-v0.7.exe`.
