using System;
using System.IO;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Broker
{
    internal sealed class GoogleOAuthConfig
    {
        public string ClientId { get; private set; }
        public string ClientSecret { get; private set; }
        public string ProjectId { get; private set; }
        public string AuthUri { get; private set; }
        public string TokenUri { get; private set; }

        private sealed class Root { public Installed installed { get; set; } }
        private sealed class Installed
        {
            public string client_id { get; set; }
            public string client_secret { get; set; }
            public string project_id { get; set; }
            public string auth_uri { get; set; }
            public string token_uri { get; set; }
        }

        public static GoogleOAuthConfig Load()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "google_oauth.json");
            if (!File.Exists(path))
                throw new InvalidOperationException("Falta google_oauth.json. Debe añadirse el cliente OAuth de Google antes de compilar el instalador final.");

            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            Root root = json.Deserialize<Root>(File.ReadAllText(path));
            if (root == null || root.installed == null || string.IsNullOrWhiteSpace(root.installed.client_id) || string.IsNullOrWhiteSpace(root.installed.project_id))
                throw new InvalidOperationException("google_oauth.json no contiene un cliente OAuth de tipo Desktop válido.");

            if (root.installed.client_id.Contains("REEMPLAZAR"))
                throw new InvalidOperationException("El cliente OAuth de Google todavía es una plantilla. Configúralo antes de la compilación final.");

            return new GoogleOAuthConfig
            {
                ClientId = root.installed.client_id,
                ClientSecret = root.installed.client_secret ?? "",
                ProjectId = root.installed.project_id,
                AuthUri = string.IsNullOrWhiteSpace(root.installed.auth_uri) ? "https://accounts.google.com/o/oauth2/v2/auth" : root.installed.auth_uri,
                TokenUri = string.IsNullOrWhiteSpace(root.installed.token_uri) ? "https://oauth2.googleapis.com/token" : root.installed.token_uri
            };
        }
    }
}
