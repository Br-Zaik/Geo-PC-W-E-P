using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Broker
{
    internal sealed class OAuthSession
    {
        private const string Scope = "https://www.googleapis.com/auth/generative-language.retriever";
        private readonly object _gate = new object();
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        private string _accessToken;
        private string _refreshToken;
        private DateTime _expiresUtc;
        private string _displayName;
        private GoogleOAuthConfig _config;

        public bool IsConnected
        {
            get { lock (_gate) return !string.IsNullOrWhiteSpace(_accessToken) && DateTime.UtcNow < _expiresUtc.AddMinutes(-1); }
        }

        public string DisplayName { get { lock (_gate) return _displayName ?? "Google"; } }
        public string ProjectId { get { EnsureConfig(); return _config.ProjectId; } }

        public async Task LoginAsync(CancellationToken token)
        {
            EnsureConfig();
            int port = GetFreePort();
            string redirectUri = "http://127.0.0.1:" + port + "/";
            string state = Base64Url(RandomBytes(24));
            string verifier = Base64Url(RandomBytes(48));
            string challenge;
            using (var sha = SHA256.Create()) challenge = Base64Url(sha.ComputeHash(Encoding.ASCII.GetBytes(verifier)));

            string authUrl = _config.AuthUri + "?" + BuildQuery(new Dictionary<string, string>
            {
                { "client_id", _config.ClientId },
                { "redirect_uri", redirectUri },
                { "response_type", "code" },
                { "scope", Scope },
                { "state", state },
                { "code_challenge", challenge },
                { "code_challenge_method", "S256" },
                { "access_type", "offline" },
                { "prompt", "consent select_account" }
            });

            var listener = new TcpListener(IPAddress.Loopback, port);
            try
            {
                listener.Start(1);
                Process.Start(new ProcessStartInfo { FileName = authUrl, UseShellExecute = true });
                string code = await WaitForAuthorizationCodeAsync(listener, state, token);
                await ExchangeCodeAsync(code, verifier, redirectUri, token);
            }
            finally
            {
                try { listener.Stop(); } catch { }
            }
        }

        public async Task<string> GetAccessTokenAsync(CancellationToken token)
        {
            EnsureConfig();
            string tokenValue;
            string refresh;
            DateTime expiry;
            lock (_gate) { tokenValue = _accessToken; refresh = _refreshToken; expiry = _expiresUtc; }
            if (!string.IsNullOrWhiteSpace(tokenValue) && DateTime.UtcNow < expiry.AddMinutes(-2)) return tokenValue;
            if (!string.IsNullOrWhiteSpace(refresh))
            {
                await RefreshAsync(refresh, token);
                lock (_gate) return _accessToken;
            }
            throw new InvalidOperationException("La sesión de Google terminó. Vuelve a iniciar sesión.");
        }

        public async Task WipeAsync()
        {
            string token;
            lock (_gate)
            {
                token = _accessToken;
                _accessToken = null;
                _refreshToken = null;
                _displayName = null;
                _expiresUtc = DateTime.MinValue;
            }

            if (!string.IsNullOrWhiteSpace(token))
            {
                try
                {
                    using (var http = new HttpClient { Timeout = TimeSpan.FromSeconds(8) })
                    using (var content = new FormUrlEncodedContent(new Dictionary<string, string> { { "token", token } }))
                        await http.PostAsync("https://oauth2.googleapis.com/revoke", content);
                }
                catch { }
            }
        }

        private async Task ExchangeCodeAsync(string code, string verifier, string redirectUri, CancellationToken token)
        {
            var form = new Dictionary<string, string>
            {
                { "code", code }, { "client_id", _config.ClientId }, { "redirect_uri", redirectUri },
                { "grant_type", "authorization_code" }, { "code_verifier", verifier }
            };
            if (!string.IsNullOrWhiteSpace(_config.ClientSecret)) form["client_secret"] = _config.ClientSecret;

            using (var http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) })
            using (var response = await http.PostAsync(_config.TokenUri, new FormUrlEncodedContent(form), token))
            {
                string raw = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode) throw new InvalidOperationException("Google OAuth respondió " + (int)response.StatusCode + ": " + ExtractError(raw));
                var root = _json.DeserializeObject(raw) as Dictionary<string, object>;
                string access = GetString(root, "access_token");
                string refresh = GetString(root, "refresh_token");
                int expires = GetInt(root, "expires_in", 3600);
                if (string.IsNullOrWhiteSpace(access)) throw new InvalidOperationException("Google no devolvió un access_token.");
                lock (_gate)
                {
                    _accessToken = access;
                    _refreshToken = refresh;
                    _expiresUtc = DateTime.UtcNow.AddSeconds(Math.Max(60, expires));
                    _displayName = "Cuenta Google conectada";
                }
            }
        }

        private async Task RefreshAsync(string refresh, CancellationToken token)
        {
            var form = new Dictionary<string, string>
            {
                { "client_id", _config.ClientId }, { "refresh_token", refresh }, { "grant_type", "refresh_token" }
            };
            if (!string.IsNullOrWhiteSpace(_config.ClientSecret)) form["client_secret"] = _config.ClientSecret;
            using (var http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) })
            using (var response = await http.PostAsync(_config.TokenUri, new FormUrlEncodedContent(form), token))
            {
                string raw = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode) throw new InvalidOperationException("No se pudo renovar la sesión de Google: " + ExtractError(raw));
                var root = _json.DeserializeObject(raw) as Dictionary<string, object>;
                string access = GetString(root, "access_token");
                int expires = GetInt(root, "expires_in", 3600);
                if (string.IsNullOrWhiteSpace(access)) throw new InvalidOperationException("Google no devolvió access_token al renovar.");
                lock (_gate) { _accessToken = access; _expiresUtc = DateTime.UtcNow.AddSeconds(Math.Max(60, expires)); }
            }
        }

        private static async Task<string> WaitForAuthorizationCodeAsync(TcpListener listener, string expectedState, CancellationToken token)
        {
            using (token.Register(() => { try { listener.Stop(); } catch { } }))
            using (TcpClient client = await listener.AcceptTcpClientAsync())
            using (NetworkStream stream = client.GetStream())
            using (var reader = new StreamReader(stream, Encoding.ASCII, false, 4096, true))
            {
                string requestLine = await reader.ReadLineAsync();
                if (string.IsNullOrWhiteSpace(requestLine)) throw new InvalidOperationException("Respuesta OAuth vacía.");
                string[] parts = requestLine.Split(' ');
                if (parts.Length < 2) throw new InvalidOperationException("Respuesta OAuth inválida.");
                Uri uri = new Uri("http://127.0.0.1" + parts[1]);
                var query = HttpUtility.ParseQueryString(uri.Query);
                string state = query["state"];
                string code = query["code"];
                string error = query["error"];

                string html;
                if (!string.IsNullOrWhiteSpace(error)) html = "<html><body><h2>Inicio de sesión cancelado</h2><p>Puedes cerrar esta ventana.</p></body></html>";
                else html = "<html><body><h2>Gemini conectado</h2><p>Ya puedes volver a Word, Excel o PowerPoint y cerrar esta ventana.</p></body></html>";
                byte[] body = Encoding.UTF8.GetBytes(html);
                string headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + body.Length + "\r\nConnection: close\r\n\r\n";
                byte[] head = Encoding.ASCII.GetBytes(headers);
                await stream.WriteAsync(head, 0, head.Length, token);
                await stream.WriteAsync(body, 0, body.Length, token);

                if (!string.IsNullOrWhiteSpace(error)) throw new InvalidOperationException("Google canceló la autorización: " + error);
                if (!string.Equals(state, expectedState, StringComparison.Ordinal)) throw new InvalidOperationException("El estado OAuth no coincide; operación cancelada por seguridad.");
                if (string.IsNullOrWhiteSpace(code)) throw new InvalidOperationException("Google no devolvió código de autorización.");
                return code;
            }
        }

        private void EnsureConfig() { if (_config == null) _config = GoogleOAuthConfig.Load(); }
        private static int GetFreePort() { var l = new TcpListener(IPAddress.Loopback, 0); l.Start(); int p = ((IPEndPoint)l.LocalEndpoint).Port; l.Stop(); return p; }
        private static byte[] RandomBytes(int count) { byte[] b = new byte[count]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(b); return b; }
        private static string Base64Url(byte[] bytes) { return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_'); }
        private static string BuildQuery(Dictionary<string, string> values)
        {
            var sb = new StringBuilder();
            foreach (var kv in values)
            {
                if (sb.Length > 0) sb.Append('&');
                sb.Append(Uri.EscapeDataString(kv.Key)).Append('=').Append(Uri.EscapeDataString(kv.Value ?? ""));
            }
            return sb.ToString();
        }
        private static string GetString(Dictionary<string, object> d, string key) { object v; return d != null && d.TryGetValue(key, out v) && v != null ? Convert.ToString(v) : null; }
        private static int GetInt(Dictionary<string, object> d, string key, int fallback) { object v; int n; return d != null && d.TryGetValue(key, out v) && int.TryParse(Convert.ToString(v), out n) ? n : fallback; }
        private static string ExtractError(string raw)
        {
            try
            {
                var json = new JavaScriptSerializer();
                var root = json.DeserializeObject(raw) as Dictionary<string, object>;
                object e;
                if (root != null && root.TryGetValue("error", out e))
                {
                    var ed = e as Dictionary<string, object>;
                    string msg = GetString(ed, "message");
                    if (!string.IsNullOrWhiteSpace(msg)) return msg;
                    return Convert.ToString(e);
                }
            }
            catch { }
            return raw == null ? "Error desconocido" : raw.Substring(0, Math.Min(raw.Length, 500));
        }
    }
}
