using GeoOfficeAI.Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Broker
{
    internal sealed class GeminiPlanner
    {
        private const string Model = "gemini-3.6-flash";
        private readonly OAuthSession _session;
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };

        public GeminiPlanner(OAuthSession session) { _session = session; }

        public async Task<string> CreatePlanJsonAsync(string host, string instruction, string context, CancellationToken token)
        {
            string accessToken = await _session.GetAccessTokenAsync(token);
            string research = "";
            List<WebSource> sources = new List<WebSource>();
            if (ShouldUseWebSearch(instruction))
            {
                var researchResult = await ResearchAsync(accessToken, instruction, token);
                research = researchResult.Item1;
                sources = researchResult.Item2;
            }

            string prompt = BuildPlannerPrompt(host, instruction, context, research, sources);
            var body = new Dictionary<string, object>
            {
                { "contents", new object[] { new Dictionary<string, object> { { "role", "user" }, { "parts", new object[] { new Dictionary<string, object> { { "text", prompt } } } } } } },
                { "generationConfig", new Dictionary<string, object> {
                    { "responseMimeType", "application/json" },
                    { "responseJsonSchema", BuildPlanSchema() },
                    { "maxOutputTokens", 8192 }
                } }
            };
            string raw = await PostGenerateContentAsync(accessToken, body, token);
            string text = ExtractCandidateText(raw);
            OfficePlan plan = PlanParser.Parse(text);
            if (sources.Count > 0)
            {
                if (plan.sources == null) plan.sources = new List<WebSource>();
                foreach (var s in sources)
                {
                    bool exists = false;
                    foreach (var p in plan.sources) if (p != null && string.Equals(p.url, s.url, StringComparison.OrdinalIgnoreCase)) { exists = true; break; }
                    if (!exists) plan.sources.Add(s);
                }
            }
            return _json.Serialize(plan);
        }


        private static Dictionary<string, object> BuildPlanSchema()
        {
            var sourceSchema = new Dictionary<string, object>
            {
                { "type", "object" },
                { "properties", new Dictionary<string, object>
                    {
                        { "title", new Dictionary<string, object> { { "type", "string" } } },
                        { "url", new Dictionary<string, object> { { "type", "string" } } }
                    }
                },
                { "required", new object[] { "url" } }
            };
            var actionSchema = new Dictionary<string, object>
            {
                { "type", "object" },
                { "properties", new Dictionary<string, object>
                    {
                        { "action", new Dictionary<string, object> { { "type", "string" } } }
                    }
                },
                { "required", new object[] { "action" } }
            };
            return new Dictionary<string, object>
            {
                { "type", "object" },
                { "properties", new Dictionary<string, object>
                    {
                        { "message", new Dictionary<string, object> { { "type", "string" } } },
                        { "actions", new Dictionary<string, object> { { "type", "array" }, { "maxItems", 160 }, { "items", actionSchema } } },
                        { "sources", new Dictionary<string, object> { { "type", "array" }, { "maxItems", 12 }, { "items", sourceSchema } } }
                    }
                },
                { "required", new object[] { "message", "actions", "sources" } }
            };
        }

        private async Task<Tuple<string, List<WebSource>>> ResearchAsync(string accessToken, string instruction, CancellationToken token)
        {
            string researchPrompt = "Busca en Internet solo la información necesaria para esta petición de ofimática. Responde en español, de forma breve, factual y lista para usar en un documento. No inventes datos. Petición: " + instruction;
            var body = new Dictionary<string, object>
            {
                { "contents", new object[] { new Dictionary<string, object> { { "role", "user" }, { "parts", new object[] { new Dictionary<string, object> { { "text", researchPrompt } } } } } } },
                { "tools", new object[] { new Dictionary<string, object> { { "google_search", new Dictionary<string, object>() } } } },
                { "generationConfig", new Dictionary<string, object>() }
            };
            string raw = await PostGenerateContentAsync(accessToken, body, token);
            string text = ExtractCandidateText(raw);
            return Tuple.Create(text, ExtractSources(raw));
        }

        private async Task<string> PostGenerateContentAsync(string accessToken, Dictionary<string, object> body, CancellationToken token)
        {
            string endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + Model + ":generateContent";
            using (var http = new HttpClient { Timeout = TimeSpan.FromSeconds(90) })
            using (var req = new HttpRequestMessage(HttpMethod.Post, endpoint))
            {
                req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                req.Headers.Add("x-goog-user-project", _session.ProjectId);
                req.Content = new StringContent(_json.Serialize(body), Encoding.UTF8, "application/json");
                using (var res = await http.SendAsync(req, token))
                {
                    string raw = await res.Content.ReadAsStringAsync();
                    if (!res.IsSuccessStatusCode) throw new InvalidOperationException("Gemini respondió " + (int)res.StatusCode + ": " + ExtractError(raw));
                    return raw;
                }
            }
        }

        private static bool ShouldUseWebSearch(string instruction)
        {
            if (string.IsNullOrWhiteSpace(instruction)) return false;
            string x = instruction.ToLowerInvariant();
            string[] triggers = { "busca en internet", "buscar en internet", "busca por internet", "buscar por internet", "busca en la web", "buscar en la web", "investiga", "actualizado", "actualiza con internet", "según internet", "con fuentes", "cita fuentes", "citas web", "información reciente", "informacion reciente" };
            foreach (var t in triggers) if (x.Contains(t)) return true;
            return false;
        }

        private static string BuildPlannerPrompt(string host, string instruction, string context, string research, List<WebSource> sources)
        {
            string actions = HostActions(host);
            var sb = new StringBuilder();
            sb.AppendLine("Eres el planificador seguro de Geo Office AI para Microsoft " + host + ".");
            sb.AppendLine("Convierte la petición del usuario en un JSON ESTRICTO con esta forma: {\"message\":\"respuesta breve\",\"actions\":[...],\"sources\":[{\"title\":\"...\",\"url\":\"...\"}]}.");
            sb.AppendLine("No devuelvas markdown, comentarios, macros, VBA, PowerShell, scripts ni código ejecutable.");
            sb.AppendLine("Usa SOLO acciones de la lista permitida. Si no hace falta modificar el archivo, devuelve actions vacío y responde en message.");
            sb.AppendLine("No existe generación de imágenes en esta aplicación. Si el usuario pide una imagen, crea en message un prompt excelente para usarlo en Gemini web. No finjas que generaste una imagen.");
            sb.AppendLine("No borres hojas, diapositivas ni archivos. No uses macros, código, conexiones externas, vínculos de libro ni fórmulas peligrosas.");
            sb.AppendLine("Piensa como un especialista de ofimática: una petición puede requerir MUCHAS acciones coordinadas. Devuelve el plan completo en el orden correcto, pero no cambies elementos ajenos a la petición.");
            sb.AppendLine("Si el usuario pide un trabajo 'profesional', no basta con escribir texto: usa también estructura, jerarquía, espaciado, estilos, tablas/gráficos cuando aporten valor y un diseño consistente.");
            sb.AppendLine("WORD: para informes, usa format_document para un estilo base coherente y luego títulos/estilos, párrafos claros, márgenes apropiados, tablas si ayudan y fuentes web citadas cuando haya investigación. Para una página, evita excederte en contenido.");
            sb.AppendLine("EXCEL: cuando el usuario quiera cálculos que se actualicen al agregar filas, prefiere una Tabla de Excel (ListObject) + create_calculated_column con referencias estructuradas. Usa fórmulas en sintaxis de Excel compatible con .Formula (nombres de funciones en inglés). Agrega validación, formato condicional, orden/filtro o gráfico solo si ayudan.");
            sb.AppendLine("POWERPOINT: para una presentación profesional, mantén poco texto por diapositiva, jerarquía visual consistente, tamaños legibles, alineación, espacios en blanco y transiciones discretas. Si faltan imágenes, crea add_image_placeholder en vez de inventar una ruta. Evita animaciones excesivas.");
            sb.AppendLine("Si hay INFORMACIÓN OBTENIDA DE GOOGLE SEARCH, úsala para contenido factual y conserva las URLs de FUENTES DISPONIBLES. En Word puedes insertar una sección Fuentes con add_hyperlink; en PowerPoint/Excel puedes incluir URLs como texto si el usuario quiere fuentes.");
            sb.AppendLine("Acciones permitidas para " + host + ":\n" + actions);
            sb.AppendLine("PETICIÓN DEL USUARIO:\n" + instruction);
            if (!string.IsNullOrWhiteSpace(research)) sb.AppendLine("INFORMACIÓN OBTENIDA DE GOOGLE SEARCH:\n" + research);
            if (sources != null && sources.Count > 0)
            {
                sb.AppendLine("FUENTES DISPONIBLES:");
                foreach (var s in sources) sb.AppendLine("- " + (s.title ?? "Fuente") + " | " + s.url);
            }
            sb.AppendLine("CONTEXTO ACTUAL DE " + host.ToUpperInvariant() + ":\n" + context);
            sb.AppendLine("Mantén los cambios mínimos necesarios y preserva el contenido/formatos que el usuario no pidió modificar.");
            return sb.ToString();
        }

        private static string HostActions(string host)
        {
            switch ((host ?? "").ToLowerInvariant())
            {
                case "word":
                    return "replace_selection{text}; insert_text{text,position}; replace_text{findText,replacementText,replaceAll,matchCase}; format_selection{fontName,fontSize,bold,italic,underline,fontColorHex,alignment,styleName,spaceBeforePt,spaceAfterPt,lineSpacing}; format_document{fontName,fontSize,fontColorHex,alignment,styleName,spaceBeforePt,spaceAfterPt,lineSpacing}; format_find{findText,...formato}; add_heading{text,headingLevel,position}; add_list{items,listType,position}; add_table{rows,position}; set_margins{marginTopCm,marginBottomCm,marginLeftCm,marginRightCm}; set_orientation{orientation}; set_paper_size{paperSize}; set_header{headerText}; set_footer{footerText}; add_page_numbers{pageNumberPosition}; page_break{position}; insert_section_break{position,breakType}; set_columns{columnsCount}; add_toc{position,minLevel,maxLevel}; add_hyperlink{text,url,position,altText}; add_comment{commentText}; track_changes{enabled}; insert_picture{filePath,position,widthCm,heightCm,target=inline|square|tight|behind|front,altText}.";
                case "excel":
                    return "set_cell{address,text,sheet}; set_formula{address,formula,sheet}; set_range_values{address,rows,sheet}; format_range{address,sheet,fontName,fontSize,bold,italic,underline,fontColorHex,fillColorHex,alignment,numberFormat}; autofit{address,sheet}; create_table{address,sheet,name,styleName}; create_calculated_column{sheet,tableName,columnName,formula}; conditional_format{address,sheet,target=cell_value|formula,operatorName,value1,value2,formula,fillColorHex,fontColorHex,bold}; data_validation{address,sheet,target=list|whole|decimal|date|text,items,value1,value2,operatorName}; sort_range{address,sheet,sortBy,ascending}; filter_range{address,sheet,fieldIndex,criteria1}; create_chart{sourceRange,sheet,chartType,title}; create_pivot_table{sourceRange,sheet,destination,name,items(row fields),dataField,summaryFunction}; define_name{name,address,sheet}; show_totals_row{sheet,tableName,enabled,dataField,summaryFunction}; set_calculation{target=automatic|manual}; add_sheet{name}; rename_sheet{sheet,name}; merge_range{address,sheet}; freeze_top_row{}; replace_text{findText,replacementText,replaceAll,matchCase}; insert_picture{filePath,address,sheet,widthCm,heightCm}.";
                case "powerpoint":
                    return "add_slide{title,text,position}; set_slide_title{slideIndex,title}; set_slide_layout{slideIndex,layoutType=blank|title|title_only|text|two}; add_textbox{slideIndex,text,leftCm,topCm,widthCm,heightCm,fontName,fontSize,bold,fontColorHex,alignment}; replace_text{findText,replacementText,replaceAll,matchCase}; format_text{slideIndex,findText,fontName,fontSize,bold,italic,underline,fontColorHex,alignment}; add_table{slideIndex,rows,leftCm,topCm,widthCm,heightCm}; add_shape{slideIndex,shapeType,text,leftCm,topCm,widthCm,heightCm,fillColorHex,fontColorHex}; add_image_placeholder{slideIndex,text,leftCm,topCm,widthCm,heightCm,fontColorHex}; set_background{slideIndex,fillColorHex}; apply_professional_style{fontName,fontSize,fontColorHex,fillColorHex}; set_transition{slideIndex(optional=all),effect=fade|push|wipe|split|none,speed=fast|medium|slow}; add_animation{slideIndex,target(shape name or contained text),effect=fade|appear|fly|wipe|zoom,position=onclick|after|with}; align_shapes{slideIndex,items(optional shape names),alignment=left|center|right|top|middle|bottom}; distribute_shapes{slideIndex,items(optional),target=horizontal|vertical}; set_notes{slideIndex,notesText}; apply_theme{filePath(local THMX/POT/POTX)}; duplicate_slide{slideIndex}; insert_picture{slideIndex,filePath,leftCm,topCm,widthCm,heightCm}.";
                default: return "No hay acciones disponibles.";
            }
        }

        private string ExtractCandidateText(string raw)
        {
            var root = _json.DeserializeObject(raw) as Dictionary<string, object>;
            object candidatesObj;
            if (root == null || !root.TryGetValue("candidates", out candidatesObj)) throw new InvalidOperationException("Gemini no devolvió candidatos.");
            var candidates = candidatesObj as object[];
            if (candidates == null || candidates.Length == 0) throw new InvalidOperationException("Gemini no devolvió contenido.");
            var first = candidates[0] as Dictionary<string, object>;
            object contentObj;
            if (first == null || !first.TryGetValue("content", out contentObj)) throw new InvalidOperationException("Respuesta Gemini sin content.");
            var content = contentObj as Dictionary<string, object>;
            object partsObj;
            if (content == null || !content.TryGetValue("parts", out partsObj)) throw new InvalidOperationException("Respuesta Gemini sin parts.");
            var parts = partsObj as object[];
            var sb = new StringBuilder();
            if (parts != null)
            {
                foreach (object pObj in parts)
                {
                    var p = pObj as Dictionary<string, object>;
                    object t;
                    if (p != null && p.TryGetValue("text", out t) && t != null) sb.Append(Convert.ToString(t));
                }
            }
            if (sb.Length == 0) throw new InvalidOperationException("Gemini no devolvió texto utilizable.");
            return sb.ToString();
        }

        private List<WebSource> ExtractSources(string raw)
        {
            var result = new List<WebSource>();
            try
            {
                var root = _json.DeserializeObject(raw) as Dictionary<string, object>;
                object candidatesObj;
                var candidates = root != null && root.TryGetValue("candidates", out candidatesObj) ? candidatesObj as object[] : null;
                if (candidates == null) return result;
                foreach (var cObj in candidates)
                {
                    var c = cObj as Dictionary<string, object>;
                    object gmObj;
                    var gm = c != null && c.TryGetValue("groundingMetadata", out gmObj) ? gmObj as Dictionary<string, object> : null;
                    object chunksObj;
                    var chunks = gm != null && gm.TryGetValue("groundingChunks", out chunksObj) ? chunksObj as object[] : null;
                    if (chunks == null) continue;
                    foreach (var chObj in chunks)
                    {
                        var ch = chObj as Dictionary<string, object>; object webObj;
                        var web = ch != null && ch.TryGetValue("web", out webObj) ? webObj as Dictionary<string, object> : null;
                        if (web == null) continue;
                        string uri = GetString(web, "uri"); string title = GetString(web, "title");
                        if (string.IsNullOrWhiteSpace(uri)) continue;
                        bool exists = false; foreach (var s in result) if (string.Equals(s.url, uri, StringComparison.OrdinalIgnoreCase)) { exists = true; break; }
                        if (!exists) result.Add(new WebSource { title = title, url = uri });
                        if (result.Count >= 8) return result;
                    }
                }
            }
            catch { }
            return result;
        }

        private static string GetString(Dictionary<string, object> d, string key) { object v; return d != null && d.TryGetValue(key, out v) && v != null ? Convert.ToString(v) : null; }
        private static string ExtractError(string raw)
        {
            try
            {
                var json = new JavaScriptSerializer();
                var root = json.DeserializeObject(raw) as Dictionary<string, object>; object e;
                var ed = root != null && root.TryGetValue("error", out e) ? e as Dictionary<string, object> : null;
                string msg = GetString(ed, "message"); if (!string.IsNullOrWhiteSpace(msg)) return msg;
            }
            catch { }
            return string.IsNullOrWhiteSpace(raw) ? "Error desconocido" : raw.Substring(0, Math.Min(raw.Length, 500));
        }
    }
}
