# Static QA — Geo Office AI v0.5

Fecha: 2026-09-07

## Resultado

**PASS estático**

## Comprobaciones ejecutadas

- XML OK en los 5 `.csproj`, 3 `App.config` y 3 descriptores VSTO.
- JSON OK: `GeoOfficeAI.Broker/google_oauth.template.json`.
- YAML OK: `.github/workflows/build-windows.yml`.
- Referencias de archivos de los proyectos: OK; `google_oauth.json` es la única ausencia esperada porque se inyecta durante el build y no debe estar en el ZIP fuente.
- Delimitadores C# (`{}`, `()`, `[]`) verificados ignorando strings/comentarios: OK.
- Campos `OfficeAction` usados por Word/Excel/PowerPoint existen en el modelo compartido: OK.
- Lista blanca y handlers sincronizados:
  - Word: 23 acciones.
  - Excel: 22 acciones.
  - PowerPoint: 19 acciones.
- Correcciones de interoperabilidad revisadas en puntos sensibles de Excel/PowerPoint.
- Código de proveedor: solo Gemini; no se detectaron endpoints de OpenAI, Anthropic ni Ollama.
- Solo plantilla OAuth; no se incluyeron credenciales reales.
- Las 3 claves de instalación no aparecen en texto plano; el instalador conserva solo hashes SHA-256.
- Seguridad presente: PKCE, OAuth `state`, tokens en memoria, revocación/wipe, named pipe restringido, whitelist, install guard, validación de URLs/rutas y bloqueo reforzado de fórmulas peligrosas.
- Generación de imágenes por API ausente; inserción de imágenes locales sí permitida.
- Versionado v0.5 consistente en README, ensamblados, workflow e instalador.

## Mejoras v0.5 verificadas estáticamente

### Word
Formato del documento completo, columnas, tabla de contenido, hipervínculos/fuentes, secciones e imágenes con ajuste de texto.

### Excel
Tablas con estilo, columnas calculadas autoexpandibles, formato condicional, validación, ordenar/filtrar, PivotTable básica, nombres definidos, totales y cálculo automático/manual.

### PowerPoint
Layouts, temas locales, transiciones, animaciones básicas, alineación/distribución, notas, placeholders de imagen y estilo profesional consistente.

## Límite de esta QA

Este entorno no contiene Windows, Microsoft Office ni Visual Studio/VSTO, por lo que **no se ha compilado ni ejecutado esta versión dentro de Word, Excel o PowerPoint reales**. La QA estática reduce errores obvios, pero no sustituye el build y las pruebas reales de COM/Interop. El inicio de sesión tampoco puede probarse hasta configurar un OAuth Client ID real de tipo Desktop en Google Cloud.


## Hotfix v0.7
- Verificado que no quedan referencias de ejecución a `gemini-2.5-flash` en `GeminiPlanner.cs`.
- Modelo de ejecución: `gemini-3.6-flash`.


## Hotfix v0.8
- `build.ps1` usa `/m:1` en lugar de `/m` para evitar compilación paralela de proyectos VSTO que acceden a claves de registro durante los targets de Office.
