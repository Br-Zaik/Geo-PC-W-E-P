﻿#define MyAppName "Geo Office AI"
#define MyAppVersion "1.2.3"
#define MyAppPublisher "Geo Office AI"
#define MyAppExeName "GeoOfficeAI.Broker.exe"

[Setup]
AppId={{D67B0F54-7523-4C9A-9A3B-6C2F93D78C04}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\GeoOfficeAI
DisableProgramGroupPage=yes
PrivilegesRequired=admin
OutputDir=..\dist
OutputBaseFilename=GeoOfficeAI-Setup-v1.2.3
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName=Geo Office AI para Word, Excel y PowerPoint
ChangesAssociations=no
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Files]
Source: "..\dist\package\Broker\*"; DestDir: "{app}\Broker"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\dist\package\Word\*"; DestDir: "{app}\Word"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\dist\package\Excel\*"; DestDir: "{app}\Excel"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\dist\package\PowerPoint\*"; DestDir: "{app}\PowerPoint"; Flags: ignoreversion recursesubdirs createallsubdirs

[Registry]
; Marcador interno de instalación autorizada, ambas vistas para Office x86/x64.
Root: HKLM32; Subkey: "SOFTWARE\GeoOfficeAI\OfficeSuite"; ValueType: string; ValueName: "InstallAuthorized"; ValueData: "1"; Flags: uninsdeletekey
Root: HKLM64; Subkey: "SOFTWARE\GeoOfficeAI\OfficeSuite"; ValueType: string; ValueName: "InstallAuthorized"; ValueData: "1"; Flags: uninsdeletekey; Check: IsWin64
Root: HKLM32; Subkey: "SOFTWARE\GeoOfficeAI\OfficeSuite"; ValueType: string; ValueName: "InstallDir"; ValueData: "{app}"
Root: HKLM64; Subkey: "SOFTWARE\GeoOfficeAI\OfficeSuite"; ValueType: string; ValueName: "InstallDir"; ValueData: "{app}"; Check: IsWin64

; Word
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: string; ValueName: "FriendlyName"; ValueData: "Asistente IA · Gemini"; Flags: uninsdeletekey
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: string; ValueName: "Description"; ValueData: "Chat de Gemini integrado en Word";
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: dword; ValueName: "LoadBehavior"; ValueData: "3";
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: string; ValueName: "Manifest"; ValueData: "{code:WordManifest}";
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: string; ValueName: "FriendlyName"; ValueData: "Asistente IA · Gemini"; Flags: uninsdeletekey; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: string; ValueName: "Description"; ValueData: "Chat de Gemini integrado en Word"; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: dword; ValueName: "LoadBehavior"; ValueData: "3"; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Word\Addins\GeoOfficeAI.Word"; ValueType: string; ValueName: "Manifest"; ValueData: "{code:WordManifest}"; Check: IsWin64

; Excel
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: string; ValueName: "FriendlyName"; ValueData: "Asistente IA · Gemini"; Flags: uninsdeletekey
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: string; ValueName: "Description"; ValueData: "Chat de Gemini integrado en Excel";
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: dword; ValueName: "LoadBehavior"; ValueData: "3";
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: string; ValueName: "Manifest"; ValueData: "{code:ExcelManifest}";
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: string; ValueName: "FriendlyName"; ValueData: "Asistente IA · Gemini"; Flags: uninsdeletekey; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: string; ValueName: "Description"; ValueData: "Chat de Gemini integrado en Excel"; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: dword; ValueName: "LoadBehavior"; ValueData: "3"; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\Excel\Addins\GeoOfficeAI.Excel"; ValueType: string; ValueName: "Manifest"; ValueData: "{code:ExcelManifest}"; Check: IsWin64

; PowerPoint
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: string; ValueName: "FriendlyName"; ValueData: "Asistente IA · Gemini"; Flags: uninsdeletekey
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: string; ValueName: "Description"; ValueData: "Chat de Gemini integrado en PowerPoint";
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: dword; ValueName: "LoadBehavior"; ValueData: "3";
Root: HKLM32; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: string; ValueName: "Manifest"; ValueData: "{code:PowerPointManifest}";
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: string; ValueName: "FriendlyName"; ValueData: "Asistente IA · Gemini"; Flags: uninsdeletekey; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: string; ValueName: "Description"; ValueData: "Chat de Gemini integrado en PowerPoint"; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: dword; ValueName: "LoadBehavior"; ValueData: "3"; Check: IsWin64
Root: HKLM64; Subkey: "SOFTWARE\Microsoft\Office\PowerPoint\Addins\GeoOfficeAI.PowerPoint"; ValueType: string; ValueName: "Manifest"; ValueData: "{code:PowerPointManifest}"; Check: IsWin64

[Code]
var
  KeyPage: TInputQueryWizardPage;

const
  KeyHash = '468D033ED1220225776BD98829D0A3051D729049677172176DA0BEBC555F6D30';

procedure InitializeWizard;
begin
  KeyPage := CreateInputQueryPage(wpSelectDir,
    'Clave de instalación',
    'Introduce una clave autorizada para continuar.',
    'La clave solo se valida durante la instalación y no se guarda en texto plano.');
  KeyPage.Add('Clave:', True);
end;

function ValidInstallKey(const S: String): Boolean;
var
  H: String;
begin
  H := Uppercase(GetSHA256OfString(Trim(S)));
  Result := (H = KeyHash);
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = KeyPage.ID then
  begin
    if not ValidInstallKey(KeyPage.Values[0]) then
    begin
      MsgBox('Clave incorrecta. La instalación no puede continuar.', mbError, MB_OK);
      Result := False;
    end;
  end;
end;

function FileUri(const P: String): String;
var
  S: String;
begin
  S := ExpandConstant(P);
  StringChangeEx(S, '\', '/', True);
  Result := 'file:///' + S + '|vstolocal';
end;

function WordManifest(Param: String): String;
begin Result := FileUri('{app}\Word\GeoOfficeAI.Word.vsto'); end;
function ExcelManifest(Param: String): String;
begin Result := FileUri('{app}\Excel\GeoOfficeAI.Excel.vsto'); end;
function PowerPointManifest(Param: String): String;
begin Result := FileUri('{app}\PowerPoint\GeoOfficeAI.PowerPoint.vsto'); end;

function InitializeSetup(): Boolean;
begin
  Result := True;
end;
