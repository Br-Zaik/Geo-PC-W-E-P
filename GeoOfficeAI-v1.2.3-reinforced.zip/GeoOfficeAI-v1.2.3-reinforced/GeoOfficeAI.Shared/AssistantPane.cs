﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace GeoOfficeAI.Shared
{
    public sealed class AssistantPane : UserControl
    {
        private readonly IOfficeHost _host;
        private readonly BrokerClient _broker;
        private readonly RichTextBox _chat;
        private readonly TextBox _prompt;
        private readonly Button _send;
        private readonly Button _login;
        private readonly Button _cancel;
        private readonly Button _undo;
        private readonly Label _status;
        private readonly Label _documentLabel;
        private readonly System.Windows.Forms.Timer _statusTimer;
        private readonly System.Windows.Forms.Timer _documentTimer;
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        private readonly List<ChatEntry> _entries = new List<ChatEntry>();
        private CancellationTokenSource _cts;
        private bool _connected;
        private string _documentSessionId;
        private string _persistentDocumentKey;
        private bool _suspendingForOfficeClose;

        public AssistantPane(IOfficeHost host)
        {
            _host = host;
            _broker = new BrokerClient();
            DiagnosticLogger.CleanupOldLogs(14);
            DiagnosticLogger.Info(_host, "AssistantPane.Start", "Panel iniciado.");
            BackColor = Color.White;
            Padding = new Padding(8);

            var headerRow = new FlowLayoutPanel
            {
                AutoSize = true,
                Width = 330,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Margin = new Padding(0, 0, 0, 2)
            };
            var header = new Label
            {
                Text = "Gemini · " + host.HostName,
                Font = new Font("Segoe UI", 12.5f, FontStyle.Bold),
                AutoSize = true,
                Margin = new Padding(0, 5, 0, 0)
            };
            headerRow.Controls.Add(header);

            _documentLabel = new Label
            {
                Text = host.GetDocumentDisplayName(),
                Font = new Font("Segoe UI", 8.2f, FontStyle.Regular),
                ForeColor = Color.DimGray,
                AutoSize = false,
                Width = 326,
                Height = 20,
                AutoEllipsis = true,
                Margin = new Padding(0, 0, 0, 3)
            };

            _login = ButtonOf("Iniciar sesión con Google", 195, 31);
            _login.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            _login.Click += async (s, e) => await LoginAsync();

            _chat = new RichTextBox
            {
                ReadOnly = true,
                Width = 326,
                Height = 285,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 9.1f),
                DetectUrls = true,
                Margin = new Padding(0, 5, 0, 6)
            };

            _prompt = new TextBox
            {
                Multiline = true,
                Width = 326,
                Height = 62,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Segoe UI", 9.6f),
                Margin = new Padding(0, 0, 0, 5)
            };
            _prompt.KeyDown += Prompt_KeyDown;

            var row = new FlowLayoutPanel
            {
                AutoSize = true,
                Width = 330,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Margin = new Padding(0)
            };
            _send = ButtonOf("Enviar", 105, 32);
            _send.Font = new Font("Segoe UI", 9.2f, FontStyle.Bold);
            _send.Click += async (s, e) => await SendAsync();
            _cancel = ButtonOf("Cancelar", 82, 32);
            _cancel.Enabled = false;
            _cancel.Click += (s, e) => { try { if (_cts != null) _cts.Cancel(); } catch { } };
            _undo = ButtonOf("Deshacer", 92, 32);
            _undo.Click += (s, e) => Safe(() => _host.UndoLast());
            row.Controls.Add(_send); row.Controls.Add(_cancel); row.Controls.Add(_undo);

            _status = new Label
            {
                Text = "Sin sesión.",
                Font = new Font("Segoe UI", 8.2f, FontStyle.Bold),
                ForeColor = Color.DarkOrange,
                AutoSize = true,
                MaximumSize = new Size(326, 0),
                Margin = new Padding(0, 6, 0, 0)
            };

            var privacy = new Label
            {
                Text = "Mismo archivo guardado = continúa el chat. Otro archivo = chat separado. Cerrar Word no borra la sesión; cerrar la X del asistente sí la elimina.",
                Font = new Font("Segoe UI", 7.5f),
                ForeColor = Color.Gray,
                AutoSize = true,
                MaximumSize = new Size(326, 0),
                Margin = new Padding(0, 5, 0, 0)
            };

            var layout = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                BackColor = Color.White,
                Padding = new Padding(1)
            };
            layout.Controls.Add(headerRow);
            layout.Controls.Add(_documentLabel);
            layout.Controls.Add(_login);
            layout.Controls.Add(_chat);
            layout.Controls.Add(_prompt);
            layout.Controls.Add(row);
            layout.Controls.Add(_status);
            layout.Controls.Add(privacy);
            Controls.Add(layout);

            SetConnected(false, "Comprobando sesión de Gemini...");
            EnsureConversationBinding(true);

            _statusTimer = new System.Windows.Forms.Timer { Interval = 9000 };
            _statusTimer.Tick += async (s, e) => await RefreshConnectionStatusAsync();
            _statusTimer.Start();

            _documentTimer = new System.Windows.Forms.Timer { Interval = 1100 };
            _documentTimer.Tick += (s, e) => EnsureConversationBinding(false);
            _documentTimer.Start();
        }

        public void ResumeAfterShow()
        {
            _suspendingForOfficeClose = false;
            try { _statusTimer.Start(); _documentTimer.Start(); } catch { }
            EnsureConversationBinding(true);
            _ = InitializeStatusAsync();
        }

        public async Task InitializeStatusAsync()
        {
            try
            {
                var r = await _broker.StatusAsync(CancellationToken.None);
                SetConnected(r.ok && r.connected, r.ok && r.connected ? "Gemini conectado." : "Sin sesión. Inicia sesión con Google.");
            }
            catch (Exception ex) { DiagnosticLogger.Error(_host, "InitializeStatus", ex); SetConnected(false, "Sin sesión. Inicia sesión con Google."); }
        }

        public void PersistCurrentConversation()
        {
            try
            {
                EnsureConversationBinding(false);
                if (!string.IsNullOrWhiteSpace(_persistentDocumentKey)) ConversationStore.Save(_persistentDocumentKey, _entries);
            }
            catch { }
        }

        public void NotifyDocumentMayHaveBeenSaved()
        {
            try
            {
                BeginInvoke((Action)(() =>
                {
                    EnsureConversationBinding(false);
                    PersistCurrentConversation();
                }));
            }
            catch { }
        }

        // Se usa cuando Office se cierra. Conserva login e historial de archivos guardados.
        public void SuspendForOfficeShutdown()
        {
            DiagnosticLogger.Info(_host, "Office.Shutdown", "Office se está cerrando: se conserva sesión e historial de archivos guardados.");
            _suspendingForOfficeClose = true;
            PersistCurrentConversation();
            try { _statusTimer.Stop(); _documentTimer.Stop(); } catch { }
            try { if (_cts != null && !_cts.IsCancellationRequested) _cts.Cancel(); } catch { }
            try { _host.WipeTemporaryData(); } catch { }
        }

        private async Task RefreshConnectionStatusAsync()
        {
            if (_cts != null) return;
            try
            {
                var r = await _broker.StatusAsync(CancellationToken.None);
                if (r.ok && r.connected)
                {
                    if (!_connected) SetConnected(true, "Gemini conectado.");
                }
                else SetConnected(false, "Sin sesión. Inicia sesión con Google.");
            }
            catch { if (_connected) SetConnected(false, "Sin sesión. Inicia sesión con Google."); }
        }

        private async Task LoginAsync()
        {
            SetBusy(true, "Abriendo inicio de sesión de Google...");
            _cts = new CancellationTokenSource(TimeSpan.FromMinutes(4));
            try
            {
                var r = await _broker.LoginAsync(_cts.Token);
                if (!r.ok) throw new InvalidOperationException(r.error ?? "No se pudo iniciar sesión.");
                SetConnected(r.connected, r.connected ? "Gemini conectado." : "No se completó el inicio de sesión.");
                if (r.connected) AppendAssistant("Sesión iniciada. Se conservará al cerrar Office; la X del asistente la elimina.");
            }
            catch (OperationCanceledException) { _status.Text = "Inicio de sesión cancelado."; }
            catch (Exception ex)
            {
                DiagnosticLogger.Error(_host, "Login", ex);
                MessageBox.Show(ex.Message, "Geo Office AI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                _status.Text = "No se pudo iniciar sesión.";
            }
            finally { DisposeCts(); SetBusy(false, _status.Text); }
        }

        private async Task SendAsync()
        {
            EnsureConversationBinding(false);
            string instruction = (_prompt.Text ?? "").Trim();
            if (instruction.Length == 0) return;
            if (!_connected)
            {
                MessageBox.Show("Primero inicia sesión con Google.", "Geo Office AI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string priorHistory = BuildHistoryForModel();
            AppendUser(instruction);
            _prompt.Clear();
            _cts = new CancellationTokenSource(TimeSpan.FromMinutes(7));
            SetBusy(true, "Analizando el archivo...");
            DiagnosticLogger.Info(_host, "Request.Start", "Petición iniciada. Longitud=" + instruction.Length + " caracteres; historial=" + _entries.Count + " entradas.");

            int successfulBatches = 0;
            int failedBatches = 0;
            int totalActions = 0;
            bool finalAuditStarted = false;
            try
            {
                string context = _host.GetContext(95000);
                BrokerResponse turn = await _broker.AgentStartAsync(_host.HostName.ToLowerInvariant(), instruction, context, priorHistory, _cts.Token);
                _cts.Token.ThrowIfCancellationRequested();

                for (int round = 0; round < 18; round++)
                {
                    _cts.Token.ThrowIfCancellationRequested();

                    if (turn.completed)
                    {
                        // Segunda pasada independiente: obliga a revisar la petición original
                        // contra el documento YA modificado antes de aceptar el "Listo".
                        if (successfulBatches > 0 && !finalAuditStarted && !turn.usingFallback)
                        {
                            finalAuditStarted = true;
                            _status.Text = "Revisión final del trabajo...";
                            string auditInstruction =
                                "AUDITORÍA FINAL OBLIGATORIA. Revisa el estado ACTUAL de Office y compáralo con la petición original que aparece abajo. " +
                                "No rehagas lo que ya esté correcto. Corrige únicamente requisitos faltantes o incorrectos usando las herramientas reales de Office. " +
                                "Verifica especialmente formato global, títulos/subtítulos, márgenes, tablas/cuadros, ortografía, palabras clave, espacios para imágenes y fuentes cuando hayan sido pedidos. " +
                                "Si todo está correcto, responde brevemente que la auditoría pasó. PETICIÓN ORIGINAL: " + instruction;
                            string auditContext = _host.GetContext(95000);
                            turn = await _broker.AgentStartAsync(_host.HostName.ToLowerInvariant(), auditInstruction, auditContext, priorHistory, _cts.Token);
                            continue;
                        }

                        string final = CompactFinalMessage(turn.finalMessage, successfulBatches > 0);
                        if (!string.IsNullOrWhiteSpace(final)) AppendAssistant(final);
                        if (successfulBatches > 0) _status.Text = finalAuditStarted ? "Listo. Trabajo auditado y verificado." : "Listo. Cambios verificados.";
                        else _status.Text = "Listo.";
                        DiagnosticLogger.Info(_host, "Request.Completed", "Petición terminada. Lotes correctos=" + successfulBatches + "; fallidos=" + failedBatches + "; acciones=" + totalActions + "; auditoría=" + finalAuditStarted + ".");
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(turn.planJson))
                        throw new InvalidOperationException("Gemini no devolvió acciones ni una respuesta final.");

                    OfficePlan plan = PlanParser.Parse(turn.planJson);
                    PlanSafety.Validate(_host.HostName.ToLowerInvariant(), plan);
                    DiagnosticLogger.Info(_host, "Request.Plan", "Lote recibido con " + (plan.actions == null ? 0 : plan.actions.Count) + " acción(es): " + SafeHelpers.Truncate((_host.DescribePlan(plan) ?? "").Replace("\r", " ").Replace("\n", " "), 1200));
                    if (plan.actions == null || plan.actions.Count == 0)
                    {
                        if (turn.usingFallback)
                        {
                            if (!string.IsNullOrWhiteSpace(turn.finalMessage)) AppendAssistant(CompactFinalMessage(turn.finalMessage, false));
                            _status.Text = "Listo.";
                            return;
                        }
                        throw new InvalidOperationException("Gemini devolvió un lote de acciones vacío.");
                    }

                    _status.Text = "Aplicando " + plan.actions.Count + " cambio(s)...";
                    string toolResult;
                    try
                    {
                        await _host.ApplyPlanAsync(plan, _cts.Token);
                        _cts.Token.ThrowIfCancellationRequested();
                        successfulBatches++;
                        totalActions += plan.actions.Count;
                        DiagnosticLogger.Info(_host, "Request.BatchApplied", "Lote aplicado correctamente. Acciones=" + plan.actions.Count + "; total=" + totalActions + ".");
                        _status.Text = "Verificando cambios...";
                        string after = _host.GetContext(22000);
                        toolResult = _json.Serialize(new Dictionary<string, object>
                        {
                            { "ok", true },
                            { "applied_actions", plan.actions.Count },
                            { "total_actions_applied", totalActions },
                            { "verification", "Office ejecutó el lote sin excepciones y las verificaciones internas de las acciones pasaron." },
                            { "context_after", SafeHelpers.Truncate(after, 20000) }
                        });
                    }
                    catch (OperationCanceledException) { throw; }
                    catch (Exception ex)
                    {
                        failedBatches++;
                        DiagnosticLogger.Error(_host, "Request.BatchFailed", ex);
                        _status.Text = "Corrigiendo un problema detectado...";
                        string after = "";
                        try { after = _host.GetContext(18000); } catch { }
                        toolResult = _json.Serialize(new Dictionary<string, object>
                        {
                            { "ok", false },
                            { "error", SafeHelpers.Truncate(ex.Message, 3000) },
                            { "rollback", "El host intentó revertir el lote antes de devolver este error." },
                            { "context_after", SafeHelpers.Truncate(after, 16000) }
                        });
                        if (failedBatches >= 3)
                            throw new InvalidOperationException("El agente intentó corregir el trabajo varias veces, pero Office sigue rechazando una acción. Último problema: " + ex.Message);
                    }

                    // Fallback estructurado: no tiene bucle de function calling, pero conserva la ejecución segura.
                    if (turn.usingFallback || string.IsNullOrWhiteSpace(turn.agentSessionId) || string.IsNullOrWhiteSpace(turn.callId))
                    {
                        if (successfulBatches > 0)
                        {
                            string msg = string.IsNullOrWhiteSpace(turn.finalMessage) ? "Listo: los cambios se aplicaron correctamente." : turn.finalMessage;
                            AppendAssistant(CompactFinalMessage(msg, true));
                            _status.Text = "Listo. Cambios verificados.";
                            DiagnosticLogger.Info(_host, "Request.CompletedFallback", "Fallback completó cambios. Lotes=" + successfulBatches + "; acciones=" + totalActions + ".");
                            return;
                        }
                        throw new InvalidOperationException("El motor de respaldo no pudo aplicar la petición.");
                    }

                    turn = await _broker.AgentContinueAsync(turn.agentSessionId, turn.callId, turn.functionName, toolResult, _cts.Token);
                }
                throw new InvalidOperationException("La petición necesitó demasiados ciclos de trabajo y se detuvo por seguridad antes de realizar cambios adicionales.");
            }
            catch (OperationCanceledException)
            {
                DiagnosticLogger.Info(_host, "Request.Cancelled", "Operación cancelada por usuario o timeout.");
                _status.Text = "Operación cancelada.";
            }
            catch (Exception ex)
            {
                DiagnosticLogger.Error(_host, "Request.Failed", ex);
                _status.Text = "No se completó. Diagnóstico guardado.";
                AppendAssistant("No pude completar el trabajo: " + SafeHelpers.Truncate(ex.Message, 900) + "\nDiagnóstico técnico guardado localmente en GeoOfficeAI\\Logs.");
            }
            finally
            {
                PersistCurrentConversation();
                DisposeCts();
                SetBusy(false, _status.Text);
            }
        }

        private string BuildHistoryForModel()
        {
            var sb = new StringBuilder();
            int start = Math.Max(0, _entries.Count - 20);
            for (int i = start; i < _entries.Count; i++)
            {
                ChatEntry e = _entries[i];
                if (e == null || string.IsNullOrWhiteSpace(e.text)) continue;
                sb.Append(string.Equals(e.role, "assistant", StringComparison.OrdinalIgnoreCase) ? "Gemini" : "Usuario").Append(": ")
                  .AppendLine(SafeHelpers.Truncate(e.text.Replace("\r", " ").Replace("\n", " "), 1800));
                if (sb.Length > 16000) break;
            }
            return SafeHelpers.Truncate(sb.ToString(), 16000);
        }

        private static string CompactFinalMessage(string message, bool changedOffice)
        {
            string text = (message ?? "").Trim();
            if (text.Length == 0) return changedOffice ? "Listo: el trabajo quedó aplicado en Office." : "Listo.";
            if (text.Length > 1400) text = text.Substring(0, 1400).TrimEnd() + "…";
            return text;
        }

        private void Prompt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && e.Control)
            {
                e.SuppressKeyPress = true;
                _ = SendAsync();
            }
        }

        // Solo debe llamarse cuando el usuario cierra intencionalmente la X del asistente.
        public void WipeSensitiveSession()
        {
            if (_suspendingForOfficeClose) return;
            DiagnosticLogger.Info(_host, "Session.Wipe", "Cierre intencional de la X del asistente: se eliminarán sesión e historiales.");
            try { _statusTimer.Stop(); _documentTimer.Stop(); } catch { }
            try { if (_cts != null && !_cts.IsCancellationRequested) _cts.Cancel(); } catch { }
            try { Task.Run(async () => await _broker.WipeAsync()).Wait(2200); } catch { }
            try { _host.WipeTemporaryData(); } catch { }
            try { ConversationStore.DeleteAll(); } catch { }
            _entries.Clear();
            try { _chat.Clear(); _prompt.Clear(); } catch { }
            _persistentDocumentKey = null;
            SetConnected(false, "Sesión e historial eliminados.");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                try { if (_statusTimer != null) { _statusTimer.Stop(); _statusTimer.Dispose(); } } catch { }
                try { if (_documentTimer != null) { _documentTimer.Stop(); _documentTimer.Dispose(); } } catch { }
                DisposeCts();
            }
            base.Dispose(disposing);
        }

        private void EnsureConversationBinding(bool force)
        {
            string sessionId;
            string persistentKey;
            string display;
            try
            {
                sessionId = _host.GetDocumentSessionId() ?? "none";
                persistentKey = _host.GetPersistentDocumentKey();
                display = _host.GetDocumentDisplayName();
            }
            catch { return; }

            if (!force && string.Equals(sessionId, _documentSessionId, StringComparison.Ordinal))
            {
                // El mismo documento pudo guardarse por primera vez o cambiar de ruta con Guardar como.
                if (!string.IsNullOrWhiteSpace(persistentKey) && !string.Equals(persistentKey, _persistentDocumentKey, StringComparison.OrdinalIgnoreCase))
                {
                    if (!string.IsNullOrWhiteSpace(_persistentDocumentKey)) ConversationStore.Save(_persistentDocumentKey, _entries);
                    _persistentDocumentKey = persistentKey;
                    ConversationStore.Save(_persistentDocumentKey, _entries);
                }
                _documentLabel.Text = display;
                return;
            }

            if (!string.IsNullOrWhiteSpace(_persistentDocumentKey)) ConversationStore.Save(_persistentDocumentKey, _entries);
            _documentSessionId = sessionId;
            _persistentDocumentKey = persistentKey;
            _entries.Clear();
            if (!string.IsNullOrWhiteSpace(_persistentDocumentKey)) _entries.AddRange(ConversationStore.Load(_persistentDocumentKey));
            _documentLabel.Text = display;
            RenderChat();
        }

        private void RenderChat()
        {
            _chat.Clear();
            foreach (ChatEntry e in _entries)
            {
                if (e == null) continue;
                AppendVisual(string.Equals(e.role, "assistant", StringComparison.OrdinalIgnoreCase) ? "Gemini" : "Tú", e.text,
                    string.Equals(e.role, "assistant", StringComparison.OrdinalIgnoreCase) ? Color.FromArgb(25, 115, 70) : Color.FromArgb(30, 80, 150));
            }
        }

        private void SetConnected(bool value, string text)
        {
            _connected = value;
            _login.Visible = !value;
            _prompt.Enabled = value;
            _send.Enabled = value;
            _undo.Enabled = true;
            _status.Text = text;
            _status.ForeColor = value ? Color.DarkGreen : Color.DarkOrange;
        }

        private void SetBusy(bool busy, string text)
        {
            _login.Enabled = !busy;
            _send.Enabled = !busy && _connected;
            _prompt.Enabled = !busy && _connected;
            _cancel.Enabled = busy;
            _undo.Enabled = !busy;
            UseWaitCursor = busy;
            _status.Text = text;
        }

        private void AppendUser(string text) { AddEntry("user", text); }
        private void AppendAssistant(string text) { AddEntry("assistant", text); }

        private void AddEntry(string role, string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            var entry = new ChatEntry { role = role, text = text.Trim(), utc = DateTime.UtcNow };
            _entries.Add(entry);
            AppendVisual(role == "assistant" ? "Gemini" : "Tú", entry.text,
                role == "assistant" ? Color.FromArgb(25, 115, 70) : Color.FromArgb(30, 80, 150));
            if (!string.IsNullOrWhiteSpace(_persistentDocumentKey)) ConversationStore.Save(_persistentDocumentKey, _entries);
        }

        private void AppendVisual(string who, string text, Color color)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            _chat.SelectionStart = _chat.TextLength;
            _chat.SelectionColor = color;
            _chat.SelectionFont = new Font(_chat.Font, FontStyle.Bold);
            _chat.AppendText(who + ": ");
            _chat.SelectionColor = Color.Black;
            _chat.SelectionFont = _chat.Font;
            _chat.AppendText(text.Trim() + "\n\n");
            _chat.ScrollToCaret();
        }

        private static Button ButtonOf(string text, int width, int height)
        {
            return new Button { Text = text, Width = width, Height = height, Font = new Font("Segoe UI", 8.8f), Margin = new Padding(0, 0, 5, 4), UseVisualStyleBackColor = true };
        }

        private void DisposeCts()
        {
            try { if (_cts != null) _cts.Dispose(); } catch { }
            _cts = null;
        }

        private static void Safe(Action a)
        {
            try { a(); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Geo Office AI", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
