﻿# Static QA — Geo Office AI v1.2.3 Copilot reforzado

## Qué se verifica automáticamente

El script `qa-static.ps1`, ejecutado por GitHub Actions antes de compilar, comprueba regresiones estructurales de alto impacto:

- Cada acción permitida de Word, Excel y PowerPoint tiene un `case` ejecutor correspondiente.
- El agente principal usa Gemini 3.8 Flash mediante Interactions API estable `v1`, Function Calling `validated` y Google Search condicional.
- El fallback conserva Structured Outputs, reparación limitada y validación local.
- Word mantiene `UndoRecord`, preflight, cursor secuencial y rollback ante fallo/cancelación.
- Word incluye las herramientas Copilot-style nuevas: `format_style`, `style_table`, `set_table_cell_margins` y `add_image_placeholder`, además de anclajes de inserción antes/después de texto existente.
- El contexto de Word expone estructura de párrafos, tablas y señales de ortografía/gramática.
- Existe una segunda auditoría agentic obligatoria antes de aceptar un trabajo modificado como terminado.
- Excel y PowerPoint mantienen copia de recuperación previa y las tres aplicaciones protegen el uso COM/STA.
- Historial y refresh token están cifrados con DPAPI CurrentUser.
- El mismo archivo guardado puede recuperar su chat; cerrar Office conserva la sesión; la X del asistente elimina historiales y sesión.
- El panel de las tres aplicaciones conserva un ancho compacto de 350 px.
- AssemblyVersion/FileVersion, instalador y artefactos apuntan a v1.2.
- El instalador contiene un único `KeyHash` y no conserva `KeyHash1/2/3`.
- `DiagnosticLogger` está incluido en Shared, rota logs y el panel registra fallos de lote/fallo final.
- Los tres add-ins usan decisión diferida para distinguir X del asistente del ocultamiento durante el cierre de Office.

## Qué NO demuestra QA estática

No demuestra que Word, Excel o PowerPoint hayan ejecutado físicamente las acciones en una instalación real. Tampoco sustituye MSBuild/VSTO ni las pruebas en Office x86/x64. El entorno en el que se preparó esta entrega es Linux y no contiene Microsoft Office.

El gate correcto es:

1. `qa-static.ps1` en Windows.
2. Compilación completa de `GeoOfficeAI.sln` con MSBuild/Visual Studio Office workload.
3. Creación del instalador Inno Setup.
4. Instalación en una máquina de prueba.
5. Matriz funcional de `docs/PRUEBAS-v1.2.md`.

## Resultado esperado

La v1.2 busca que una sola orden natural y compuesta se convierta en trabajo real: analizar el Word, ejecutar cambios, volver a leer el documento, corregir faltantes y solo entonces confirmar. Si una API o una llamada COM falla, la aplicación debe informar el fallo en lugar de fingir que el trabajo se realizó.


## Regresión de compilación v1.2.1
- Se prohíbe la asignación directa a `Word.Table.Style`; debe usarse `Table.set_Style(ref object)` para compatibilidad con los PIAs usados por MSBuild/VSTO.
- El workflow usa `actions/checkout@v5`.

## Regresión de compilación v1.2.3

- Prohíbe suscripción directa `this.Application.NewDocument += ...` que causa CS0229 con Word PIA.
- Exige `Word.ApplicationEvents4_Event` y suscripción explícita a `NewDocument`.
- Exige `actions/checkout@v5`.
