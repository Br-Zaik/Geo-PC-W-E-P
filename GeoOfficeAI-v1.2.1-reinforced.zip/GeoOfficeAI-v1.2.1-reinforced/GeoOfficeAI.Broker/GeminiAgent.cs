using GeoOfficeAI.Shared;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Broker
{
    /// <summary>
    /// Motor agente basado en Gemini Interactions API. Usa function calling para que
    /// Office ejecute cambios, devuelve el resultado al modelo y permite que Gemini
    /// compruebe/corrija el siguiente paso antes de afirmar que terminó.
    /// </summary>
    internal sealed class GeminiAgent
    {
        private const string Model = "gemini-3.8-flash";
        private const string ToolName = "apply_office_actions";
        private const int MaxActionsPerBatch = 12;
        private readonly OAuthSession _session;
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        private readonly object _gate = new object();
        private readonly Dictionary<string, AgentSession> _sessions = new Dictionary<string, AgentSession>(StringComparer.OrdinalIgnoreCase);

        private sealed class AgentSession
        {
            public string id;
            public string host;
            public string instruction;
            public bool webEnabled;
            public List<object> history;
            public DateTime lastUtc;
        }

        public GeminiAgent(OAuthSession session) { _session = session; }

        public async Task<BrokerResponse> StartAsync(string host, string instruction, string context, string conversationHistory, CancellationToken token)
        {
            host = (host ?? "").Trim().ToLowerInvariant();
            if (host != "word" && host != "excel" && host != "powerpoint") throw new InvalidOperationException("Aplicación de Office no reconocida.");
            if (string.IsNullOrWhiteSpace(instruction)) throw new InvalidOperationException("La petición está vacía.");

            string sessionId = Guid.NewGuid().ToString("N");
            string input = BuildUserInput(host, instruction, context, conversationHistory);
            var state = new AgentSession
            {
                id = sessionId,
                host = host,
                instruction = instruction,
                webEnabled = ShouldUseWebSearch(instruction),
                lastUtc = DateTime.UtcNow,
                history = new List<object>
                {
                    new Dictionary<string, object>
                    {
                        { "type", "user_input" },
                        { "content", new object[] { new Dictionary<string, object> { { "type", "text" }, { "text", input } } } }
                    }
                }
            };

            lock (_gate) { PruneSessions(); _sessions[sessionId] = state; }
            try
            {
                BrokerResponse response = await RunTurnAsync(state, token);
                response.agentSessionId = sessionId;
                if (response.completed) RemoveSession(sessionId);
                return response;
            }
            catch
            {
                RemoveSession(sessionId);
                throw;
            }
        }

        public async Task<BrokerResponse> ContinueAsync(string agentSessionId, string callId, string functionName, string toolResult, CancellationToken token)
        {
            AgentSession state;
            lock (_gate)
            {
                if (string.IsNullOrWhiteSpace(agentSessionId) || !_sessions.TryGetValue(agentSessionId, out state))
                    throw new InvalidOperationException("La ejecución del agente expiró. Vuelve a enviar la petición.");
                state.lastUtc = DateTime.UtcNow;
            }
            if (!string.Equals(functionName, ToolName, StringComparison.Ordinal))
                throw new InvalidOperationException("Gemini intentó continuar con una herramienta no reconocida.");
            if (string.IsNullOrWhiteSpace(callId)) throw new InvalidOperationException("Falta el identificador de la llamada de herramienta.");

            foreach (string id in DecodeCallIds(callId))
            {
                state.history.Add(new Dictionary<string, object>
                {
                    { "type", "function_result" },
                    { "name", ToolName },
                    { "call_id", id },
                    { "result", new object[] { new Dictionary<string, object> { { "type", "text" }, { "text", SafeHelpers.Truncate(toolResult ?? "{}", 24000) } } } }
                });
            }

            BrokerResponse response = await RunTurnAsync(state, token);
            response.agentSessionId = agentSessionId;
            if (response.completed) RemoveSession(agentSessionId);
            return response;
        }

        public void ClearSessions()
        {
            lock (_gate) _sessions.Clear();
        }

        private async Task<BrokerResponse> RunTurnAsync(AgentSession state, CancellationToken token)
        {
            string accessToken = await _session.GetAccessTokenAsync(token);
            var body = new Dictionary<string, object>
            {
                { "model", Model },
                { "store", false },
                { "input", state.history.ToArray() },
                { "system_instruction", BuildSystemInstruction(state.host, state.webEnabled) },
                { "tools", BuildTools(state.host, state.webEnabled) },
                { "generation_config", new Dictionary<string, object> {
                    { "thinking_level", "medium" },
                    // validated mantiene el esquema de la función sin restringir la herramienta
                    // integrada google_search cuando el turno requiere investigación web.
                    { "tool_choice", "validated" },
                    { "max_output_tokens", 12000 }
                } }
            };

            string raw = await PostInteractionAsync(accessToken, body, token);
            var root = _json.DeserializeObject(raw) as Dictionary<string, object>;
            if (root == null) throw new InvalidOperationException("Gemini devolvió una interacción vacía.");
            string status = GetString(root, "status");
            if (string.Equals(status, "failed", StringComparison.OrdinalIgnoreCase) || string.Equals(status, "cancelled", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Gemini no pudo completar la interacción.");

            object stepsObj;
            object[] steps = root.TryGetValue("steps", out stepsObj) ? stepsObj as object[] : null;
            if (steps == null) steps = new object[0];
            foreach (object step in steps) state.history.Add(step);

            // Gemini puede emitir llamadas paralelas. Como todas apuntan a la misma herramienta
            // segura de Office, las fusionamos en UN solo lote transaccional/verificable y después
            // devolvemos un function_result por cada call_id para mantener el historial válido.
            var calls = new List<Dictionary<string, object>>();
            foreach (object stepObj in steps)
            {
                var step = stepObj as Dictionary<string, object>;
                if (step != null && string.Equals(GetString(step, "type"), "function_call", StringComparison.OrdinalIgnoreCase)) calls.Add(step);
            }
            if (calls.Count > 0)
            {
                var merged = new OfficePlan { message = "", actions = new List<OfficeAction>(), sources = new List<WebSource>() };
                var ids = new List<string>();
                foreach (var step in calls)
                {
                    string name = GetString(step, "name");
                    string id = GetString(step, "id");
                    if (!string.Equals(name, ToolName, StringComparison.Ordinal)) throw new InvalidOperationException("Gemini solicitó una herramienta no permitida: " + name);
                    if (string.IsNullOrWhiteSpace(id)) throw new InvalidOperationException("Gemini devolvió una llamada de herramienta sin identificador.");
                    object argsObj;
                    var args = step.TryGetValue("arguments", out argsObj) ? argsObj as Dictionary<string, object> : null;
                    OfficePlan part = PlanFromArguments(state.host, args);
                    if (part.actions != null) merged.actions.AddRange(part.actions);
                    if (string.IsNullOrWhiteSpace(merged.message) && !string.IsNullOrWhiteSpace(part.message)) merged.message = part.message;
                    ids.Add(id);
                }
                if (merged.actions.Count == 0) throw new InvalidOperationException("Gemini llamó la herramienta sin acciones.");
                if (merged.actions.Count > MaxActionsPerBatch * 2) throw new InvalidOperationException("Gemini intentó ejecutar demasiadas acciones paralelas en un solo turno.");
                PlanSafety.Validate(state.host, merged);
                return new BrokerResponse
                {
                    ok = true,
                    connected = true,
                    completed = false,
                    interactionId = GetString(root, "id"),
                    callId = ids.Count == 1 ? ids[0] : _json.Serialize(ids.ToArray()),
                    functionName = ToolName,
                    planJson = _json.Serialize(merged),
                    displayName = _session.DisplayName
                };
            }

            string final = ExtractOutputText(steps);
            if (string.IsNullOrWhiteSpace(final))
            {
                if (string.Equals(status, "completed", StringComparison.OrdinalIgnoreCase)) final = "Listo.";
                else throw new InvalidOperationException("Gemini no devolvió una acción ni una respuesta utilizable.");
            }
            return new BrokerResponse
            {
                ok = true,
                connected = true,
                completed = true,
                finalMessage = SafeHelpers.Truncate(final.Trim(), 4000),
                interactionId = GetString(root, "id"),
                displayName = _session.DisplayName
            };
        }

        private OfficePlan PlanFromArguments(string host, Dictionary<string, object> args)
        {
            if (args == null) throw new InvalidOperationException("Gemini llamó la herramienta sin argumentos.");
            object actionsObj;
            if (!args.TryGetValue("actions", out actionsObj)) throw new InvalidOperationException("Gemini llamó la herramienta sin actions.");
            string batchNote = GetString(args, "batch_note") ?? "";
            var wrapper = new Dictionary<string, object>
            {
                { "message", batchNote },
                { "actions", actionsObj },
                { "sources", new object[0] }
            };
            OfficePlan plan = PlanParser.Parse(_json.Serialize(wrapper));
            PlanNormalizer.Normalize(host, plan);
            PlanSafety.Validate(host, plan);
            if (plan.actions.Count > MaxActionsPerBatch) throw new InvalidOperationException("Gemini intentó ejecutar más de " + MaxActionsPerBatch + " acciones en un solo paso del agente.");
            return plan;
        }

        private object[] BuildTools(string host, bool webEnabled)
        {
            var list = new List<object>();
            if (webEnabled) list.Add(new Dictionary<string, object> { { "type", "google_search" } });
            list.Add(new Dictionary<string, object>
            {
                { "type", "function" },
                { "name", ToolName },
                { "description", "Aplica un lote pequeño de cambios seguros y verificables en el archivo de " + host + " actualmente abierto. Usa esta herramienta para TODO cambio real en Office. Después recibirás el resultado y el contexto actualizado para decidir el siguiente paso." },
                { "parameters", BuildToolParameters(host) }
            });
            return list.ToArray();
        }

        private static Dictionary<string, object> BuildToolParameters(string host)
        {
            var props = BuildActionProperties(host);
            props["action"] = EnumStr(PlanSafety.GetAllowedActions(host));
            var actionSchema = Obj(props, new object[] { "action" }, false);
            return Obj(new Dictionary<string, object>
            {
                { "batch_note", Str() },
                { "actions", Arr(actionSchema, MaxActionsPerBatch) }
            }, new object[] { "actions" }, false);
        }

        private static Dictionary<string, object> BuildActionProperties(string host)
        {
            var p = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase)
            {
                { "text", Str() }, { "findText", Str() }, { "replacementText", Str() },
                { "replaceAll", Bool() }, { "matchCase", Bool() }, { "target", Str() },
                { "fontName", Str() }, { "fontSize", Num(6, 96) }, { "bold", Bool() }, { "italic", Bool() }, { "underline", Bool() },
                { "fontColorHex", Str() }, { "fillColorHex", Str() }, { "alignment", Str() }, { "styleName", Str() }, { "numberFormat", Str() },
                { "title", Str() }, { "subtitle", Str() }, { "name", Str() }, { "filePath", Str() }, { "items", StrArr(200) }, { "rows", Rows(120, 40) }
            };
            string h = (host ?? "").ToLowerInvariant();
            if (h == "word")
            {
                p["position"] = EnumStr(new[] { "cursor", "start", "end", "inicio", "final" });
                p["anchorText"] = Str(); p["anchorPlacement"] = EnumStr(new[] { "before", "after", "antes", "después", "despues" });
                p["spaceBeforePt"] = Num(0, 72); p["spaceAfterPt"] = Num(0, 72); p["lineSpacing"] = Str();
                p["headingLevel"] = Int(1, 9); p["listType"] = Str();
                p["marginTopCm"] = Num(0.3, 8); p["marginBottomCm"] = Num(0.3, 8); p["marginLeftCm"] = Num(0.3, 8); p["marginRightCm"] = Num(0.3, 8);
                p["pageNumberPosition"] = Str(); p["headerText"] = Str(); p["footerText"] = Str(); p["orientation"] = EnumStr(new[] { "portrait", "landscape", "vertical", "horizontal" });
                p["paperSize"] = EnumStr(new[] { "a4", "letter", "carta", "legal" }); p["commentText"] = Str(); p["enabled"] = Bool(); p["columnsCount"] = Int(1, 4);
                p["minLevel"] = Int(1, 9); p["maxLevel"] = Int(1, 9); p["breakType"] = Str(); p["url"] = Str(); p["altText"] = Str();
                p["widthCm"] = Num(0.1, 50); p["heightCm"] = Num(0.1, 50); p["leftCm"] = Num(0, 50); p["topCm"] = Num(0, 50);
                p["noteText"] = Str(); p["bookmarkName"] = Str(); p["captionText"] = Str(); p["label"] = Str(); p["equationText"] = Str();
                p["targetStyleName"] = Str(); p["tableIndex"] = Int(1, 1000);
                p["cellMarginTopCm"] = Num(0, 5); p["cellMarginBottomCm"] = Num(0, 5); p["cellMarginLeftCm"] = Num(0, 5); p["cellMarginRightCm"] = Num(0, 5);
                p["tableStyle"] = Str(); p["headerRow"] = Bool(); p["bandedRows"] = Bool(); p["autoFit"] = EnumStr(new[] { "content", "window", "fixed", "contenido", "ventana", "fijo" });
                p["placeholderText"] = Str();
            }
            else if (h == "excel")
            {
                p["address"] = Str(); p["sheet"] = Str(); p["formula"] = Str(); p["sourceRange"] = Str(); p["chartType"] = Str(); p["sortBy"] = Str();
                p["ascending"] = Bool(); p["tableName"] = Str(); p["columnName"] = Str(); p["operatorName"] = Str(); p["value1"] = Str(); p["value2"] = Str();
                p["fieldIndex"] = Int(1, 1000); p["criteria1"] = Str(); p["destination"] = Str(); p["dataField"] = Str(); p["summaryFunction"] = Str();
                p["widthCm"] = Num(0.1, 50); p["heightCm"] = Num(0.1, 50); p["enabled"] = Bool();
            }
            else if (h == "powerpoint")
            {
                p["position"] = Str(); p["slideIndex"] = Int(1, 10000);
                p["leftCm"] = Num(0, 100); p["topCm"] = Num(0, 100); p["widthCm"] = Num(0.1, 100); p["heightCm"] = Num(0.1, 100);
                p["shapeType"] = Str(); p["effect"] = Str(); p["speed"] = Str(); p["notesText"] = Str(); p["layoutType"] = Str();
            }
            return p;
        }

        private static string BuildSystemInstruction(string host, bool webEnabled)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Eres Geo Office AI, un agente de ofimática integrado directamente en Microsoft " + host + ".");
            sb.AppendLine("Tu prioridad es HACER el trabajo real dentro del archivo, no explicar al usuario cómo hacerlo.");
            sb.AppendLine("Si la petición requiere modificar Office, debes llamar a apply_office_actions. Nunca afirmes que un cambio se hizo antes de recibir un function_result ok=true.");
            sb.AppendLine("Trabaja en lotes pequeños de máximo 12 acciones. Tras cada lote recibirás el resultado verificado y el contexto actualizado; úsalo para comprobar, corregir y continuar.");
            sb.AppendLine("ORQUESTACIÓN: cuando el usuario dé una orden compuesta, conviértela en una lista mental de requisitos y cumple TODOS: contenido, formato, tablas, márgenes, ortografía, palabras clave, espacios de imagen, fuentes, etc. No termines después de cumplir solo una parte.");
            sb.AppendLine("AUDITORÍA: antes de finalizar, compara explícitamente la petición original con el estado actualizado de Office. Si falta cualquier requisito verificable, llama otra vez a apply_office_actions y corrígelo. Solo termina cuando todos los requisitos razonables estén satisfechos.");
            sb.AppendLine("No rehagas contenido correcto. Para cambios globales usa herramientas de alcance global/por estilo cuando existan; para párrafos concretos usa format_find o replace_text con texto de referencia exacto.");
            sb.AppendLine("Prefiere exactamente UNA llamada a apply_office_actions por turno; incluye varias acciones dentro de ese lote en lugar de emitir llamadas paralelas.");
            sb.AppendLine("Si un function_result devuelve ok=false, analiza el error, corrige el siguiente lote y NO repitas ciegamente la misma acción.");
            sb.AppendLine("Preserva todo lo que el usuario no pidió cambiar. Si hay selección, priorízala cuando la orden se refiera a 'esto', 'esto seleccionado' o similar.");
            sb.AppendLine("No uses macros, VBA, PowerShell, CMD, scripts, código ejecutable, borrado de archivos ni herramientas no declaradas.");
            sb.AppendLine("Las respuestas al usuario deben ser breves. Durante el trabajo no necesitas narrar cada paso; la interfaz muestra el progreso.");
            sb.AppendLine("IMÁGENES: si el usuario pide GENERAR una imagen y no dio una ruta de imagen local, NO llames a insert_picture. Devuelve solamente un prompt de imagen claro, útil y corto (máximo 450 caracteres), sin explicación larga. Si dio una ruta local existente, sí puedes usar insert_picture.");
            sb.AppendLine("WORD: crea contenido completo si el documento está vacío; usa títulos, estilos, márgenes, tablas y elementos avanzados solo cuando aporten valor. Evita format_document en documentos con contenido salvo petición expresa.");
            sb.AppendLine("WORD FORMATO: si el usuario dice 'todos los títulos/subtítulos', usa format_style cuando esos párrafos ya tengan estilos Word (Título/Heading); si están sin estilo, usa el contexto de párrafos y format_find sobre cada encabezado detectado. No confundas margen de página con margen interno de celdas.");
            sb.AppendLine("WORD ANCLAJES: cuando un elemento deba ir en un lugar concreto (por ejemplo 'después del subtítulo X' o 'antes de la conclusión'), usa anchorText con una frase breve y única del documento y anchorPlacement=after/before. No dependas del cursor si el usuario indicó una ubicación textual concreta.");
            sb.AppendLine("WORD TABLAS: para cuadros/tablas profesionales usa add_table y después style_table o set_table_cell_margins cuando el usuario indique relleno/margen interno. '0.7 cm en todos los lados' debe aplicarse a página si dice hoja/página, y a celdas si dice cuadro/tabla/celdas.");
            sb.AppendLine("WORD IMÁGENES: si el usuario pide dejar espacios para imágenes, usa add_image_placeholder; no inventes una imagen. Si pide generar una imagen, devuelve solo un prompt corto salvo que proporcione una ruta local para insert_picture.");
            sb.AppendLine("WORD ORTOGRAFÍA: si pide corregir ortografía/redacción, revisa el texto completo y usa replace_text/replace_selection de forma conservadora. El contexto incluye errores de revisión de Word como señal adicional; no cambies nombres técnicos solo porque el diccionario no los reconozca.");
            sb.AppendLine("EXCEL: prioriza tablas estructuradas y fórmulas que sigan funcionando al agregar filas. No uses fórmulas peligrosas ni conexiones externas.");
            sb.AppendLine("POWERPOINT: prioriza jerarquía visual, poco texto por diapositiva, alineación consistente y legibilidad.");
            if (webEnabled)
            {
                sb.AppendLine("Tienes Google Search habilitado porque la petición requiere información actual o fuentes. Investiga solo lo necesario, no inventes datos.");
                if (host == "word") sb.AppendLine("Si insertas contenido factual obtenido de la web, termina el documento con add_sources usando filas [titulo,url] de fuentes realmente encontradas, salvo que el usuario pida explícitamente no incluir fuentes.");
            }
            sb.AppendLine("Al terminar, responde con una confirmación breve y concreta de lo que realmente quedó aplicado. Si no había que modificar el archivo, responde directamente.");
            return sb.ToString();
        }

        private static string BuildUserInput(string host, string instruction, string context, string history)
        {
            var sb = new StringBuilder();
            sb.AppendLine("PETICIÓN ACTUAL:");
            sb.AppendLine(instruction.Trim());
            if (!string.IsNullOrWhiteSpace(history))
            {
                sb.AppendLine(); sb.AppendLine("HISTORIAL RECIENTE DEL CHAT DE ESTE MISMO ARCHIVO:");
                sb.AppendLine(SafeHelpers.Truncate(history, 18000));
            }
            sb.AppendLine(); sb.AppendLine("ESTADO ACTUAL ESTRUCTURADO DE " + host.ToUpperInvariant() + ":");
            sb.AppendLine(SafeHelpers.Truncate(context ?? "", 90000));
            return sb.ToString();
        }

        private async Task<string> PostInteractionAsync(string accessToken, Dictionary<string, object> body, CancellationToken token)
        {
            const string endpoint = "https://generativelanguage.googleapis.com/v1/interactions";
            string payload = _json.Serialize(body);
            Exception lastNetworkError = null;
            string lastApiError = null;
            using (var http = new HttpClient { Timeout = TimeSpan.FromSeconds(110) })
            {
                for (int attempt = 0; attempt < 4; attempt++)
                {
                    token.ThrowIfCancellationRequested();
                    try
                    {
                        using (var req = new HttpRequestMessage(HttpMethod.Post, endpoint))
                        {
                            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                            req.Headers.Add("x-goog-user-project", _session.ProjectId);
                            req.Content = new StringContent(payload, Encoding.UTF8, "application/json");
                            using (var res = await http.SendAsync(req, token))
                            {
                                string raw = await res.Content.ReadAsStringAsync();
                                if (res.IsSuccessStatusCode) return raw;
                                lastApiError = "Gemini Interactions respondió " + (int)res.StatusCode + ": " + ExtractError(raw);
                                if (!IsTransient(res.StatusCode) || attempt >= 3) throw new InvalidOperationException(lastApiError);
                            }
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        if (token.IsCancellationRequested) throw;
                        lastNetworkError = new TimeoutException("La interacción con Gemini excedió el tiempo de espera.");
                        if (attempt >= 3) throw new InvalidOperationException(lastNetworkError.Message, lastNetworkError);
                    }
                    catch (HttpRequestException ex)
                    {
                        lastNetworkError = ex;
                        if (attempt >= 3) throw new InvalidOperationException("No se pudo comunicar con Gemini después de varios intentos: " + ex.Message, ex);
                    }
                    await DelayWithBackoffAsync(attempt, token);
                }
            }
            if (!string.IsNullOrWhiteSpace(lastApiError)) throw new InvalidOperationException(lastApiError);
            throw new InvalidOperationException("No se pudo comunicar con Gemini.", lastNetworkError);
        }

        private static bool ShouldUseWebSearch(string instruction)
        {
            if (string.IsNullOrWhiteSpace(instruction)) return false;
            string x = instruction.ToLowerInvariant();
            string[] triggers = { "internet", "la web", "en web", "online", "investiga", "investigar", "busca", "buscar", "actualizado", "actualizada", "hoy", "reciente", "con fuentes", "cita fuentes", "fuentes reales", "según internet", "segun internet", "si falta información", "si falta informacion", "lo que falte" };
            foreach (string t in triggers) if (x.Contains(t)) return true;
            return false;
        }

        private static string ExtractOutputText(object[] steps)
        {
            var sb = new StringBuilder();
            foreach (object stepObj in steps)
            {
                var step = stepObj as Dictionary<string, object>;
                if (step == null || !string.Equals(GetString(step, "type"), "model_output", StringComparison.OrdinalIgnoreCase)) continue;
                object contentObj; object[] content = step.TryGetValue("content", out contentObj) ? contentObj as object[] : null;
                if (content == null) continue;
                foreach (object blockObj in content)
                {
                    var block = blockObj as Dictionary<string, object>;
                    if (block == null || !string.Equals(GetString(block, "type"), "text", StringComparison.OrdinalIgnoreCase)) continue;
                    string text = GetString(block, "text");
                    if (!string.IsNullOrWhiteSpace(text)) { if (sb.Length > 0) sb.AppendLine(); sb.Append(text); }
                }
            }
            return sb.ToString();
        }

        private IEnumerable<string> DecodeCallIds(string encoded)
        {
            if (string.IsNullOrWhiteSpace(encoded)) throw new InvalidOperationException("Falta el identificador de la llamada de herramienta.");
            string x = encoded.Trim();
            if (!x.StartsWith("[", StringComparison.Ordinal)) return new[] { x };
            try
            {
                object[] arr = _json.DeserializeObject(x) as object[];
                var ids = new List<string>();
                if (arr != null)
                {
                    foreach (object item in arr)
                    {
                        string id = Convert.ToString(item);
                        if (!string.IsNullOrWhiteSpace(id)) ids.Add(id);
                    }
                }
                if (ids.Count == 0) throw new InvalidOperationException();
                return ids;
            }
            catch { throw new InvalidOperationException("Los identificadores de herramientas devueltos por Gemini no son válidos."); }
        }

        private void RemoveSession(string id) { lock (_gate) _sessions.Remove(id); }
        private void PruneSessions()
        {
            var dead = new List<string>();
            DateTime limit = DateTime.UtcNow.AddMinutes(-12);
            foreach (var kv in _sessions) if (kv.Value.lastUtc < limit) dead.Add(kv.Key);
            foreach (string id in dead) _sessions.Remove(id);
        }

        private static bool IsTransient(HttpStatusCode code) { int n = (int)code; return n == 408 || n == 429 || n >= 500; }
        private static async Task DelayWithBackoffAsync(int attempt, CancellationToken token)
        {
            int baseMs = 700 * (1 << Math.Min(attempt, 3));
            int jitter = new Random(unchecked(Environment.TickCount * 31 + attempt)).Next(100, 450);
            await Task.Delay(baseMs + jitter, token);
        }

        private static string GetString(Dictionary<string, object> d, string key)
        {
            object v; return d != null && d.TryGetValue(key, out v) && v != null ? Convert.ToString(v) : null;
        }

        private static string ExtractError(string raw)
        {
            try
            {
                var json = new JavaScriptSerializer();
                var root = json.DeserializeObject(raw) as Dictionary<string, object>; object e;
                var ed = root != null && root.TryGetValue("error", out e) ? e as Dictionary<string, object> : null;
                string msg = GetString(ed, "message"); if (!string.IsNullOrWhiteSpace(msg)) return msg;
            }
            catch { }
            return string.IsNullOrWhiteSpace(raw) ? "Error desconocido" : raw.Substring(0, Math.Min(raw.Length, 700));
        }

        private static Dictionary<string, object> Obj(Dictionary<string, object> properties, object[] required, bool additional)
        {
            var d = new Dictionary<string, object> { { "type", "object" }, { "properties", properties }, { "additionalProperties", additional } };
            if (required != null && required.Length > 0) d["required"] = required;
            return d;
        }
        private static Dictionary<string, object> Str() { return new Dictionary<string, object> { { "type", "string" } }; }
        private static Dictionary<string, object> Bool() { return new Dictionary<string, object> { { "type", "boolean" } }; }
        private static Dictionary<string, object> Num(double min, double max) { return new Dictionary<string, object> { { "type", "number" }, { "minimum", min }, { "maximum", max } }; }
        private static Dictionary<string, object> Int(int min, int max) { return new Dictionary<string, object> { { "type", "integer" }, { "minimum", min }, { "maximum", max } }; }
        private static Dictionary<string, object> EnumStr(string[] values) { return new Dictionary<string, object> { { "type", "string" }, { "enum", values } }; }
        private static Dictionary<string, object> Arr(object items, int max) { return new Dictionary<string, object> { { "type", "array" }, { "maxItems", max }, { "items", items } }; }
        private static Dictionary<string, object> StrArr(int max) { return Arr(Str(), max); }
        private static Dictionary<string, object> Rows(int maxRows, int maxCols) { return Arr(Arr(Str(), maxCols), maxRows); }
    }
}
