using GeoOfficeAI.Shared;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Broker
{
    internal sealed class GeminiPlanner
    {
        private const string Model = "gemini-3.8-flash";
        private const int MaxPlanAttempts = 3;
        private readonly OAuthSession _session;
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };

        public GeminiPlanner(OAuthSession session) { _session = session; }

        public async Task<string> CreatePlanJsonAsync(string host, string instruction, string context, CancellationToken token)
        {
            string accessToken = await _session.GetAccessTokenAsync(token);
            string research = "";
            List<WebSource> sources = new List<WebSource>();
            if (ShouldUseWebSearch(instruction))
            {
                var researchResult = await ResearchAsync(accessToken, instruction, token);
                research = researchResult.Item1;
                sources = researchResult.Item2;
            }

            OfficePlan plan = await CreateValidatedPlanAsync(accessToken, host, instruction, context, research, sources, token);
            if (sources.Count > 0)
            {
                if (plan.sources == null) plan.sources = new List<WebSource>();
                foreach (var s in sources)
                {
                    bool exists = false;
                    foreach (var p in plan.sources)
                    {
                        if (p != null && string.Equals(p.url, s.url, StringComparison.OrdinalIgnoreCase)) { exists = true; break; }
                    }
                    if (!exists) plan.sources.Add(s);
                }
            }

            PlanNormalizer.Normalize(host, plan);
            PlanSafety.Validate(host, plan);
            return _json.Serialize(plan);
        }

        private async Task<OfficePlan> CreateValidatedPlanAsync(string accessToken, string host, string instruction, string context, string research, List<WebSource> sources, CancellationToken token)
        {
            string lastText = null;
            string lastError = null;
            for (int attempt = 0; attempt < MaxPlanAttempts; attempt++)
            {
                token.ThrowIfCancellationRequested();
                string prompt = attempt == 0
                    ? BuildPlannerPrompt(host, instruction, context, research, sources)
                    : BuildRepairPrompt(host, instruction, context, research, sources, lastText, lastError);

                var body = new Dictionary<string, object>
                {
                    { "contents", new object[] { new Dictionary<string, object> { { "role", "user" }, { "parts", new object[] { new Dictionary<string, object> { { "text", prompt } } } } } } },
                    { "generationConfig", new Dictionary<string, object> {
                        { "responseMimeType", "application/json" },
                        { "responseJsonSchema", BuildPlanSchema(host) },
                        { "maxOutputTokens", 8192 }
                    } }
                };

                string raw = await PostGenerateContentAsync(accessToken, body, token);
                lastText = ExtractCandidateText(raw);
                try
                {
                    OfficePlan plan = PlanParser.Parse(lastText);
                    PlanNormalizer.Normalize(host, plan);
                    PlanSafety.Validate(host, plan);
                    return plan;
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                    if (attempt + 1 >= MaxPlanAttempts)
                        throw new InvalidOperationException("Gemini no pudo preparar un plan de Office válido y seguro después de " + MaxPlanAttempts + " intentos. Último problema: " + ex.Message);
                }
            }
            throw new InvalidOperationException("Gemini no pudo preparar un plan válido.");
        }

        private static Dictionary<string, object> BuildPlanSchema(string host)
        {
            var sourceSchema = Obj(new Dictionary<string, object>
            {
                { "title", Str() },
                { "url", Str() }
            }, new object[] { "url" }, false);

            var actionProps = BuildActionProperties(host);
            actionProps["action"] = EnumStr(PlanSafety.GetAllowedActions(host));
            var actionSchema = Obj(actionProps, new object[] { "action" }, false);

            return Obj(new Dictionary<string, object>
            {
                { "message", Str() },
                { "actions", Arr(actionSchema, 160) },
                { "sources", Arr(sourceSchema, 12) }
            }, new object[] { "message", "actions", "sources" }, false);
        }

        private static Dictionary<string, object> BuildActionProperties(string host)
        {
            var p = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase)
            {
                { "text", Str() }, { "findText", Str() }, { "replacementText", Str() },
                { "replaceAll", Bool() }, { "matchCase", Bool() }, { "target", Str() },
                { "fontName", Str() }, { "fontSize", Num(6, 96) }, { "bold", Bool() }, { "italic", Bool() }, { "underline", Bool() },
                { "fontColorHex", Str() }, { "fillColorHex", Str() }, { "alignment", Str() }, { "styleName", Str() }, { "numberFormat", Str() }
            };

            string h = (host ?? "").ToLowerInvariant();
            if (h == "word")
            {
                p["position"] = EnumStr(new[] { "cursor", "start", "end", "inicio", "final" });
                p["spaceBeforePt"] = Num(0, 72); p["spaceAfterPt"] = Num(0, 72); p["lineSpacing"] = Str();
                p["headingLevel"] = Int(1, 9); p["items"] = StrArr(200); p["listType"] = Str(); p["rows"] = Rows(100, 30);
                p["marginTopCm"] = Num(0.3, 8); p["marginBottomCm"] = Num(0.3, 8); p["marginLeftCm"] = Num(0.3, 8); p["marginRightCm"] = Num(0.3, 8);
                p["pageNumberPosition"] = Str(); p["headerText"] = Str(); p["footerText"] = Str(); p["orientation"] = EnumStr(new[] { "portrait", "landscape", "vertical", "horizontal" });
                p["paperSize"] = EnumStr(new[] { "a4", "letter", "carta", "legal" }); p["commentText"] = Str(); p["enabled"] = Bool(); p["columnsCount"] = Int(1, 4);
                p["minLevel"] = Int(1, 9); p["maxLevel"] = Int(1, 9); p["breakType"] = Str(); p["url"] = Str(); p["altText"] = Str(); p["filePath"] = Str();
                p["widthCm"] = Num(0.1, 50); p["heightCm"] = Num(0.1, 50); p["leftCm"] = Num(0, 40); p["topCm"] = Num(0, 40);
                p["noteText"] = Str(); p["bookmarkName"] = Str(); p["captionText"] = Str(); p["label"] = Str(); p["equationText"] = Str(); p["name"] = Str(); p["title"] = Str();
            }
            else if (h == "excel")
            {
                p["address"] = Str(); p["sheet"] = Str(); p["formula"] = Str(); p["name"] = Str(); p["sourceRange"] = Str(); p["chartType"] = Str(); p["sortBy"] = Str();
                p["ascending"] = Bool(); p["tableName"] = Str(); p["columnName"] = Str(); p["operatorName"] = Str(); p["value1"] = Str(); p["value2"] = Str();
                p["fieldIndex"] = Int(1, 1000); p["criteria1"] = Str(); p["destination"] = Str(); p["dataField"] = Str(); p["summaryFunction"] = Str();
                p["items"] = StrArr(200); p["rows"] = Rows(500, 100); p["filePath"] = Str(); p["widthCm"] = Num(0.1, 50); p["heightCm"] = Num(0.1, 50);
                p["enabled"] = Bool();
            }
            else if (h == "powerpoint")
            {
                p["position"] = Str(); p["slideIndex"] = Int(1, 10000); p["title"] = Str(); p["subtitle"] = Str(); p["rows"] = Rows(30, 12);
                p["leftCm"] = Num(0, 100); p["topCm"] = Num(0, 100); p["widthCm"] = Num(0.1, 100); p["heightCm"] = Num(0.1, 100);
                p["shapeType"] = Str(); p["filePath"] = Str(); p["effect"] = Str(); p["speed"] = Str(); p["notesText"] = Str(); p["layoutType"] = Str(); p["items"] = StrArr(100);
            }
            return p;
        }

        private static Dictionary<string, object> Obj(Dictionary<string, object> properties, object[] required, bool additional)
        {
            var d = new Dictionary<string, object> { { "type", "object" }, { "properties", properties }, { "additionalProperties", additional } };
            if (required != null && required.Length > 0) d["required"] = required;
            return d;
        }
        private static Dictionary<string, object> Str() { return new Dictionary<string, object> { { "type", "string" } }; }
        private static Dictionary<string, object> Bool() { return new Dictionary<string, object> { { "type", "boolean" } }; }
        private static Dictionary<string, object> Num(double min, double max) { return new Dictionary<string, object> { { "type", "number" }, { "minimum", min }, { "maximum", max } }; }
        private static Dictionary<string, object> Int(int min, int max) { return new Dictionary<string, object> { { "type", "integer" }, { "minimum", min }, { "maximum", max } }; }
        private static Dictionary<string, object> EnumStr(string[] values) { return new Dictionary<string, object> { { "type", "string" }, { "enum", values } }; }
        private static Dictionary<string, object> Arr(object items, int max) { return new Dictionary<string, object> { { "type", "array" }, { "maxItems", max }, { "items", items } }; }
        private static Dictionary<string, object> StrArr(int max) { return Arr(Str(), max); }
        private static Dictionary<string, object> Rows(int maxRows, int maxCols) { return Arr(Arr(Str(), maxCols), maxRows); }

        private async Task<Tuple<string, List<WebSource>>> ResearchAsync(string accessToken, string instruction, CancellationToken token)
        {
            string researchPrompt = "Busca en Internet solo la información necesaria para esta petición de ofimática. Responde en español, de forma breve, factual y lista para usar en un documento. No inventes datos. Petición: " + instruction;
            var body = new Dictionary<string, object>
            {
                { "contents", new object[] { new Dictionary<string, object> { { "role", "user" }, { "parts", new object[] { new Dictionary<string, object> { { "text", researchPrompt } } } } } } },
                { "tools", new object[] { new Dictionary<string, object> { { "google_search", new Dictionary<string, object>() } } } },
                { "generationConfig", new Dictionary<string, object>() }
            };
            string raw = await PostGenerateContentAsync(accessToken, body, token);
            string text = ExtractCandidateText(raw);
            return Tuple.Create(text, ExtractSources(raw));
        }

        private async Task<string> PostGenerateContentAsync(string accessToken, Dictionary<string, object> body, CancellationToken token)
        {
            string endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + Model + ":generateContent";
            string payload = _json.Serialize(body);
            Exception lastNetworkError = null;
            string lastApiError = null;

            using (var http = new HttpClient { Timeout = TimeSpan.FromSeconds(90) })
            {
                for (int attempt = 0; attempt < 4; attempt++)
                {
                    token.ThrowIfCancellationRequested();
                    try
                    {
                        using (var req = new HttpRequestMessage(HttpMethod.Post, endpoint))
                        {
                            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                            req.Headers.Add("x-goog-user-project", _session.ProjectId);
                            req.Content = new StringContent(payload, Encoding.UTF8, "application/json");
                            using (var res = await http.SendAsync(req, token))
                            {
                                string raw = await res.Content.ReadAsStringAsync();
                                if (res.IsSuccessStatusCode) return raw;

                                lastApiError = "Gemini respondió " + (int)res.StatusCode + ": " + ExtractError(raw);
                                if (!IsTransient(res.StatusCode) || attempt >= 3) throw new InvalidOperationException(lastApiError);
                            }
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        if (token.IsCancellationRequested) throw;
                        lastNetworkError = new TimeoutException("La solicitud a Gemini excedió el tiempo de espera.");
                        if (attempt >= 3) throw new InvalidOperationException(lastNetworkError.Message, lastNetworkError);
                    }
                    catch (HttpRequestException ex)
                    {
                        lastNetworkError = ex;
                        if (attempt >= 3) throw new InvalidOperationException("No se pudo comunicar con Gemini después de varios intentos: " + ex.Message, ex);
                    }

                    await DelayWithBackoffAsync(attempt, token);
                }
            }

            if (!string.IsNullOrWhiteSpace(lastApiError)) throw new InvalidOperationException(lastApiError);
            throw new InvalidOperationException("No se pudo comunicar con Gemini.", lastNetworkError);
        }

        private static bool IsTransient(HttpStatusCode code)
        {
            int n = (int)code;
            return n == 408 || n == 429 || n >= 500;
        }

        private static async Task DelayWithBackoffAsync(int attempt, CancellationToken token)
        {
            int baseMs = 700 * (1 << Math.Min(attempt, 3));
            int jitter = new Random(unchecked(Environment.TickCount * 31 + attempt)).Next(100, 450);
            await Task.Delay(baseMs + jitter, token);
        }

        private static bool ShouldUseWebSearch(string instruction)
        {
            if (string.IsNullOrWhiteSpace(instruction)) return false;
            string x = instruction.ToLowerInvariant();
            string[] triggers = { "busca en internet", "buscar en internet", "busca por internet", "buscar por internet", "busca en la web", "buscar en la web", "investiga", "actualizado", "actualiza con internet", "según internet", "con fuentes", "cita fuentes", "citas web", "información reciente", "informacion reciente" };
            foreach (var t in triggers) if (x.Contains(t)) return true;
            return false;
        }

        private static string BuildPlannerPrompt(string host, string instruction, string context, string research, List<WebSource> sources)
        {
            string actions = HostActions(host);
            var sb = new StringBuilder();
            sb.AppendLine("Eres el planificador seguro de Geo Office AI para Microsoft " + host + ".");
            sb.AppendLine("Convierte la petición del usuario en un JSON ESTRICTO con esta forma: {\"message\":\"respuesta breve\",\"actions\":[...],\"sources\":[{\"title\":\"...\",\"url\":\"...\"}]}. El response schema es obligatorio.");
            sb.AppendLine("REGLA CRÍTICA: el campo action contiene SOLO el identificador exacto de la acción, por ejemplo \"set_margins\". NUNCA escribas parámetros dentro de action, NUNCA uses set_margins{...} ni set_margins(...). Los parámetros son propiedades JSON hermanas.");
            sb.AppendLine("Ejemplo correcto Word: {\"action\":\"set_margins\",\"marginTopCm\":2,\"marginBottomCm\":2,\"marginLeftCm\":2.5,\"marginRightCm\":2.5}.");
            sb.AppendLine("message NO debe afirmar que el trabajo ya fue creado, aplicado o terminado. La aplicación solo mostrará la confirmación después de ejecutar y verificar Office. Puedes usar una descripción neutral como \"Preparé un plan para...\" o dejar una respuesta informativa si actions está vacío.");
            sb.AppendLine("No devuelvas markdown, comentarios, macros, VBA, PowerShell, scripts ni código ejecutable.");
            sb.AppendLine("Usa SOLO acciones de la lista permitida. Si no hace falta modificar el archivo, devuelve actions vacío y responde en message.");
            sb.AppendLine("No existe generación de imágenes en esta aplicación. Si el usuario pide una imagen, crea en message un prompt excelente para usarlo en Gemini web. No finjas que generaste una imagen.");
            sb.AppendLine("No borres hojas, diapositivas ni archivos. No uses macros, código, conexiones externas, vínculos de libro ni fórmulas peligrosas.");
            sb.AppendLine("Piensa como un especialista de ofimática: una petición puede requerir MUCHAS acciones coordinadas. Devuelve el plan completo en el orden correcto, pero no cambies elementos ajenos a la petición.");
            sb.AppendLine("Si el usuario pide un trabajo profesional, no basta con escribir texto: usa estructura, jerarquía, espaciado, estilos y tablas/gráficos solo cuando aporten valor.");
            sb.AppendLine("WORD: en un documento VACÍO puedes usar format_document para un estilo base coherente y después títulos, párrafos, márgenes y tablas cuando ayuden. Si el documento ya contiene contenido, NO uses format_document salvo que el usuario pida expresamente reformatear todo el documento; prefiere selección o acciones localizadas. En documento vacío, inserta realmente todo el contenido necesario. Para una sola página, sé conciso.");
            sb.AppendLine("EXCEL: cuando los cálculos deban crecer al agregar filas, prefiere Tabla de Excel + create_calculated_column. Usa fórmulas compatibles con .Formula y nombres de funciones en inglés.");
            sb.AppendLine("POWERPOINT: poco texto por diapositiva, jerarquía visual consistente, tamaños legibles, alineación y transiciones discretas. Si falta una imagen local, usa add_image_placeholder.");
            sb.AppendLine("Si hay INFORMACIÓN OBTENIDA DE GOOGLE SEARCH, úsala para contenido factual y conserva las URLs de FUENTES DISPONIBLES.");
            sb.AppendLine("Acciones permitidas para " + host + ":\n" + actions);
            sb.AppendLine("PETICIÓN DEL USUARIO:\n" + instruction);
            if (!string.IsNullOrWhiteSpace(research)) sb.AppendLine("INFORMACIÓN OBTENIDA DE GOOGLE SEARCH:\n" + research);
            if (sources != null && sources.Count > 0)
            {
                sb.AppendLine("FUENTES DISPONIBLES:");
                foreach (var s in sources) sb.AppendLine("- " + (s.title ?? "Fuente") + " | " + s.url);
            }
            sb.AppendLine("CONTEXTO ACTUAL DE " + host.ToUpperInvariant() + ":\n" + context);
            sb.AppendLine("Mantén los cambios mínimos necesarios y preserva el contenido/formatos que el usuario no pidió modificar.");
            return sb.ToString();
        }

        private static string BuildRepairPrompt(string host, string instruction, string context, string research, List<WebSource> sources, string invalidPlan, string error)
        {
            var sb = new StringBuilder(BuildPlannerPrompt(host, instruction, context, research, sources));
            sb.AppendLine();
            sb.AppendLine("EL PLAN ANTERIOR FUE RECHAZADO ANTES DE TOCAR OFFICE.");
            sb.AppendLine("Motivo de validación: " + SafeHelpers.Truncate(error ?? "Error desconocido", 1200));
            sb.AppendLine("Plan anterior (solo para corregirlo, no lo copies ciegamente):");
            sb.AppendLine(SafeHelpers.Truncate(invalidPlan ?? "", 12000));
            sb.AppendLine("Devuelve un plan nuevo que preserve la intención del usuario pero corrija exactamente el problema. action debe ser siempre un identificador exacto y los parámetros deben ir en propiedades separadas.");
            return sb.ToString();
        }

        private static string HostActions(string host)
        {
            switch ((host ?? "").ToLowerInvariant())
            {
                case "word":
                    return "replace_selection{text}; insert_text{text,position}; replace_text{findText,replacementText,replaceAll,matchCase}; format_selection{fontName,fontSize,bold,italic,underline,fontColorHex,alignment,styleName,spaceBeforePt,spaceAfterPt,lineSpacing}; format_document{fontName,fontSize,fontColorHex,alignment,styleName,spaceBeforePt,spaceAfterPt,lineSpacing}; format_find{findText,...formato}; add_heading{text,headingLevel,position}; add_list{items,listType,position}; add_table{rows,position}; set_margins{marginTopCm,marginBottomCm,marginLeftCm,marginRightCm}; set_orientation{orientation}; set_paper_size{paperSize}; set_header{headerText}; set_footer{footerText}; add_page_numbers{pageNumberPosition}; page_break{position}; insert_section_break{position,breakType}; set_columns{columnsCount}; add_toc{position,minLevel,maxLevel}; add_hyperlink{text,url,position,altText}; add_comment{commentText}; track_changes{enabled}; insert_picture{filePath,position,widthCm,heightCm,target,altText}; add_sources{rows:[titulo,url],title,position}; add_footnote{noteText,findText}; add_bookmark{bookmarkName,findText}; add_textbox{text,position,leftCm,topCm,widthCm,heightCm,...formato}; insert_equation{equationText,position}; add_caption{captionText,label,position}.";
                case "excel":
                    return "set_cell{address,text,sheet}; set_formula{address,formula,sheet}; set_range_values{address,rows,sheet}; format_range{address,sheet,fontName,fontSize,bold,italic,underline,fontColorHex,fillColorHex,alignment,numberFormat}; autofit{address,sheet}; create_table{address,sheet,name,styleName}; create_calculated_column{sheet,tableName,columnName,formula}; conditional_format{address,sheet,target,operatorName,value1,value2,formula,fillColorHex,fontColorHex,bold}; data_validation{address,sheet,target,items,value1,value2,operatorName}; sort_range{address,sheet,sortBy,ascending}; filter_range{address,sheet,fieldIndex,criteria1}; create_chart{sourceRange,sheet,chartType,title}; create_pivot_table{sourceRange,sheet,destination,name,items,dataField,summaryFunction}; define_name{name,address,sheet}; show_totals_row{sheet,tableName,enabled,dataField,summaryFunction}; set_calculation{target}; add_sheet{name}; rename_sheet{sheet,name}; merge_range{address,sheet}; freeze_top_row{}; replace_text{findText,replacementText,replaceAll,matchCase}; insert_picture{filePath,address,sheet,widthCm,heightCm}.";
                case "powerpoint":
                    return "add_slide{title,text,position}; set_slide_title{slideIndex,title}; set_slide_layout{slideIndex,layoutType}; add_textbox{slideIndex,text,leftCm,topCm,widthCm,heightCm,fontName,fontSize,bold,fontColorHex,alignment}; replace_text{findText,replacementText,replaceAll,matchCase}; format_text{slideIndex,findText,fontName,fontSize,bold,italic,underline,fontColorHex,alignment}; add_table{slideIndex,rows,leftCm,topCm,widthCm,heightCm}; add_shape{slideIndex,shapeType,text,leftCm,topCm,widthCm,heightCm,fillColorHex,fontColorHex}; add_image_placeholder{slideIndex,text,leftCm,topCm,widthCm,heightCm,fontColorHex}; set_background{slideIndex,fillColorHex}; apply_professional_style{fontName,fontSize,fontColorHex,fillColorHex}; set_transition{slideIndex,effect,speed}; add_animation{slideIndex,target,effect,position}; align_shapes{slideIndex,items,alignment}; distribute_shapes{slideIndex,items,target}; set_notes{slideIndex,notesText}; apply_theme{filePath}; duplicate_slide{slideIndex}; insert_picture{slideIndex,filePath,leftCm,topCm,widthCm,heightCm}.";
                default: return "No hay acciones disponibles.";
            }
        }

        private string ExtractCandidateText(string raw)
        {
            var root = _json.DeserializeObject(raw) as Dictionary<string, object>;
            object candidatesObj;
            if (root == null || !root.TryGetValue("candidates", out candidatesObj)) throw new InvalidOperationException("Gemini no devolvió candidatos.");
            var candidates = candidatesObj as object[];
            if (candidates == null || candidates.Length == 0) throw new InvalidOperationException("Gemini no devolvió contenido.");
            var first = candidates[0] as Dictionary<string, object>;
            object contentObj;
            if (first == null || !first.TryGetValue("content", out contentObj)) throw new InvalidOperationException("Respuesta Gemini sin content.");
            var content = contentObj as Dictionary<string, object>;
            object partsObj;
            if (content == null || !content.TryGetValue("parts", out partsObj)) throw new InvalidOperationException("Respuesta Gemini sin parts.");
            var parts = partsObj as object[];
            var sb = new StringBuilder();
            if (parts != null)
            {
                foreach (object pObj in parts)
                {
                    var p = pObj as Dictionary<string, object>;
                    object t;
                    if (p != null && p.TryGetValue("text", out t) && t != null) sb.Append(Convert.ToString(t));
                }
            }
            if (sb.Length == 0) throw new InvalidOperationException("Gemini no devolvió texto utilizable.");
            return sb.ToString();
        }

        private List<WebSource> ExtractSources(string raw)
        {
            var result = new List<WebSource>();
            try
            {
                var root = _json.DeserializeObject(raw) as Dictionary<string, object>;
                object candidatesObj;
                var candidates = root != null && root.TryGetValue("candidates", out candidatesObj) ? candidatesObj as object[] : null;
                if (candidates == null) return result;
                foreach (var cObj in candidates)
                {
                    var c = cObj as Dictionary<string, object>;
                    object gmObj;
                    var gm = c != null && c.TryGetValue("groundingMetadata", out gmObj) ? gmObj as Dictionary<string, object> : null;
                    object chunksObj;
                    var chunks = gm != null && gm.TryGetValue("groundingChunks", out chunksObj) ? chunksObj as object[] : null;
                    if (chunks == null) continue;
                    foreach (var chObj in chunks)
                    {
                        var ch = chObj as Dictionary<string, object>; object webObj;
                        var web = ch != null && ch.TryGetValue("web", out webObj) ? webObj as Dictionary<string, object> : null;
                        if (web == null) continue;
                        string uri = GetString(web, "uri"); string title = GetString(web, "title");
                        if (string.IsNullOrWhiteSpace(uri)) continue;
                        bool exists = false; foreach (var s in result) if (string.Equals(s.url, uri, StringComparison.OrdinalIgnoreCase)) { exists = true; break; }
                        if (!exists) result.Add(new WebSource { title = title, url = uri });
                        if (result.Count >= 8) return result;
                    }
                }
            }
            catch { }
            return result;
        }

        private static string GetString(Dictionary<string, object> d, string key) { object v; return d != null && d.TryGetValue(key, out v) && v != null ? Convert.ToString(v) : null; }
        private static string ExtractError(string raw)
        {
            try
            {
                var json = new JavaScriptSerializer();
                var root = json.DeserializeObject(raw) as Dictionary<string, object>; object e;
                var ed = root != null && root.TryGetValue("error", out e) ? e as Dictionary<string, object> : null;
                string msg = GetString(ed, "message"); if (!string.IsNullOrWhiteSpace(msg)) return msg;
            }
            catch { }
            return string.IsNullOrWhiteSpace(raw) ? "Error desconocido" : raw.Substring(0, Math.Min(raw.Length, 500));
        }
    }
}
