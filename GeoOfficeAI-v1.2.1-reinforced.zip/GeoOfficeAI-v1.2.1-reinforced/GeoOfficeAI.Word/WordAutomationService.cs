using GeoOfficeAI.Shared;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;

namespace GeoOfficeAI.WordAddIn
{
    public sealed class WordAutomationService : IOfficeHost
    {
        private readonly Word.Application _app;
        private string _lastTempFile;
        private int? _executionCursor;

        public WordAutomationService(Word.Application app) { _app = app; }
        public string HostName { get { return "Word"; } }
        public string HostLabel { get { return "Microsoft Word " + (_app.Version ?? "") + " · documento actual"; } }

        public string GetDocumentSessionId()
        {
            try
            {
                Word.Document doc = _app.ActiveDocument;
                return doc == null ? "word:none" : "word:runtime:" + RuntimeHelpers.GetHashCode(doc).ToString();
            }
            catch { return "word:none"; }
        }

        public string GetPersistentDocumentKey()
        {
            try
            {
                Word.Document doc = _app.ActiveDocument;
                if (doc == null || string.IsNullOrWhiteSpace(doc.Path)) return null;
                string full = doc.FullName;
                return !string.IsNullOrWhiteSpace(full) && File.Exists(full) ? "word:" + Path.GetFullPath(full) : null;
            }
            catch { return null; }
        }

        public string GetDocumentDisplayName()
        {
            try { return _app.ActiveDocument == null ? "Sin documento" : (_app.ActiveDocument.Name ?? "Documento"); }
            catch { return "Documento"; }
        }

        public string GetContext(int maxCharacters)
        {
            var sb = new StringBuilder();
            Word.Document doc = _app.ActiveDocument;
            if (doc == null) return "No hay documento abierto.";

            sb.AppendLine("[DOCUMENTO]");
            sb.AppendLine("Nombre: " + (doc.Name ?? "Sin nombre"));
            try { sb.AppendLine("Ruta: " + (string.IsNullOrWhiteSpace(doc.Path) ? "NO GUARDADO" : doc.FullName)); } catch { }
            try { sb.AppendLine("Guardado sin cambios pendientes: " + doc.Saved); } catch { }
            try { sb.AppendLine("Páginas: " + doc.ComputeStatistics(Word.WdStatistic.wdStatisticPages) + " | Secciones: " + doc.Sections.Count + " | Párrafos: " + doc.Paragraphs.Count + " | Tablas: " + doc.Tables.Count + " | Imágenes inline: " + doc.InlineShapes.Count + " | Formas: " + doc.Shapes.Count); } catch { }
            try { sb.AppendLine("Hipervínculos: " + doc.Hyperlinks.Count + " | Comentarios: " + doc.Comments.Count + " | Marcadores: " + doc.Bookmarks.Count + " | Control de cambios: " + doc.TrackRevisions); } catch { }
            try
            {
                int spelling = doc.Content.SpellingErrors.Count;
                int grammar = doc.Content.GrammaticalErrors.Count;
                sb.AppendLine("Revisión Word: ortografía=" + spelling + " | gramática=" + grammar);
                if (spelling > 0)
                {
                    sb.AppendLine("[MUESTRA ERRORES ORTOGRÁFICOS]");
                    int max = Math.Min(spelling, 48);
                    for (int i = 1; i <= max; i++)
                    {
                        try
                        {
                            Word.Range er = doc.Content.SpellingErrors[i];
                            string et = (er.Text ?? "").Trim().Replace("\r", " ").Replace("\n", " ");
                            if (et.Length > 0) sb.AppendLine("- " + SafeHelpers.Truncate(et, 100));
                        }
                        catch { }
                    }
                }
            }
            catch { }

            try
            {
                Word.Selection sel = _app.Selection;
                if (sel != null)
                {
                    string selected = (sel.Text ?? "").Trim();
                    sb.AppendLine("[CURSOR/SELECCIÓN]");
                    sb.AppendLine("Rango: " + sel.Range.Start + "-" + sel.Range.End + " | Tipo: " + sel.Type);
                    try { sb.AppendLine("Estilo: " + GetStyleName(sel.get_Style())); } catch { }
                    try { sb.AppendLine("Fuente: " + sel.Font.Name + " " + sel.Font.Size + " pt | Negrita: " + sel.Font.Bold + " | Cursiva: " + sel.Font.Italic); } catch { }
                    if (selected.Length > 0)
                    {
                        sb.AppendLine("Texto seleccionado:");
                        sb.AppendLine(SafeHelpers.Truncate(selected, Math.Min(18000, maxCharacters / 3)));
                    }
                }
            }
            catch { }

            try
            {
                sb.AppendLine("[SECCIONES]");
                int count = Math.Min(doc.Sections.Count, 12);
                for (int i = 1; i <= count; i++)
                {
                    Word.Section sec = doc.Sections[i];
                    Word.PageSetup ps = sec.PageSetup;
                    sb.AppendLine("Sección " + i + ": orientación=" + ps.Orientation + ", márgenes(pt)=" + Math.Round(ps.TopMargin) + "/" + Math.Round(ps.BottomMargin) + "/" + Math.Round(ps.LeftMargin) + "/" + Math.Round(ps.RightMargin) + ", columnas=" + ps.TextColumns.Count);
                }
            }
            catch { }

            try
            {
                sb.AppendLine("[ESTRUCTURA DE PÁRRAFOS]");
                int maxParagraphs = Math.Min(doc.Paragraphs.Count, 120);
                for (int i = 1; i <= maxParagraphs && sb.Length < maxCharacters * 0.62; i++)
                {
                    Word.Paragraph para = doc.Paragraphs[i];
                    string t = (para.Range.Text ?? "").Trim().Replace("\r", " ").Replace("\n", " ");
                    if (t.Length == 0) continue;
                    string style = "";
                    string fmt = "";
                    try { style = GetStyleName(para.get_Style()); } catch { }
                    try
                    {
                        float fs = para.Range.Font.Size;
                        int fb = para.Range.Font.Bold;
                        int fi = para.Range.Font.Italic;
                        var al = para.Range.ParagraphFormat.Alignment;
                        var ol = para.OutlineLevel;
                        fmt = " size=" + fs + " bold=" + fb + " italic=" + fi + " align=" + al + " outline=" + ol;
                    }
                    catch { }
                    sb.Append("P").Append(i).Append(" [").Append(style).Append(fmt).Append("] ").AppendLine(SafeHelpers.Truncate(t, 320));
                }
            }
            catch { }

            try
            {
                if (doc.Tables.Count > 0)
                {
                    sb.AppendLine("[TABLAS]");
                    int maxTables = Math.Min(doc.Tables.Count, 20);
                    for (int ti = 1; ti <= maxTables && sb.Length < maxCharacters * 0.74; ti++)
                    {
                        Word.Table table = doc.Tables[ti];
                        string tableMeta = "";
                        try { tableMeta = " padding(pt)=" + Math.Round(table.TopPadding, 1) + "/" + Math.Round(table.BottomPadding, 1) + "/" + Math.Round(table.LeftPadding, 1) + "/" + Math.Round(table.RightPadding, 1) + " autofit=" + table.AllowAutoFit; } catch { }
                        sb.AppendLine("Tabla " + ti + ": " + table.Rows.Count + "x" + table.Columns.Count + tableMeta);
                        int rmax = Math.Min(table.Rows.Count, 6), cmax = Math.Min(table.Columns.Count, 6);
                        for (int r = 1; r <= rmax; r++)
                        {
                            var row = new StringBuilder();
                            for (int c = 1; c <= cmax; c++)
                            {
                                if (c > 1) row.Append(" | ");
                                try { row.Append((table.Cell(r, c).Range.Text ?? "").TrimEnd('\r', '\a').Replace("\r", " ")); } catch { row.Append("?"); }
                            }
                            sb.AppendLine(SafeHelpers.Truncate(row.ToString(), 600));
                        }
                    }
                }
            }
            catch { }

            sb.AppendLine("[CONTENIDO COMPLETO/TRUNCADO]");
            string body = "";
            try { body = doc.Content.Text ?? ""; } catch { }
            sb.AppendLine(SafeHelpers.Truncate(body, Math.Max(1200, maxCharacters - sb.Length)));
            return SafeHelpers.Truncate(sb.ToString(), maxCharacters);
        }

        private static string GetStyleName(object styleObject)
        {
            if (styleObject == null) return "";
            try
            {
                Word.Style style = styleObject as Word.Style;
                if (style != null) return style.NameLocal ?? "";
            }
            catch { }
            try
            {
                dynamic d = styleObject;
                string local = Convert.ToString(d.NameLocal);
                if (!string.IsNullOrWhiteSpace(local)) return local;
                return Convert.ToString(d.Name) ?? "";
            }
            catch { return Convert.ToString(styleObject) ?? ""; }
        }

        public string DescribePlan(OfficePlan plan)
        {
            var sb = new StringBuilder();
            if (plan == null || plan.actions == null) return "Sin cambios.";
            foreach (var a in plan.actions) sb.AppendLine("• " + (a == null ? "acción" : a.action));
            return sb.ToString();
        }

        public Task ApplyPlanAsync(OfficePlan plan, CancellationToken token)
        {
            PlanSafety.Validate("word", plan);
            if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA) throw new InvalidOperationException("Word debe modificarse desde un hilo STA de Office. La operación fue bloqueada para evitar errores COM.");
            if (plan == null || plan.actions == null || plan.actions.Count == 0) return Task.CompletedTask;

            Word.Document doc = _app.ActiveDocument;
            if (doc == null) throw new InvalidOperationException("No hay un documento de Word abierto.");
            if (doc.ProtectionType != Word.WdProtectionType.wdNoProtection)
                throw new InvalidOperationException("El documento está protegido. Quita la protección antes de pedir cambios a la IA.");
            try
            {
                dynamic ddoc = doc;
                if ((bool)ddoc.ReadOnly) throw new InvalidOperationException("El documento está abierto como solo lectura y no se puede modificar.");
            }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException) { }

            PreflightPlan(doc, plan);

            try
            {
                Word.Selection sel = _app.Selection;
                int initial = sel == null ? Math.Max(0, doc.Content.End - 1) : sel.Range.End;
                _executionCursor = Math.Max(0, Math.Min(Math.Max(0, doc.Content.End - 1), initial));
            }
            catch { _executionCursor = Math.Max(0, doc.Content.End - 1); }

            Word.UndoRecord undo;
            try
            {
                undo = _app.UndoRecord;
                undo.StartCustomRecord("Geo Office AI");
            }
            catch (Exception ex)
            {
                _executionCursor = null;
                throw new InvalidOperationException("Word no pudo iniciar una transacción segura de Deshacer. No se aplicó ningún cambio. " + ex.Message);
            }

            bool recordOpen = true;
            try
            {
                for (int i = 0; i < plan.actions.Count; i++)
                {
                    token.ThrowIfCancellationRequested();
                    OfficeAction action = plan.actions[i];
                    if (action == null) continue;
                    try { ApplyAction(doc, action); }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException("Falló la acción " + (i + 1) + " (" + action.action + "): " + ex.Message, ex);
                    }
                }
                token.ThrowIfCancellationRequested();
                undo.EndCustomRecord();
                recordOpen = false;
                return Task.CompletedTask;
            }
            catch (OperationCanceledException)
            {
                if (recordOpen) { try { undo.EndCustomRecord(); } catch { } recordOpen = false; }
                bool rolledBack = TryRollback(doc);
                if (!rolledBack)
                    throw new InvalidOperationException("La operación se canceló, pero Word no pudo revertir automáticamente todos los cambios. Usa Deshacer de Word antes de continuar.");
                throw;
            }
            catch (Exception ex)
            {
                if (recordOpen) { try { undo.EndCustomRecord(); } catch { } recordOpen = false; }
                bool rolledBack = TryRollback(doc);
                string suffix = rolledBack ? " Los cambios parciales fueron revertidos." : " Word no pudo confirmar la reversión automática; usa Deshacer de Word antes de continuar.";
                throw new InvalidOperationException(ex.Message + suffix, ex);
            }
            finally
            {
                if (recordOpen) { try { undo.EndCustomRecord(); } catch { } }
                _executionCursor = null;
            }
        }

        private static void PreflightPlan(Word.Document doc, OfficePlan plan)
        {
            if (plan == null || plan.actions == null) return;
            foreach (OfficeAction a in plan.actions)
            {
                if (a == null) continue;
                string action = (a.action ?? "").Trim().ToLowerInvariant();
                if (action == "replace_text" || action == "format_find" || ((action == "add_footnote" || action == "add_bookmark") && !string.IsNullOrWhiteSpace(a.findText)))
                {
                    if (!DocumentContains(doc, a.findText, a.matchCase ?? false))
                        throw new InvalidOperationException("No se encontró el texto de referencia: " + a.findText + ". No se aplicó ningún cambio.");
                }
                else if (action == "add_comment")
                {
                    Word.Selection sel = doc.Application.Selection;
                    if (sel == null) throw new InvalidOperationException("No hay una selección disponible para agregar el comentario. No se aplicó ningún cambio.");
                }
            }
        }

        private static bool DocumentContains(Word.Document doc, string text, bool matchCase)
        {
            if (string.IsNullOrWhiteSpace(text)) return false;
            Word.Range r = doc.Content.Duplicate;
            dynamic find = r.Find;
            find.ClearFormatting();
            return find.Execute(FindText: text, MatchCase: matchCase, Forward: true, Wrap: Word.WdFindWrap.wdFindStop);
        }

        private static bool TryRollback(Word.Document doc)
        {
            try
            {
                dynamic ddoc = doc;
                return (bool)ddoc.Undo(1);
            }
            catch { return false; }
        }

        private void ApplyAction(Word.Document doc, OfficeAction a)
        {
            string action = (a.action ?? "").Trim().ToLowerInvariant();
            switch (action)
            {
                case "replace_selection":
                    {
                        Word.Selection sel = _app.Selection;
                        if (sel == null) throw new InvalidOperationException("No hay una selección disponible en Word.");
                        int start = sel.Range.Start;
                        string replacement = a.text ?? "";
                        sel.Range.Text = replacement;
                        Word.Range inserted = doc.Range(start, start + replacement.Length);
                        if (HasFormatting(a)) ApplyFormat(inserted, a);
                        AdvanceCursor(doc, inserted.End);
                    }
                    break;
                case "insert_text":
                    InsertText(doc, a);
                    break;
                case "replace_text":
                    ReplaceText(doc, a);
                    break;
                case "format_selection":
                    ApplyFormat(_app.Selection.Range, a);
                    break;
                case "format_document":
                    ApplyFormat(doc.Content, a);
                    break;
                case "format_find":
                    FormatFind(doc, a);
                    break;
                case "add_heading":
                    AddHeading(doc, a);
                    break;
                case "add_list":
                    AddList(doc, a);
                    break;
                case "add_table":
                    AddTable(doc, a);
                    break;
                case "set_margins":
                    SetMargins(doc, a);
                    break;
                case "set_orientation":
                    SetOrientation(doc, a.orientation);
                    break;
                case "set_paper_size":
                    SetPaperSize(doc, a.paperSize);
                    break;
                case "set_header":
                    SetHeader(doc, a.headerText ?? a.text ?? "");
                    break;
                case "set_footer":
                    SetFooter(doc, a.footerText ?? a.text ?? "");
                    break;
                case "add_page_numbers":
                    AddPageNumbers(doc, a.pageNumberPosition);
                    break;
                case "page_break":
                    InsertPageBreak(doc, a);
                    break;
                case "add_comment":
                    AddComment(doc, a.commentText ?? a.text ?? "Comentario de Gemini");
                    break;
                case "track_changes":
                    {
                        bool expected = a.enabled ?? true;
                        doc.TrackRevisions = expected;
                        if (doc.TrackRevisions != expected) throw new InvalidOperationException("Word no confirmó el estado de Control de cambios.");
                    }
                    break;
                case "insert_picture":
                    InsertPicture(doc, a);
                    break;
                case "set_columns":
                    SetColumns(doc, a.columnsCount ?? 1);
                    break;
                case "add_toc":
                    AddTableOfContents(doc, a);
                    break;
                case "add_hyperlink":
                    AddHyperlink(doc, a);
                    break;
                case "insert_section_break":
                    InsertSectionBreak(doc, a);
                    break;
                case "add_sources":
                    AddSources(doc, a);
                    break;
                case "add_footnote":
                    AddFootnote(doc, a);
                    break;
                case "add_bookmark":
                    AddBookmark(doc, a);
                    break;
                case "add_textbox":
                    AddTextBox(doc, a);
                    break;
                case "insert_equation":
                    InsertEquation(doc, a);
                    break;
                case "add_caption":
                    AddCaption(doc, a);
                    break;
                case "format_style":
                    FormatStyle(doc, a);
                    break;
                case "set_table_cell_margins":
                    SetTableCellMargins(doc, a);
                    break;
                case "style_table":
                    StyleTable(doc, a);
                    break;
                case "add_image_placeholder":
                    AddImagePlaceholder(doc, a);
                    break;
                default:
                    throw new InvalidOperationException("Acción de Word no permitida: " + a.action);
            }
        }

        private void InsertText(Word.Document doc, OfficeAction a)
        {
            string text = a.text ?? "";
            Word.Range r = GetInsertionRange(doc, a);
            int start = r.Start; int beforeEnd = r.End;
            r.InsertAfter(text);
            if (!string.IsNullOrEmpty(text) && r.End <= beforeEnd) throw new InvalidOperationException("Word no confirmó la inserción del texto.");
            Word.Range inserted = doc.Range(start, r.End);
            if (HasFormatting(a)) ApplyFormat(inserted, a);
            AdvanceCursor(doc, inserted.End);
        }

        private Word.Range GetInsertionRange(Word.Document doc, OfficeAction action)
        {
            if (action != null && !string.IsNullOrWhiteSpace(action.anchorText))
            {
                string anchor = action.anchorText.Trim();
                Word.Range r = doc.Content.Duplicate;
                dynamic find = r.Find;
                bool found = find.Execute(FindText: anchor, MatchCase: false, Forward: true, Wrap: Word.WdFindWrap.wdFindStop);
                if (!found) throw new InvalidOperationException("No se encontró el texto de anclaje: " + anchor);
                string place = (action.anchorPlacement ?? "after").Trim().ToLowerInvariant();
                if (place == "before" || place == "antes") r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
                else r.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                return r;
            }
            return GetInsertionRange(doc, action == null ? null : action.position);
        }

        private Word.Range GetInsertionRange(Word.Document doc, string position)
        {
            string p = (position ?? "cursor").ToLowerInvariant();
            if (p == "start" || p == "inicio") return doc.Range(0, 0);
            if (p == "end" || p == "final")
            {
                int end = Math.Max(0, doc.Content.End - 1);
                return doc.Range(end, end);
            }

            int cursor;
            if (_executionCursor.HasValue) cursor = _executionCursor.Value;
            else
            {
                try { cursor = _app.Selection.Range.End; }
                catch { cursor = Math.Max(0, doc.Content.End - 1); }
            }
            cursor = Math.Max(0, Math.Min(Math.Max(0, doc.Content.End - 1), cursor));
            return doc.Range(cursor, cursor);
        }

        private void AdvanceCursor(Word.Document doc, int position)
        {
            int max = Math.Max(0, doc.Content.End - 1);
            _executionCursor = Math.Max(0, Math.Min(max, position));
        }

        private static void ReplaceText(Word.Document doc, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("replace_text requiere findText.");
            Word.Range r = doc.Content.Duplicate;
            dynamic find = r.Find;
            find.ClearFormatting();
            find.Replacement.ClearFormatting();
            object replace = (a.replaceAll ?? false) ? Word.WdReplace.wdReplaceAll : Word.WdReplace.wdReplaceOne;
            bool found = find.Execute(FindText: a.findText, MatchCase: a.matchCase ?? false, ReplaceWith: a.replacementText ?? "", Replace: replace);
            if (!found) throw new InvalidOperationException("No se encontró el texto que debía reemplazarse: " + a.findText);
        }

        private static void FormatFind(Word.Document doc, OfficeAction a)
        {
            if (string.IsNullOrWhiteSpace(a.findText)) throw new InvalidOperationException("format_find requiere findText.");
            Word.Range search = doc.Content.Duplicate;
            int applied = 0;
            while (applied < 100)
            {
                dynamic find = search.Find;
                find.ClearFormatting();
                bool found = find.Execute(FindText: a.findText, MatchCase: a.matchCase ?? false, Forward: true, Wrap: Word.WdFindWrap.wdFindStop);
                if (!found) break;
                ApplyFormat(search, a);
                applied++;
                int next = search.End;
                if (next >= doc.Content.End) break;
                search.SetRange(next, doc.Content.End);
                if (!(a.replaceAll ?? false)) break;
            }
            if (applied == 0) throw new InvalidOperationException("No se encontró el texto que debía formatearse: " + a.findText);
        }

        private static bool HasFormatting(OfficeAction a)
        {
            return a != null && (!string.IsNullOrWhiteSpace(a.fontName) || a.fontSize.HasValue || a.bold.HasValue || a.italic.HasValue || a.underline.HasValue ||
                !string.IsNullOrWhiteSpace(a.fontColorHex) || !string.IsNullOrWhiteSpace(a.fillColorHex) || !string.IsNullOrWhiteSpace(a.alignment) || !string.IsNullOrWhiteSpace(a.styleName) ||
                a.spaceBeforePt.HasValue || a.spaceAfterPt.HasValue || !string.IsNullOrWhiteSpace(a.lineSpacing));
        }

        private static void ApplyFormat(Word.Range r, OfficeAction a)
        {
            if (r == null) return;
            if (!string.IsNullOrWhiteSpace(a.styleName)) ApplyStyle(r, a.styleName);
            if (!string.IsNullOrWhiteSpace(a.fontName)) r.Font.Name = a.fontName;
            if (a.fontSize.HasValue && a.fontSize.Value >= 6 && a.fontSize.Value <= 96) r.Font.Size = (float)a.fontSize.Value;
            if (a.bold.HasValue) r.Font.Bold = a.bold.Value ? 1 : 0;
            if (a.italic.HasValue) r.Font.Italic = a.italic.Value ? 1 : 0;
            if (a.underline.HasValue) r.Font.Underline = a.underline.Value ? Word.WdUnderline.wdUnderlineSingle : Word.WdUnderline.wdUnderlineNone;
            if (!string.IsNullOrWhiteSpace(a.fontColorHex)) r.Font.Color = (Word.WdColor)SafeHelpers.ParseRgb(a.fontColorHex, (int)Word.WdColor.wdColorAutomatic);
            if (!string.IsNullOrWhiteSpace(a.fillColorHex))
            {
                try { r.Shading.BackgroundPatternColor = (Word.WdColor)SafeHelpers.ParseRgb(a.fillColorHex, (int)Word.WdColor.wdColorAutomatic); } catch { }
            }
            if (!string.IsNullOrWhiteSpace(a.alignment))
            {
                string x = a.alignment.ToLowerInvariant();
                if (x == "center" || x == "centrado") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                else if (x == "right" || x == "derecha") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                else if (x == "justify" || x == "justificado") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                else if (x == "left" || x == "izquierda") r.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            }
            if (a.spaceBeforePt.HasValue) r.ParagraphFormat.SpaceBefore = (float)Math.Max(0, Math.Min(72, a.spaceBeforePt.Value));
            if (a.spaceAfterPt.HasValue) r.ParagraphFormat.SpaceAfter = (float)Math.Max(0, Math.Min(72, a.spaceAfterPt.Value));
            if (!string.IsNullOrWhiteSpace(a.lineSpacing))
            {
                string ls = a.lineSpacing.ToLowerInvariant();
                if (ls.Contains("1.5")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpace1pt5;
                else if (ls.Contains("double") || ls.Contains("doble")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceDouble;
                else if (ls.Contains("single") || ls.Contains("sencillo")) r.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
            }
        }

        private static void ApplyStyle(Word.Range r, string styleName)
        {
            string x = (styleName ?? "").Trim().ToLowerInvariant();
            try
            {
                if (x == "normal") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleNormal; }
                else if (x == "title" || x == "título" || x == "titulo") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleTitle; }
                else if (x == "subtitle" || x == "subtítulo" || x == "subtitulo") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleSubtitle; }
                else if (x == "quote" || x == "cita") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleQuote; }
                else if (x == "heading 1" || x == "título 1" || x == "titulo 1") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleHeading1; }
                else if (x == "heading 2" || x == "título 2" || x == "titulo 2") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleHeading2; }
                else if (x == "heading 3" || x == "título 3" || x == "titulo 3") { dynamic dr = r; dr.Style = Word.WdBuiltinStyle.wdStyleHeading3; }
                else { dynamic dr = r; dr.Style = styleName; }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Word no pudo aplicar el estilo '" + styleName + "'. Usa un estilo existente en el documento. " + ex.Message);
            }
        }

        private void AddHeading(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a);
            string text = (a.text ?? "").TrimEnd() + Environment.NewLine;
            r.InsertAfter(text);
            int start = Math.Max(0, r.End - text.Length);
            Word.Range inserted = doc.Range(start, r.End);
            int level = Math.Max(1, Math.Min(9, a.headingLevel ?? 1));
            try
            {
                Word.WdBuiltinStyle style;
                switch (level)
                {
                    case 1: style = Word.WdBuiltinStyle.wdStyleHeading1; break;
                    case 2: style = Word.WdBuiltinStyle.wdStyleHeading2; break;
                    case 3: style = Word.WdBuiltinStyle.wdStyleHeading3; break;
                    case 4: style = Word.WdBuiltinStyle.wdStyleHeading4; break;
                    case 5: style = Word.WdBuiltinStyle.wdStyleHeading5; break;
                    case 6: style = Word.WdBuiltinStyle.wdStyleHeading6; break;
                    case 7: style = Word.WdBuiltinStyle.wdStyleHeading7; break;
                    case 8: style = Word.WdBuiltinStyle.wdStyleHeading8; break;
                    default: style = Word.WdBuiltinStyle.wdStyleHeading9; break;
                }
                dynamic d = inserted;
                d.Style = style;
            }
            catch { inserted.Font.Bold = 1; inserted.Font.Size = level == 1 ? 18 : (level == 2 ? 15 : 12); }
            ApplyFormat(inserted, a);
            AdvanceCursor(doc, inserted.End);
        }

        private void AddList(Word.Document doc, OfficeAction a)
        {
            if (a.items == null || a.items.Count == 0) return;
            if (a.items.Count > 200) throw new InvalidOperationException("La lista supera el límite de 200 elementos.");
            Word.Range r = GetInsertionRange(doc, a);
            int start = r.Start;
            r.InsertAfter(string.Join(Environment.NewLine, a.items) + Environment.NewLine);
            Word.Range inserted = doc.Range(start, r.End);
            if (string.Equals(a.listType, "numbered", StringComparison.OrdinalIgnoreCase) || string.Equals(a.listType, "numerada", StringComparison.OrdinalIgnoreCase)) inserted.ListFormat.ApplyNumberDefault();
            else inserted.ListFormat.ApplyBulletDefault();
            if (HasFormatting(a)) ApplyFormat(inserted, a);
            AdvanceCursor(doc, inserted.End);
        }

        private void AddTable(Word.Document doc, OfficeAction a)
        {
            if (a.rows == null || a.rows.Count == 0) return;
            int rows = a.rows.Count; int cols = 0;
            foreach (var row in a.rows) if (row != null) cols = Math.Max(cols, row.Count);
            if (rows > 100 || cols > 30 || cols == 0) throw new InvalidOperationException("Tabla demasiado grande o inválida.");
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            int beforeCount = doc.Tables.Count;
            Word.Table table = doc.Tables.Add(r, rows, cols);
            if (doc.Tables.Count <= beforeCount) throw new InvalidOperationException("Word no confirmó la creación de la tabla.");
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    table.Cell(i + 1, j + 1).Range.Text = a.rows[i] != null && j < a.rows[i].Count ? (a.rows[i][j] ?? "") : "";
            try { table.Borders.Enable = 1; table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitContent); } catch { }
            ApplyTableOptions(table, a);
            AdvanceCursor(doc, table.Range.End);
        }

        private static void FormatStyle(Word.Document doc, OfficeAction a)
        {
            string target = (a.targetStyleName ?? "").Trim();
            if (target.Length == 0) throw new InvalidOperationException("format_style requiere targetStyleName.");
            int applied = 0;
            foreach (Word.Paragraph para in doc.Paragraphs)
            {
                if (!ParagraphMatchesStyle(para, target)) continue;
                ApplyFormat(para.Range, a);
                applied++;
            }
            if (applied == 0) throw new InvalidOperationException("No se encontraron párrafos con el estilo objetivo '" + target + "'.");
        }

        private static bool ParagraphMatchesStyle(Word.Paragraph para, string target)
        {
            string x = (target ?? "").Trim().ToLowerInvariant();
            if (x.Length == 0) return false;
            try
            {
                if (x == "heading1" || x == "heading 1" || x == "título 1" || x == "titulo 1") return para.OutlineLevel == Word.WdOutlineLevel.wdOutlineLevel1;
                if (x == "heading2" || x == "heading 2" || x == "título 2" || x == "titulo 2") return para.OutlineLevel == Word.WdOutlineLevel.wdOutlineLevel2;
                if (x == "heading3" || x == "heading 3" || x == "título 3" || x == "titulo 3") return para.OutlineLevel == Word.WdOutlineLevel.wdOutlineLevel3;
                if (x == "heading4" || x == "heading 4" || x == "título 4" || x == "titulo 4") return para.OutlineLevel == Word.WdOutlineLevel.wdOutlineLevel4;
            }
            catch { }
            string style = "";
            try { style = GetStyleName(para.get_Style()); } catch { }
            string sx = style.Trim().ToLowerInvariant();
            if (x == "title" || x == "título" || x == "titulo") return sx == "title" || sx == "título" || sx == "titulo";
            if (x == "subtitle" || x == "subtítulo" || x == "subtitulo") return sx == "subtitle" || sx == "subtítulo" || sx == "subtitulo";
            return string.Equals(sx, x, StringComparison.OrdinalIgnoreCase);
        }

        private static Word.Table ResolveTable(Word.Document doc, OfficeAction a)
        {
            if (doc.Tables.Count == 0) throw new InvalidOperationException("El documento no contiene tablas.");
            if (a != null && a.tableIndex.HasValue)
            {
                int idx = a.tableIndex.Value;
                if (idx < 1 || idx > doc.Tables.Count) throw new InvalidOperationException("No existe la tabla " + idx + ".");
                return doc.Tables[idx];
            }
            try
            {
                Word.Selection sel = doc.Application.Selection;
                if (sel != null && sel.Tables.Count > 0) return sel.Tables[1];
            }
            catch { }
            return doc.Tables[doc.Tables.Count];
        }

        private static void ApplyTableMargins(Word.Table table, OfficeAction a)
        {
            if (a.cellMarginTopCm.HasValue) { float v = SafeHelpers.CmToPoints(a.cellMarginTopCm.Value); table.TopPadding = v; VerifyPoints(table.TopPadding, v, "margen interno superior de la tabla"); }
            if (a.cellMarginBottomCm.HasValue) { float v = SafeHelpers.CmToPoints(a.cellMarginBottomCm.Value); table.BottomPadding = v; VerifyPoints(table.BottomPadding, v, "margen interno inferior de la tabla"); }
            if (a.cellMarginLeftCm.HasValue) { float v = SafeHelpers.CmToPoints(a.cellMarginLeftCm.Value); table.LeftPadding = v; VerifyPoints(table.LeftPadding, v, "margen interno izquierdo de la tabla"); }
            if (a.cellMarginRightCm.HasValue) { float v = SafeHelpers.CmToPoints(a.cellMarginRightCm.Value); table.RightPadding = v; VerifyPoints(table.RightPadding, v, "margen interno derecho de la tabla"); }
        }

        private static void SetTableCellMargins(Word.Document doc, OfficeAction a)
        {
            Word.Table table = ResolveTable(doc, a);
            ApplyTableMargins(table, a);
        }

        private static void StyleTable(Word.Document doc, OfficeAction a)
        {
            Word.Table table = ResolveTable(doc, a);
            ApplyTableOptions(table, a);
        }

        // Word.Table.Style expone un setter COM con parámetro ref object.
        // En PIAs/Embed Interop Types antiguos, la asignación directa de Style produce CS1545.
        // Esta función usa el accessor COM explícito para compilar en Office 2010+ y Office moderno.
        private static void SetTableStyle(Word.Table table, object styleValue)
        {
            if (table == null || styleValue == null) return;
            object value = styleValue;
            table.set_Style(ref value);
        }

        private static void ApplyTableOptions(Word.Table table, OfficeAction a)
        {
            if (table == null || a == null) return;
            if (!string.IsNullOrWhiteSpace(a.tableStyle))
            {
                string style = a.tableStyle.Trim().ToLowerInvariant();
                try
                {
                    if (style == "professional" || style == "profesional" || style == "light_grid_accent1" || style == "light grid accent 1") SetTableStyle(table, Word.WdBuiltinStyle.wdStyleTableLightGridAccent1);
                    else if (style == "light_grid" || style == "light grid" || style == "cuadrícula clara" || style == "cuadricula clara") SetTableStyle(table, Word.WdBuiltinStyle.wdStyleTableLightGrid);
                    else if (style == "medium_grid" || style == "medium grid" || style == "cuadrícula media" || style == "cuadricula media") SetTableStyle(table, Word.WdBuiltinStyle.wdStyleTableMediumGrid1);
                    else if (style == "light_shading" || style == "light shading" || style == "sombreado claro") SetTableStyle(table, Word.WdBuiltinStyle.wdStyleTableLightShadingAccent1);
                    else SetTableStyle(table, a.tableStyle);
                }
                catch (Exception ex) { throw new InvalidOperationException("Word no pudo aplicar el estilo de tabla '" + a.tableStyle + "'. " + ex.Message); }
            }
            if (a.headerRow.HasValue) table.ApplyStyleHeadingRows = a.headerRow.Value;
            if (a.bandedRows.HasValue) table.ApplyStyleRowBands = a.bandedRows.Value;
            if (!string.IsNullOrWhiteSpace(a.autoFit))
            {
                string fit = a.autoFit.Trim().ToLowerInvariant();
                if (fit == "fixed" || fit == "fijo") { table.AllowAutoFit = false; table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitFixed); }
                else if (fit == "window" || fit == "ventana") { table.AllowAutoFit = true; table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitWindow); }
                else { table.AllowAutoFit = true; table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitContent); }
            }
            if (a.widthCm.HasValue)
            {
                table.PreferredWidthType = Word.WdPreferredWidthType.wdPreferredWidthPoints;
                table.PreferredWidth = SafeHelpers.CmToPoints(a.widthCm.Value);
            }
            ApplyTableMargins(table, a);
            if (HasFormatting(a)) ApplyFormat(table.Range, a);
            try
            {
                if (a.headerRow == true && table.Rows.Count > 0)
                {
                    table.Rows[1].Range.Font.Bold = 1;
                    table.Rows[1].HeadingFormat = -1;
                }
            }
            catch { }
        }

        private void AddImagePlaceholder(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            int before = doc.Tables.Count;
            Word.Table table = doc.Tables.Add(r, 1, 1);
            if (doc.Tables.Count <= before) throw new InvalidOperationException("Word no confirmó el espacio para imagen.");
            string label = string.IsNullOrWhiteSpace(a.placeholderText) ? (string.IsNullOrWhiteSpace(a.text) ? "ESPACIO PARA IMAGEN" : a.text.Trim()) : a.placeholderText.Trim();
            Word.Cell cell = table.Cell(1, 1);
            cell.Range.Text = "[ " + label + " ]";
            cell.Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            cell.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
            cell.Range.Font.Italic = 1;
            cell.Range.Font.Color = Word.WdColor.wdColorGray50;
            table.Borders.Enable = 1;
            try { table.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleNone; table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleDashSmallGap; } catch { }
            table.AllowAutoFit = false;
            table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitFixed);
            table.PreferredWidthType = Word.WdPreferredWidthType.wdPreferredWidthPoints;
            table.PreferredWidth = SafeHelpers.CmToPoints(a.widthCm ?? 12.0);
            table.Rows[1].HeightRule = Word.WdRowHeightRule.wdRowHeightExactly;
            table.Rows[1].Height = SafeHelpers.CmToPoints(a.heightCm ?? 5.5);
            try { table.LeftPadding = table.RightPadding = SafeHelpers.CmToPoints(0.25); table.TopPadding = table.BottomPadding = SafeHelpers.CmToPoints(0.2); } catch { }
            try { table.Range.InsertParagraphAfter(); } catch { }
            AdvanceCursor(doc, Math.Min(Math.Max(0, doc.Content.End - 1), table.Range.End));
        }

        private static void SetMargins(Word.Document doc, OfficeAction a)
        {
            foreach (Word.Section s in doc.Sections)
            {
                if (a.marginTopCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginTopCm.Value); s.PageSetup.TopMargin = v; VerifyPoints(s.PageSetup.TopMargin, v, "margen superior"); }
                if (a.marginBottomCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginBottomCm.Value); s.PageSetup.BottomMargin = v; VerifyPoints(s.PageSetup.BottomMargin, v, "margen inferior"); }
                if (a.marginLeftCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginLeftCm.Value); s.PageSetup.LeftMargin = v; VerifyPoints(s.PageSetup.LeftMargin, v, "margen izquierdo"); }
                if (a.marginRightCm.HasValue) { float v = SafeHelpers.CmToPoints(a.marginRightCm.Value); s.PageSetup.RightMargin = v; VerifyPoints(s.PageSetup.RightMargin, v, "margen derecho"); }
            }
        }

        private static void VerifyPoints(float actual, float expected, string name)
        {
            if (Math.Abs(actual - expected) > 1.5f) throw new InvalidOperationException("Word no confirmó el " + name + ".");
        }

        private static void SetOrientation(Word.Document doc, string value)
        {
            bool landscape = string.Equals(value, "landscape", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "horizontal", StringComparison.OrdinalIgnoreCase);
            Word.WdOrientation expected = landscape ? Word.WdOrientation.wdOrientLandscape : Word.WdOrientation.wdOrientPortrait;
            foreach (Word.Section s in doc.Sections)
            {
                s.PageSetup.Orientation = expected;
                if (s.PageSetup.Orientation != expected) throw new InvalidOperationException("Word no confirmó la orientación de página.");
            }
        }

        private static void SetPaperSize(Word.Document doc, string value)
        {
            Word.WdPaperSize size = Word.WdPaperSize.wdPaperA4;
            string x = (value ?? "a4").ToLowerInvariant();
            if (x.Contains("letter") || x.Contains("carta")) size = Word.WdPaperSize.wdPaperLetter;
            else if (x.Contains("legal")) size = Word.WdPaperSize.wdPaperLegal;
            foreach (Word.Section s in doc.Sections)
            {
                s.PageSetup.PaperSize = size;
                if (s.PageSetup.PaperSize != size) throw new InvalidOperationException("Word no confirmó el tamaño de papel.");
            }
        }

        private static void AddPageNumbers(Word.Document doc, string position)
        {
            foreach (Word.Section s in doc.Sections)
            {
                Word.HeaderFooter footer = s.Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary];
                Word.WdPageNumberAlignment align = Word.WdPageNumberAlignment.wdAlignPageNumberCenter;
                string p = (position ?? "center").ToLowerInvariant();
                if (p.Contains("right") || p.Contains("derecha")) align = Word.WdPageNumberAlignment.wdAlignPageNumberRight;
                else if (p.Contains("left") || p.Contains("izquierda")) align = Word.WdPageNumberAlignment.wdAlignPageNumberLeft;
                if (footer.PageNumbers.Count == 0) footer.PageNumbers.Add(align, true);
                if (footer.PageNumbers.Count == 0) throw new InvalidOperationException("Word no confirmó la numeración de páginas.");
                try { footer.PageNumbers[1].Alignment = align; }
                catch { }
            }
        }


        private void InsertPicture(Word.Document doc, OfficeAction a)
        {
            PlanSafety.ValidatePicturePath(a.filePath);
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            int beforePictures = doc.InlineShapes.Count + doc.Shapes.Count;
            Word.InlineShape picture = doc.InlineShapes.AddPicture(a.filePath, false, true, r);
            if (doc.InlineShapes.Count + doc.Shapes.Count <= beforePictures) throw new InvalidOperationException("Word no confirmó la inserción de la imagen.");
            if (!string.IsNullOrWhiteSpace(a.altText))
            {
                try { picture.AlternativeText = a.altText; }
                catch (Exception ex) { throw new InvalidOperationException("Word insertó la imagen pero no pudo establecer el texto alternativo: " + ex.Message); }
            }
            if (a.widthCm.HasValue && a.widthCm.Value > 0 && a.widthCm.Value <= 50)
            {
                try { picture.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoTrue; } catch { }
                picture.Width = SafeHelpers.CmToPoints(a.widthCm.Value);
            }
            if (a.heightCm.HasValue && a.heightCm.Value > 0 && a.heightCm.Value <= 50 && !a.widthCm.HasValue)
            {
                try { picture.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoTrue; } catch { }
                picture.Height = SafeHelpers.CmToPoints(a.heightCm.Value);
            }
            string wrap = (a.target ?? "").ToLowerInvariant();
            if (!string.IsNullOrWhiteSpace(wrap) && !wrap.Contains("inline"))
            {
                try
                {
                    Word.Shape shape = picture.ConvertToShape();
                    if (wrap.Contains("square") || wrap.Contains("cuadr")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;
                    else if (wrap.Contains("tight") || wrap.Contains("estrech")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapTight;
                    else if (wrap.Contains("behind") || wrap.Contains("detrás") || wrap.Contains("detras")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapBehind;
                    else if (wrap.Contains("front") || wrap.Contains("delante")) shape.WrapFormat.Type = Word.WdWrapType.wdWrapFront;
                    else throw new InvalidOperationException("Tipo de ajuste de imagen no reconocido: " + a.target);
                }
                catch (Exception ex) { throw new InvalidOperationException("Word insertó la imagen pero no pudo aplicar el ajuste solicitado: " + ex.Message); }
            }
            try { AdvanceCursor(doc, picture.Range.End); } catch { AdvanceCursor(doc, r.End); }
        }

        private static void SetColumns(Word.Document doc, int count)
        {
            count = Math.Max(1, Math.Min(4, count));
            foreach (Word.Section section in doc.Sections)
            {
                section.PageSetup.TextColumns.SetCount(count);
                if (section.PageSetup.TextColumns.Count != count) throw new InvalidOperationException("Word no confirmó el número de columnas.");
            }
        }

        private void AddTableOfContents(Word.Document doc, OfficeAction a)
        {
            int min = Math.Max(1, Math.Min(9, a.minLevel ?? 1));
            int max = Math.Max(min, Math.Min(9, a.maxLevel ?? 3));
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            try
            {
                int before = doc.TablesOfContents.Count;
                Word.TableOfContents toc = doc.TablesOfContents.Add(r, true, min, max);
                if (doc.TablesOfContents.Count <= before) throw new InvalidOperationException("Word no confirmó la tabla de contenido.");
                AdvanceCursor(doc, toc.Range.End);
            }
            catch (Exception ex) { throw new InvalidOperationException("No se pudo crear la tabla de contenido. Asegúrate de usar estilos Título 1/2/3. " + ex.Message); }
        }

        private void AddHyperlink(Word.Document doc, OfficeAction a)
        {
            PlanSafety.ValidateHttpUrl(a.url);
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            string label = string.IsNullOrWhiteSpace(a.text) ? a.url : a.text;
            int before = doc.Hyperlinks.Count;
            Word.Hyperlink link = doc.Hyperlinks.Add(r, a.url, Type.Missing, string.IsNullOrWhiteSpace(a.altText) ? Type.Missing : (object)a.altText, label, Type.Missing);
            if (doc.Hyperlinks.Count <= before) throw new InvalidOperationException("Word no confirmó la inserción del hipervínculo.");
            try { AdvanceCursor(doc, link.Range.End); } catch { AdvanceCursor(doc, r.End); }
        }

        private Word.Range FindRangeOrSelection(Word.Document doc, string findText)
        {
            if (!string.IsNullOrWhiteSpace(findText))
            {
                Word.Range r = doc.Content.Duplicate;
                dynamic find = r.Find;
                bool found = find.Execute(FindText: findText, MatchCase: false, Forward: true, Wrap: Word.WdFindWrap.wdFindStop);
                if (!found) throw new InvalidOperationException("No se encontró el texto de referencia: " + findText);
                return r;
            }
            Word.Selection sel = _app.Selection;
            if (sel == null) throw new InvalidOperationException("No hay una selección disponible en Word.");
            return sel.Range.Duplicate;
        }

        private void AddSources(Word.Document doc, OfficeAction a)
        {
            if (a.rows == null || a.rows.Count == 0) throw new InvalidOperationException("No hay fuentes para insertar.");
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            int start = r.Start;
            string heading = string.IsNullOrWhiteSpace(a.title) ? "Fuentes" : a.title.Trim();
            r.Text = heading + "\r";
            Word.Range hr = doc.Range(start, start + heading.Length);
            try { dynamic dhr = hr; dhr.Style = Word.WdBuiltinStyle.wdStyleHeading2; } catch { hr.Font.Bold = 1; hr.Font.Size = 14; }
            int cursor = start + heading.Length + 1;
            foreach (var row in a.rows)
            {
                if (row == null || row.Count < 2) continue;
                string title = string.IsNullOrWhiteSpace(row[0]) ? row[1] : row[0].Trim();
                string url = row[1].Trim();
                PlanSafety.ValidateHttpUrl(url);
                Word.Range line = doc.Range(cursor, cursor);
                int before = doc.Hyperlinks.Count;
                Word.Hyperlink link = doc.Hyperlinks.Add(line, url, Type.Missing, Type.Missing, "• " + title, Type.Missing);
                if (doc.Hyperlinks.Count <= before) throw new InvalidOperationException("Word no confirmó una fuente insertada.");
                cursor = link.Range.End;
                Word.Range eol = doc.Range(cursor, cursor);
                eol.InsertAfter("\r");
                cursor++;
            }
            AdvanceCursor(doc, Math.Min(cursor, Math.Max(0, doc.Content.End - 1)));
        }

        private void AddFootnote(Word.Document doc, OfficeAction a)
        {
            Word.Range anchor = FindRangeOrSelection(doc, a.findText);
            anchor.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
            int before = doc.Footnotes.Count;
            object footnoteReference = Type.Missing;
            object footnoteText = a.noteText ?? a.text ?? "";
            doc.Footnotes.Add(anchor, ref footnoteReference, ref footnoteText);
            if (doc.Footnotes.Count <= before) throw new InvalidOperationException("Word no confirmó la nota al pie.");
        }

        private void AddBookmark(Word.Document doc, OfficeAction a)
        {
            string raw = (a.bookmarkName ?? a.name ?? "").Trim();
            string name = SanitizeBookmarkName(raw);
            if (name.Length == 0) throw new InvalidOperationException("El nombre del marcador no es válido.");
            Word.Range target = FindRangeOrSelection(doc, a.findText);
            if (doc.Bookmarks.Exists(name)) doc.Bookmarks[name].Delete();
            object bookmarkRange = target;
            doc.Bookmarks.Add(name, ref bookmarkRange);
            if (!doc.Bookmarks.Exists(name)) throw new InvalidOperationException("Word no confirmó el marcador.");
        }

        private static string SanitizeBookmarkName(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return "";
            var sb = new StringBuilder();
            foreach (char c in raw) if (char.IsLetterOrDigit(c) || c == '_') sb.Append(c);
            if (sb.Length == 0) return "";
            if (char.IsDigit(sb[0])) sb.Insert(0, 'B');
            return sb.Length > 40 ? sb.ToString(0, 40) : sb.ToString();
        }

        private void AddTextBox(Word.Document doc, OfficeAction a)
        {
            Word.Range anchor = GetInsertionRange(doc, a);
            float left = SafeHelpers.CmToPoints(a.leftCm ?? 1.0);
            float top = SafeHelpers.CmToPoints(a.topCm ?? 1.0);
            float width = SafeHelpers.CmToPoints(a.widthCm ?? 8.0);
            float height = SafeHelpers.CmToPoints(a.heightCm ?? 3.0);
            int before = doc.Shapes.Count;
            object anchorObject = anchor;
            Word.Shape shape = doc.Shapes.AddTextbox(Office.MsoTextOrientation.msoTextOrientationHorizontal, left, top, width, height, ref anchorObject);
            shape.TextFrame.TextRange.Text = a.text ?? "";
            if (doc.Shapes.Count <= before) throw new InvalidOperationException("Word no confirmó el cuadro de texto.");
            if (HasFormatting(a)) ApplyFormat(shape.TextFrame.TextRange, a);
        }

        private void InsertEquation(Word.Document doc, OfficeAction a)
        {
            string equation = a.equationText ?? a.text ?? "";
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            int start = r.Start;
            r.Text = equation;
            Word.Range eqRange = doc.Range(start, start + equation.Length);
            int before = doc.OMaths.Count;
            Word.Range built = doc.OMaths.Add(eqRange);
            try { built.OMaths.BuildUp(); } catch { }
            if (doc.OMaths.Count <= before) throw new InvalidOperationException("Word no confirmó la ecuación.");
            AdvanceCursor(doc, built.End);
        }

        private void AddCaption(Word.Document doc, OfficeAction a)
        {
            string text = a.captionText ?? a.text ?? "";
            Word.Range r = GetInsertionRange(doc, a);
            r.Collapse(Word.WdCollapseDirection.wdCollapseStart);
            string label = string.IsNullOrWhiteSpace(a.label) ? "Figura" : a.label.Trim();
            string line = label + ": " + text + "\r";
            int start = r.Start;
            r.Text = line;
            Word.Range inserted = doc.Range(start, start + line.Length - 1);
            try { dynamic di = inserted; di.Style = Word.WdBuiltinStyle.wdStyleCaption; } catch { inserted.Font.Italic = 1; }
            AdvanceCursor(doc, inserted.End + 1);
        }

        private void InsertSectionBreak(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a);
            string kind = (a.breakType ?? "next_page").ToLowerInvariant();
            Word.WdBreakType type = (kind.Contains("continuous") || kind.Contains("continu")) ? Word.WdBreakType.wdSectionBreakContinuous : Word.WdBreakType.wdSectionBreakNextPage;
            int before = doc.Sections.Count;
            r.InsertBreak(type);
            if (doc.Sections.Count <= before) throw new InvalidOperationException("Word no confirmó el salto de sección.");
            AdvanceCursor(doc, r.End);
        }
        private static void SetHeader(Word.Document doc, string text)
        {
            foreach (Word.Section s in doc.Sections)
            {
                Word.Range r = s.Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                r.Text = text ?? "";
                string actual = (r.Text ?? "").TrimEnd('\r', '\a');
                if (!string.Equals(actual, (text ?? "").TrimEnd('\r'), StringComparison.Ordinal))
                    throw new InvalidOperationException("Word no confirmó el encabezado.");
            }
        }

        private static void SetFooter(Word.Document doc, string text)
        {
            foreach (Word.Section s in doc.Sections)
            {
                Word.Range r = s.Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                r.Text = text ?? "";
                string actual = (r.Text ?? "").TrimEnd('\r', '\a');
                if (!string.Equals(actual, (text ?? "").TrimEnd('\r'), StringComparison.Ordinal))
                    throw new InvalidOperationException("Word no confirmó el pie de página.");
            }
        }

        private void InsertPageBreak(Word.Document doc, OfficeAction a)
        {
            Word.Range r = GetInsertionRange(doc, a);
            int beforePages = 0;
            try { beforePages = doc.ComputeStatistics(Word.WdStatistic.wdStatisticPages); } catch { }
            r.InsertBreak(Word.WdBreakType.wdPageBreak);
            AdvanceCursor(doc, r.End);
            if (beforePages > 0)
            {
                try
                {
                    int afterPages = doc.ComputeStatistics(Word.WdStatistic.wdStatisticPages);
                    if (afterPages < beforePages) throw new InvalidOperationException("Word no confirmó el salto de página.");
                }
                catch (InvalidOperationException) { throw; }
                catch { }
            }
        }

        private static void AddComment(Word.Document doc, string text)
        {
            Word.Selection sel = doc.Application.Selection;
            if (sel == null) throw new InvalidOperationException("No hay una selección disponible para agregar el comentario.");
            int before = doc.Comments.Count;
            doc.Comments.Add(sel.Range, text ?? "Comentario de Gemini");
            if (doc.Comments.Count <= before) throw new InvalidOperationException("Word no confirmó la creación del comentario.");
        }

        private static double Clamp(double v, double min, double max) { return Math.Max(min, Math.Min(max, v)); }

        public void UndoLast()
        {
            try
            {
                Word.Document doc = _app.ActiveDocument;
                if (doc == null) throw new InvalidOperationException("No hay documento abierto.");
                dynamic ddoc = doc;
                if (!(bool)ddoc.Undo(1)) throw new InvalidOperationException("Word no encontró un cambio para deshacer.");
            }
            catch (Exception ex) { throw new InvalidOperationException("Word no pudo deshacer automáticamente el último cambio de IA. " + ex.Message); }
        }

        public void WipeTemporaryData() { SafeHelpers.DeleteIfExists(_lastTempFile); _lastTempFile = null; }
    }
}
