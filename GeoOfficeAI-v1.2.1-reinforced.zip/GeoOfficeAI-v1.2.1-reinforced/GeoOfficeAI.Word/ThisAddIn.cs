using GeoOfficeAI.Shared;
using Microsoft.Office.Tools;
using System;
using System.Net;
using System.Windows.Forms;
using Office = Microsoft.Office.Core;
using Word = Microsoft.Office.Interop.Word;

namespace GeoOfficeAI.WordAddIn
{
    public partial class ThisAddIn
    {
        private AssistantPane _paneControl;
        private CustomTaskPane _pane;
        private bool _officeClosing;
        private Timer _assistantCloseDecisionTimer;

        private void ThisAddIn_Startup(object sender, EventArgs e)
        {
            try
            {
                if (!LicenseGuard.IsInstallAuthorized()) return;
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                _paneControl = new AssistantPane(new WordAutomationService(this.Application));
                _pane = this.CustomTaskPanes.Add(_paneControl, "Asistente IA · Gemini");
                _pane.DockPosition = Office.MsoCTPDockPosition.msoCTPDockPositionRight;
                _pane.Width = 350;
                _pane.VisibleChanged += Pane_VisibleChanged;
                _pane.Visible = true;

                _assistantCloseDecisionTimer = new Timer { Interval = 1200 };
                _assistantCloseDecisionTimer.Tick += (s, args) =>
                {
                    _assistantCloseDecisionTimer.Stop();
                    if (_pane == null || _pane.Visible || _paneControl == null) return;
                    // Esperar evita confundir la X del panel con el ocultamiento del panel durante el cierre de Office.
                    if (_officeClosing) _paneControl.PersistCurrentConversation();
                    else _paneControl.WipeSensitiveSession();
                };
                this.Application.DocumentBeforeClose += Application_DocumentBeforeClose;
                this.Application.DocumentBeforeSave += Application_DocumentBeforeSave;
                this.Application.DocumentOpen += Application_DocumentOpen;
                this.Application.NewDocument += Application_NewDocument;
                this.Application.WindowActivate += Application_WindowActivate;
                _ = _paneControl.InitializeStatusAsync();
            }
            catch (Exception ex)
            {
                DiagnosticLogger.Error("Word Add-in", "Startup", ex);
                MessageBox.Show(ex.Message, "Geo Office AI · Word");
            }
        }

        private void Application_DocumentBeforeClose(Word.Document doc, ref bool cancel)
        {
            _officeClosing = true;
            try { _paneControl?.PersistCurrentConversation(); } catch { }
        }

        private void Application_DocumentBeforeSave(Word.Document doc, ref bool saveAsUi, ref bool cancel)
        {
            try { _paneControl?.NotifyDocumentMayHaveBeenSaved(); } catch { }
        }

        private void Application_DocumentOpen(Word.Document doc) { try { _officeClosing = false; _assistantCloseDecisionTimer?.Stop(); _paneControl?.ResumeAfterShow(); } catch { } }
        private void Application_NewDocument(Word.Document doc) { try { _officeClosing = false; _assistantCloseDecisionTimer?.Stop(); _paneControl?.ResumeAfterShow(); } catch { } }
        private void Application_WindowActivate(Word.Document doc, Word.Window wn) { try { _officeClosing = false; _assistantCloseDecisionTimer?.Stop(); _paneControl?.ResumeAfterShow(); } catch { } }

        private void Pane_VisibleChanged(object sender, EventArgs e)
        {
            if (_pane == null || _paneControl == null) return;
            try { _assistantCloseDecisionTimer?.Stop(); } catch { }
            if (_pane.Visible) return;
            // No borrar inmediatamente: Office también oculta task panes durante su cierre.
            // La decisión se toma 1.2 s después; Shutdown/BeforeClose marcan _officeClosing.
            try { _assistantCloseDecisionTimer?.Start(); } catch { }
        }

        private void ThisAddIn_Shutdown(object sender, EventArgs e)
        {
            _officeClosing = true;
            try { _assistantCloseDecisionTimer?.Stop(); } catch { }
            if (_paneControl != null) { _paneControl.SuspendForOfficeShutdown(); _paneControl.Dispose(); }
            try { _assistantCloseDecisionTimer?.Stop(); _assistantCloseDecisionTimer?.Dispose(); } catch { }
        }

        internal void ShowAssistantPane()
        {
            if (_pane == null || _paneControl == null) return;
            _officeClosing = false;
            try { _assistantCloseDecisionTimer?.Stop(); } catch { }
            _pane.Visible = true;
            _paneControl.ResumeAfterShow();
        }

        protected override Office.IRibbonExtensibility CreateRibbonExtensibilityObject() { return new OfficeRibbon(); }

        private void InternalStartup()
        {
            this.Startup += new EventHandler(ThisAddIn_Startup);
            this.Shutdown += new EventHandler(ThisAddIn_Shutdown);
        }
    }
}
