using System;
using System.Collections.Generic;

namespace GeoOfficeAI.Shared
{
    [Serializable]
    public sealed class OfficePlan
    {
        public string message { get; set; }
        public List<OfficeAction> actions { get; set; }
        public List<WebSource> sources { get; set; }

        public OfficePlan()
        {
            actions = new List<OfficeAction>();
            sources = new List<WebSource>();
        }
    }

    [Serializable]
    public sealed class WebSource
    {
        public string title { get; set; }
        public string url { get; set; }
    }

    [Serializable]
    public sealed class OfficeAction
    {
        public string action { get; set; }

        // Selección / búsqueda / texto
        public string text { get; set; }
        public string findText { get; set; }
        public string replacementText { get; set; }
        public bool? replaceAll { get; set; }
        public bool? matchCase { get; set; }
        public string position { get; set; }
        // Word: anclaje opcional para insertar antes/después de un texto existente.
        public string anchorText { get; set; }
        public string anchorPlacement { get; set; }
        public string target { get; set; }

        // Formato común
        public string fontName { get; set; }
        public double? fontSize { get; set; }
        public bool? bold { get; set; }
        public bool? italic { get; set; }
        public bool? underline { get; set; }
        public string fontColorHex { get; set; }
        public string fillColorHex { get; set; }
        public string alignment { get; set; }
        public string styleName { get; set; }
        public string targetStyleName { get; set; }
        public string numberFormat { get; set; }
        public double? spaceBeforePt { get; set; }
        public double? spaceAfterPt { get; set; }
        public string lineSpacing { get; set; }

        // Word
        public int? headingLevel { get; set; }
        public List<string> items { get; set; }
        public string listType { get; set; }
        public List<List<string>> rows { get; set; }
        public double? marginTopCm { get; set; }
        public double? marginBottomCm { get; set; }
        public double? marginLeftCm { get; set; }
        public double? marginRightCm { get; set; }
        public string pageNumberPosition { get; set; }
        public string headerText { get; set; }
        public string footerText { get; set; }
        public string orientation { get; set; }
        public string paperSize { get; set; }
        public string commentText { get; set; }
        public bool? enabled { get; set; }
        public int? columnsCount { get; set; }
        public int? minLevel { get; set; }
        public int? maxLevel { get; set; }
        public string breakType { get; set; }
        public string url { get; set; }
        public string altText { get; set; }

        // Excel
        public string address { get; set; }
        public string sheet { get; set; }
        public string formula { get; set; }
        public string name { get; set; }
        public string sourceRange { get; set; }
        public string chartType { get; set; }
        public string sortBy { get; set; }
        public bool? ascending { get; set; }
        public string tableName { get; set; }
        public string columnName { get; set; }
        public string operatorName { get; set; }
        public string value1 { get; set; }
        public string value2 { get; set; }
        public int? fieldIndex { get; set; }
        public string criteria1 { get; set; }
        public string destination { get; set; }
        public string dataField { get; set; }
        public string summaryFunction { get; set; }

        // PowerPoint
        public int? slideIndex { get; set; }
        public string title { get; set; }
        public string subtitle { get; set; }
        public double? leftCm { get; set; }
        public double? topCm { get; set; }
        public double? widthCm { get; set; }
        public double? heightCm { get; set; }
        public string shapeType { get; set; }
        public string filePath { get; set; }
        public string effect { get; set; }
        public string speed { get; set; }
        public string notesText { get; set; }
        public string layoutType { get; set; }

        // Word avanzado
        public string noteText { get; set; }
        public string bookmarkName { get; set; }
        public string captionText { get; set; }
        public string label { get; set; }
        public string equationText { get; set; }

        // Word tablas / espacios de imagen / formato por estilo
        public int? tableIndex { get; set; }
        public double? cellMarginTopCm { get; set; }
        public double? cellMarginBottomCm { get; set; }
        public double? cellMarginLeftCm { get; set; }
        public double? cellMarginRightCm { get; set; }
        public string tableStyle { get; set; }
        public bool? headerRow { get; set; }
        public bool? bandedRows { get; set; }
        public string autoFit { get; set; }
        public string placeholderText { get; set; }
    }

    [Serializable]
    public sealed class BrokerRequest
    {
        public string command { get; set; }
        public string host { get; set; }
        public string instruction { get; set; }
        public string context { get; set; }
        public string history { get; set; }
        public string agentSessionId { get; set; }
        public string callId { get; set; }
        public string functionName { get; set; }
        public string toolResult { get; set; }
    }

    [Serializable]
    public sealed class BrokerResponse
    {
        public bool ok { get; set; }
        public bool connected { get; set; }
        public string displayName { get; set; }
        public string error { get; set; }
        public string planJson { get; set; }
        public string agentSessionId { get; set; }
        public string interactionId { get; set; }
        public string callId { get; set; }
        public string functionName { get; set; }
        public string finalMessage { get; set; }
        public bool completed { get; set; }
        public bool usingFallback { get; set; }
    }
}
