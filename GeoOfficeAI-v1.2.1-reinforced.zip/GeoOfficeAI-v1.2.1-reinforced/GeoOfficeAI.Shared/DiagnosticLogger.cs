using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace GeoOfficeAI.Shared
{
    /// <summary>
    /// Registro técnico local y sin contenido de documentos/prompts.
    /// Sirve para diagnosticar errores reales de Office/VSTO sin exponer tokens.
    /// </summary>
    public static class DiagnosticLogger
    {
        private static readonly object Gate = new object();
        private const long MaxLogBytes = 2L * 1024L * 1024L;

        public static string LogDirectory
        {
            get
            {
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GeoOfficeAI", "Logs");
                Directory.CreateDirectory(dir);
                return dir;
            }
        }

        public static string CurrentLogPath
        {
            get { return Path.Combine(LogDirectory, "GeoOfficeAI-" + DateTime.UtcNow.ToString("yyyyMMdd") + ".log"); }
        }

        public static void CleanupOldLogs(int days)
        {
            try
            {
                DateTime cutoff = DateTime.UtcNow.AddDays(-Math.Max(1, days));
                foreach (string file in Directory.GetFiles(LogDirectory, "GeoOfficeAI-*.log*"))
                {
                    try { if (File.GetLastWriteTimeUtc(file) < cutoff) File.Delete(file); } catch { }
                }
            }
            catch { }
        }

        public static void Info(IOfficeHost host, string step, string message)
        {
            Write("INFO", host, step, message, null);
        }

        public static void Error(IOfficeHost host, string step, Exception ex)
        {
            // No persistimos ex.Message porque algunos errores de Office incluyen texto del documento,
            // rutas o valores de acciones. Tipo + HRESULT + stack son suficientes para el diagnóstico.
            Write("ERROR", host, step, ex == null ? "Error desconocido" : ex.GetType().FullName, ex);
        }

        public static void Error(string component, string step, Exception ex)
        {
            WriteRaw("ERROR", component, step, ex == null ? "Error desconocido" : ex.GetType().FullName, ex);
        }

        private static void Write(string level, IOfficeHost host, string step, string message, Exception ex)
        {
            string component = "Office";
            try
            {
                if (host != null)
                {
                    component = Sanitize(host.HostLabel);
                    string doc = Sanitize(host.GetDocumentDisplayName());
                    if (!string.IsNullOrWhiteSpace(doc)) component += " | " + doc;
                }
            }
            catch { }
            WriteRaw(level, component, step, message, ex);
        }

        private static void WriteRaw(string level, string component, string step, string message, Exception ex)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append(DateTime.UtcNow.ToString("o"))
                  .Append(" | ").Append(Sanitize(level))
                  .Append(" | ").Append(Sanitize(component))
                  .Append(" | ").Append(Sanitize(step))
                  .Append(" | ").Append(Sanitize(message));
                if (ex != null)
                {
                    sb.Append(" | HRESULT=0x").Append(ex.HResult.ToString("X8"));
                    if (ex.InnerException != null)
                        sb.Append(" | INNER_TYPE=").Append(Sanitize(ex.InnerException.GetType().FullName));
                    if (!string.IsNullOrWhiteSpace(ex.StackTrace))
                        sb.Append(" | STACK=").Append(Sanitize(ex.StackTrace));
                }
                sb.AppendLine();

                lock (Gate)
                {
                    string path = CurrentLogPath;
                    RotateIfNeeded(path);
                    File.AppendAllText(path, sb.ToString(), Encoding.UTF8);
                }
            }
            catch { }
        }

        private static void RotateIfNeeded(string path)
        {
            try
            {
                if (!File.Exists(path) || new FileInfo(path).Length < MaxLogBytes) return;
                string rotated = path + ".1";
                if (File.Exists(rotated)) File.Delete(rotated);
                File.Move(path, rotated);
            }
            catch { }
        }

        private static string Sanitize(string value)
        {
            string s = value ?? "";
            if (s.Length > 5000) s = s.Substring(0, 5000);
            // Evita dejar tokens OAuth/API en el registro si una excepción externa los incluyera.
            s = Regex.Replace(s, @"(?i)Bearer\s+[A-Za-z0-9._~+\-/=]+", "Bearer [REDACTED]");
            s = Regex.Replace(s, @"(?i)(access_token|refresh_token|id_token|api[_-]?key)\s*[:=]\s*[^\s,;]+", "$1=[REDACTED]");
            s = s.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
            return s.Trim();
        }
    }
}
