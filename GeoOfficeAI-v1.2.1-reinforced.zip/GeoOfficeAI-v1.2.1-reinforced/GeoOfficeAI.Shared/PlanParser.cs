using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Shared
{
    public static class PlanParser
    {
        public static OfficePlan Parse(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw))
                throw new InvalidOperationException("Gemini devolvió una respuesta vacía.");

            string json = ExtractJson(raw.Trim());
            var serializer = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            OfficePlan plan;
            try
            {
                plan = serializer.Deserialize<OfficePlan>(json);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Gemini no devolvió un plan válido. " + ex.Message);
            }

            if (plan == null) plan = new OfficePlan();
            if (plan.actions == null) plan.actions = new List<OfficeAction>();
            if (plan.sources == null) plan.sources = new List<WebSource>();
            if (plan.actions.Count > 160)
                throw new InvalidOperationException("Gemini propuso demasiadas acciones de una sola vez. Divide la tarea en partes.");
            return plan;
        }

        private static string ExtractJson(string raw)
        {
            if (raw.StartsWith("```"))
            {
                int firstNl = raw.IndexOf('\n');
                int lastFence = raw.LastIndexOf("```");
                if (firstNl >= 0 && lastFence > firstNl)
                    raw = raw.Substring(firstNl + 1, lastFence - firstNl - 1).Trim();
            }

            int start = raw.IndexOf('{');
            int end = raw.LastIndexOf('}');
            if (start >= 0 && end > start)
                return raw.Substring(start, end - start + 1);
            return raw;
        }
    }
}
