using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;

namespace GeoOfficeAI.Shared
{
    [Serializable]
    public sealed class ChatEntry
    {
        public string role { get; set; }
        public string text { get; set; }
        public DateTime utc { get; set; }
    }

    public static class ConversationStore
    {
        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("GeoOfficeAI.ConversationStore.v1");

        private static string Root
        {
            get
            {
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GeoOfficeAI", "Conversations");
                Directory.CreateDirectory(dir);
                return dir;
            }
        }

        public static List<ChatEntry> Load(string persistentDocumentKey)
        {
            if (string.IsNullOrWhiteSpace(persistentDocumentKey)) return new List<ChatEntry>();
            try
            {
                string path = FilePath(persistentDocumentKey);
                if (!File.Exists(path)) return new List<ChatEntry>();
                byte[] protectedBytes = File.ReadAllBytes(path);
                byte[] clear = ProtectedData.Unprotect(protectedBytes, Entropy, DataProtectionScope.CurrentUser);
                var list = Json.Deserialize<List<ChatEntry>>(Encoding.UTF8.GetString(clear));
                return list ?? new List<ChatEntry>();
            }
            catch
            {
                return new List<ChatEntry>();
            }
        }

        public static void Save(string persistentDocumentKey, IList<ChatEntry> entries)
        {
            if (string.IsNullOrWhiteSpace(persistentDocumentKey)) return;
            try
            {
                var safe = new List<ChatEntry>();
                if (entries != null)
                {
                    int start = Math.Max(0, entries.Count - 120);
                    for (int i = start; i < entries.Count; i++)
                    {
                        ChatEntry e = entries[i];
                        if (e == null || string.IsNullOrWhiteSpace(e.text)) continue;
                        safe.Add(new ChatEntry
                        {
                            role = string.Equals(e.role, "assistant", StringComparison.OrdinalIgnoreCase) ? "assistant" : "user",
                            text = SafeHelpers.Truncate(e.text, 12000),
                            utc = e.utc == default(DateTime) ? DateTime.UtcNow : e.utc
                        });
                    }
                }
                string raw = Json.Serialize(safe);
                byte[] clear = Encoding.UTF8.GetBytes(raw);
                byte[] protectedBytes = ProtectedData.Protect(clear, Entropy, DataProtectionScope.CurrentUser);
                string path = FilePath(persistentDocumentKey);
                string temp = path + ".tmp";
                File.WriteAllBytes(temp, protectedBytes);
                if (File.Exists(path)) File.Delete(path);
                File.Move(temp, path);
            }
            catch { }
        }

        public static void Delete(string persistentDocumentKey)
        {
            if (string.IsNullOrWhiteSpace(persistentDocumentKey)) return;
            try { SafeHelpers.DeleteIfExists(FilePath(persistentDocumentKey)); } catch { }
        }

        public static void DeleteAll()
        {
            try
            {
                string dir = Root;
                foreach (string file in Directory.GetFiles(dir, "*.bin")) SafeHelpers.DeleteIfExists(file);
                foreach (string file in Directory.GetFiles(dir, "*.tmp")) SafeHelpers.DeleteIfExists(file);
            }
            catch { }
        }

        private static string FilePath(string key)
        {
            byte[] bytes;
            using (var sha = SHA256.Create()) bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(key.Trim().ToLowerInvariant()));
            var sb = new StringBuilder(bytes.Length * 2);
            foreach (byte b in bytes) sb.Append(b.ToString("x2"));
            return Path.Combine(Root, sb.ToString() + ".bin");
        }
    }
}
