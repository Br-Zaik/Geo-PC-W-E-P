# Instalación y uso — Geo Office AI v0.9

## Antes de compilar

1. Crear una credencial OAuth 2.0 de tipo Desktop en Google Cloud y habilitar la API necesaria para Gemini.
2. Crear `GeoOfficeAI.Broker/google_oauth.json` siguiendo `docs/OAUTH-GOOGLE.md`. El archivo real no debe subirse al repositorio.
3. En GitHub Actions, cargar su contenido Base64 en el secreto `GOOGLE_OAUTH_JSON_B64`.

## Compilación automatizada

El workflow `.github/workflows/build-windows.yml` usa Windows Server 2022, comprueba/instala el workload Office/VSTO, ejecuta `qa-static.ps1`, compila con `build.ps1`, instala Inno Setup y genera:

`dist/GeoOfficeAI-Setup-v0.9.exe`

## Instalación

1. Ejecutar `GeoOfficeAI-Setup-v0.9.exe` como administrador.
2. Introducir una de las claves autorizadas del proyecto.
3. Cerrar y volver a abrir Word, Excel o PowerPoint si estaban abiertos.
4. Abrir **Asistente IA · Gemini** desde la cinta si el panel no está visible.
5. Iniciar sesión con Google cuando se solicite.

## Uso

Escribe la orden en lenguaje natural. El complemento obtiene un plan estructurado de Gemini, lo valida y después modifica el archivo abierto. El mensaje de éxito solo debe aparecer cuando el host de Office ha terminado la ejecución.

Ejemplo Word:

`Crea un informe profesional de una página sobre seguridad minera, con título centrado, introducción, tres puntos clave, tabla de prevención y conclusión. Usa márgenes de 2 cm arriba/abajo y 2.5 cm izquierda/derecha.`

Si el plan de Gemini llega mal formado, v0.9 intenta repararlo antes de tocar Office. Si una modificación de Word falla a mitad, intenta revertir el registro de Deshacer. Excel y PowerPoint crean primero una copia de recuperación; si esa copia no puede crearse, no comienzan los cambios.

## Importante después de instalar

No considerar la build lista para distribución solo porque GitHub compile. Ejecutar la matriz `docs/PRUEBAS-v1.2.md`, especialmente documento vacío, documento con contenido, cancelación, error intermedio, Internet caído, solo lectura y Word x86/x64 según el soporte que se quiera ofrecer.
