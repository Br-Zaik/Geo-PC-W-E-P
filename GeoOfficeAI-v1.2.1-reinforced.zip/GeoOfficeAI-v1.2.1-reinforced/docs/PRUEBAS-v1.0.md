# Matriz de pruebas reales — Geo Office AI v1.0 Agentic

Estas pruebas deben ejecutarse en Windows con Office real antes de declarar una build lista para uso diario.

## Word P0
1. Documento vacío: pedir un informe de 1 página con título, secciones, tabla, márgenes y numeración. Confirmar que Word queda modificado antes del mensaje “Listo”.
2. Documento con contenido: modificar únicamente un párrafo seleccionado; confirmar que el resto no cambia.
3. Investigación web: pedir información reciente con fuentes. Confirmar contenido + sección Fuentes con enlaces válidos.
4. Error reparable: forzar una acción inválida en un test del broker; confirmar que no toca Word y el agente corrige el siguiente lote.
5. Fallo a mitad: provocar error en una acción posterior; confirmar rollback del UndoRecord.
6. Cancelar durante un lote: confirmar rollback o mensaje explícito de recuperación.
7. Documento protegido y solo lectura: confirmar bloqueo antes de modificar.
8. Imagen sin ruta local: pedir “genera una imagen”; confirmar que responde solo con prompt breve y no finge inserción.
9. Imagen con ruta local válida: confirmar inserción real y verificación.
10. Notas al pie, marcadores, ecuación, cuadro de texto y fuentes: probar cada acción por separado.

## Sesión e historial P0
1. Guardar un Word, conversar, cerrar Word y volver a abrir el mismo archivo: recuperar chat y sesión sin login nuevo.
2. Abrir otro Word: historial separado/limpio.
3. Documento nuevo -> cerrar -> “No guardar”: no debe aparecer historial al crear otro documento.
4. Documento nuevo -> Guardar -> cerrar -> abrir el mismo archivo: debe recuperar historial.
5. Guardar como: el historial de la sesión actual debe seguir al nuevo archivo.
6. Cerrar únicamente la X del asistente: borrar historiales y revocar sesión; al volver a abrir debe pedir login.

## Excel / PowerPoint P0
1. Crear datos/tabla/gráfico en Excel y verificar archivo real.
2. Crear presentación de varias diapositivas y verificar contenido real.
3. Provocar fallo: confirmar que existe copia de recuperación previa.
4. Cerrar Office y reabrir el mismo archivo: recuperar chat/sesión; otro archivo: chat separado.

## Compatibilidad
- Office 2010/2013 x86 si se mantiene como objetivo de soporte.
- Office 2016/2021/365 x64.
- Windows 10 y 11.
- Internet caído, 408, 429 y 5xx de Gemini.
- Documentos grandes y archivos antiguos `.doc/.xls/.ppt` cuando aplique.
