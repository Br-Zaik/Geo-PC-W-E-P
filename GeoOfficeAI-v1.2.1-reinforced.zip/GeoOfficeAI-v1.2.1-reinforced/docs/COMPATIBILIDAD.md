# Compatibilidad prevista — Geo Office AI v0.9

Geo Office AI es un conjunto de complementos VSTO para **Microsoft Office de escritorio en Windows**. No funciona en Office web, Android, iOS ni macOS.

## Objetivo de compatibilidad

- Word, Excel y PowerPoint 2010 o posterior, siempre que el entorno disponga del VSTO Runtime y de los componentes compatibles.
- Office de 32 bits y 64 bits mediante registro del instalador en ambas vistas cuando corresponde.
- Windows compatible con .NET Framework 4.8 y VSTO Runtime.

Los proyectos usan referencias Office/Interop embebidas, pero “compila” no equivale a “compatible en todas las versiones”. Las diferencias de Office, formatos antiguos, políticas corporativas, Protected View, documentos protegidos, complementos de terceros y arquitectura x86/x64 requieren pruebas reales.

## Matriz de release recomendada

| Entorno | Estado requerido |
|---|---|
| Office 2010/2013 x86 | Probar P0 si se mantiene como objetivo de soporte |
| Office 2016/2021 x64 | Probar P0 completo |
| Microsoft 365 x64 | Probar P0 completo |
| Word/Excel/PowerPoint solo lectura | Debe rechazar cambios con mensaje claro |
| Documento protegido/Protected View | Debe no modificar o fallar de forma segura |
| Internet caído / 429 / 503 | Debe reintentar solo lo transitorio y terminar sin modificar si no hay plan válido |
| Office web/móvil/macOS | No soportado por esta arquitectura VSTO |

La compatibilidad aquí es **prevista**, no certificada. La certificación solo puede darse después de ejecutar `docs/PRUEBAS-v1.2.md` en máquinas Windows/Office reales.
