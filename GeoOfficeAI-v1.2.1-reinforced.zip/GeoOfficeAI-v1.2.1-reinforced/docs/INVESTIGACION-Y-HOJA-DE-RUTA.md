# Refuerzo v1.2 — instalación, sesión y diagnóstico

La v1.2 conserva el motor agentic v1.1 y refuerza tres puntos prácticos antes de las pruebas en cabina: una sola clave de instalación, una separación más segura entre cerrar Office y cerrar la X del asistente, y diagnóstico local sin contenido sensible para localizar errores reales de VSTO/Interop.

El motor funcional sigue siendo **Gemini 3.8 Flash + Interactions API v1 + Function Calling validated + ejecución/verificación por lotes + auditoría final independiente**, con Structured Output como fallback.

# Actualización v1.1 — motor Copilot-style

La v1.1 conserva la auditoría v0.9 que aparece más abajo como antecedente, pero cambia el núcleo principal a un flujo agentic: **Gemini 3.8 Flash + Interactions API estable v1 + Function Calling validado + ejecución/verificación por lotes + auditoría final independiente**. El planificador Structured Output anterior queda como fallback.

Mejoras añadidas sobre v1.0/v0.9:

- Orquestación de órdenes compuestas: una petición se considera una lista de requisitos y no puede darse por terminada solo porque una parte salió bien.
- Segundo pase de auditoría: después de modificar Office se vuelve a leer el estado actual y un turno agentic independiente corrige requisitos faltantes antes de mostrar “Listo”.
- Word expone estructura de párrafos, estilos, tamaño, negrita/cursiva, alineación, niveles de esquema, tablas/padding/autofit y señales de revisión ortográfica/gramatical.
- Word incorpora formato global por estilo (`format_style`), estilos profesionales de tabla (`style_table`), márgenes internos de celdas (`set_table_cell_margins`) y espacios reales para imágenes (`add_image_placeholder`).
- Las inserciones pueden anclarse a texto existente mediante `anchorText` + `anchorPlacement` para órdenes como “después del subtítulo X” o “antes de la conclusión”.
- Gemini recibe reglas explícitas para distinguir **márgenes de página** (`set_margins`) de **márgenes internos de tabla** (padding).
- La búsqueda web se habilita también cuando la orden dice “si falta información” o equivalente; si usa información web en Word, el agente debe insertar fuentes reales salvo que el usuario pida lo contrario.
- La generación de imágenes por API permanece desactivada por costo: si se pide generar una imagen sin ruta local, el asistente responde con un prompt corto; si se pide dejar espacio para una imagen, crea un placeholder en Word.
- Sesión e historial por documento permanecen cifrados. Cerrar Office conserva la sesión; cerrar la X del asistente borra historiales y revoca/elimina la concesión local de Geo Office AI.

La API Interactions está en GA y disponible bajo `v1`; el modo `validated` exige adherencia al esquema de Function Calling. En Word, el modelo de objetos expone propiedades reales de tabla como `TopPadding`, `BottomPadding`, `LeftPadding`, `RightPadding`, `ApplyStyleHeadingRows`, `ApplyStyleRowBands` y `AllowAutoFit`, que son las usadas en esta implementación.

**Límite de esta entrega:** el código pasó QA estática en Linux, pero la validación definitiva sigue siendo compilar con MSBuild/VSTO en Windows e instalar/probar con Word real. No es correcto prometer “cero fallos” antes de esa prueba.

---

# Investigación técnica y auditoría — Geo Office AI v0.9

## Objetivo de esta revisión

La v0.9 parte de la v0.8 y prioriza una cosa: que una orden del usuario no se dé por terminada hasta que los cambios se hayan aplicado realmente en Word, Excel o PowerPoint. La investigación se concentró en el fallo observado en Word (`set_margins{...}` bloqueado por seguridad), en el contrato entre Gemini y Office, en recuperación ante fallos y en las reglas de threading/COM de VSTO.

## Hallazgos de la auditoría de v0.8

1. El schema del plan permitía casi cualquier cadena en `action` y no describía de forma fuerte los parámetros de cada acción. Por eso Gemini podía incrustar argumentos dentro del identificador, por ejemplo `set_margins{marginTopCm:2,...}`.
2. `PlanSafety` hacía bien en bloquear esa cadena porque no era el identificador exacto `set_margins`, pero no existía una etapa de reparación antes de abortar.
3. El panel mostraba `plan.message` antes de ejecutar `ApplyPlanAsync`, por lo que podía decir “He creado...” aunque Office todavía no hubiese aplicado nada.
4. Había una inconsistencia de límites: el parser aceptaba menos acciones que el schema/safety.
5. En Word, varias inserciones con `position=cursor` podían reutilizar la selección viva y no mantener un cursor lógico que avanzara de forma fiable entre acciones.
6. Word agrupaba cambios con UndoRecord, pero un error a mitad no intentaba revertir automáticamente el conjunto completo.
7. Había operaciones con errores COM silenciados, lo que podía aparentar éxito sin haber aplicado completamente el cambio solicitado.
8. Faltaban prechecks claros para documento protegido/solo lectura y verificaciones posteriores para varias operaciones importantes.
9. Las llamadas REST a Gemini no tenían una estrategia limitada de reintentos para fallos transitorios.
10. Excel y PowerPoint necesitaban una recuperación previa más conservadora porque su Undo automatizado no ofrece la misma base transaccional práctica que Word.

## Evidencia técnica usada

- Gemini Structured Outputs admite JSON Schema para restringir tipos, propiedades, campos requeridos, enums, límites y propiedades adicionales. La propia documentación de Google indica que un JSON sintácticamente válido no garantiza que el resultado sea semánticamente correcto, por lo que la aplicación debe validarlo antes de usarlo.
  - https://ai.google.dev/gemini-api/docs/structured-output
  - https://ai.google.dev/api/generate-content
- Google recomienda reintentos con backoff exponencial y jitter solo para errores transitorios como 408/429/5xx, con un máximo de intentos.
  - https://ai.google.dev/gemini-api/docs/troubleshooting
- Microsoft documenta que el modelo de objetos de Office no es thread-safe, Office se ejecuta en el STA principal y las llamadas COM desde hilos de fondo pueden bloquearse o ser rechazadas cuando Office está ocupado.
  - https://learn.microsoft.com/en-us/visualstudio/vsto/threading-support-in-office?view=visualstudio
- Word ofrece `UndoRecord.StartCustomRecord` / `EndCustomRecord` para agrupar varias acciones como una sola entrada de Deshacer.
  - https://learn.microsoft.com/en-us/office/vba/word/concepts/working-with-word/working-with-the-undorecord-object
  - https://learn.microsoft.com/en-us/office/vba/api/word.undorecord.startcustomrecord
- Excel `Workbook.SaveCopyAs` y PowerPoint `Presentation.SaveCopyAs` permiten crear una copia sin cambiar el documento abierto.
  - https://learn.microsoft.com/en-us/office/vba/api/excel.workbook.savecopyas
  - https://learn.microsoft.com/en-us/office/vba/api/powerpoint.presentation.savecopyas

## Arquitectura reforzada en v0.9

Flujo esperado:

`orden del usuario -> Gemini -> schema estructurado -> normalización segura -> validación semántica -> reparación automática si es necesaria -> preflight del host -> ejecución Office -> verificación -> confirmación en UI`

### 1. Plan estructurado y cerrado

`GeminiPlanner` genera un schema específico según Word, Excel o PowerPoint. `action` es un enum construido a partir de la lista blanca del host. Los argumentos son propiedades separadas y `additionalProperties=false` evita campos inesperados.

El caso concreto de la captura debe ser:

```json
{
  "action": "set_margins",
  "marginTopCm": 2,
  "marginBottomCm": 2,
  "marginLeftCm": 2.5,
  "marginRightCm": 2.5
}
```

No se acepta como identificador `set_margins{...}` ni `set_margins(...)`.

### 2. Reparación automática antes de tocar Office

La planificación tiene hasta tres intentos. Si el plan no parsea o no pasa seguridad/semántica, Gemini recibe el error exacto y debe reparar solamente el plan. Además, `PlanNormalizer` reconoce de forma conservadora el patrón defectuoso visto en la captura cuando contiene una acción ya autorizada y solo parámetros escalares. No ejecuta código ni convierte una acción desconocida en una permitida.

### 3. Validación semántica

`PlanSafety` verifica no solo el nombre de la acción, sino parámetros obligatorios, rangos, tamaños, márgenes, índices, colores, URLs, fórmulas y límites de trabajo. El objetivo es detectar el fallo antes de modificar el archivo.

### 4. Word: ejecución real y recuperación

Word mantiene un cursor lógico de ejecución durante toda una petición, de modo que títulos, párrafos, tablas, listas, imágenes e hipervínculos se insertan secuencialmente. Antes de comenzar se comprueba el estado del documento y se realiza preflight de acciones que podrían fallar por ausencia de destino.

La modificación se abre dentro de un `UndoRecord` obligatorio. Si una acción falla o el usuario cancela, la aplicación intenta cerrar correctamente el registro y deshacer el conjunto. Las acciones críticas también verifican resultados cuando es razonable, por ejemplo márgenes, orientación, papel, columnas, encabezado/pie, comentarios, enlaces y objetos insertados.

Esto mejora mucho la recuperación, pero no convierte COM/Word en una base de datos transaccional perfecta. Por eso la prueba real en Office sigue siendo obligatoria antes de declarar una versión final.

### 5. Excel y PowerPoint: copia de recuperación obligatoria

Antes de modificar, Excel y PowerPoint crean una copia de recuperación verificada con `SaveCopyAs`; si la copia no puede crearse, la operación no empieza. Se rechazan archivos de solo lectura y se reporta qué acción falló.

Esta copia protege el estado anterior, pero no es un rollback automático del documento activo. Reabrir automáticamente una copia sobre un archivo con cambios no guardados podría destruir trabajo del usuario. En caso de fallo parcial se informa la ruta de recuperación.

### 6. Threading/COM

Los tres hosts bloquean la mutación si la llamada no está ejecutándose en un hilo STA. Las operaciones de red pueden ser asíncronas, pero el acceso al modelo de objetos de Office debe regresar al contexto correcto de la interfaz antes de tocar Word/Excel/PowerPoint.

### 7. Confirmación de éxito

El panel ya no presenta el texto de Gemini como confirmación antes de ejecutar. Primero se llama a `ApplyPlanAsync`; solo si termina sin excepción aparece `Listo: los cambios se aplicaron correctamente...`.

## Reintentos de Gemini

Las llamadas REST reintentan únicamente errores considerados transitorios: 408, 429, 5xx y fallos temporales de red/timeout. Los intentos son limitados y usan espera creciente con jitter. Errores permanentes, autorización inválida o problemas de schema no entran en un bucle infinito.

## Pruebas P0 que deben pasar en Windows antes de release

### Word
- Documento vacío: informe de una página con título, párrafos, tabla y márgenes.
- Documento existente: modificar solo selección/párrafo sin destruir imágenes, tablas ni encabezados no solicitados.
- 20+ acciones secuenciales manteniendo orden de inserción.
- Buscar/reemplazar con objetivo existente e inexistente.
- Márgenes, orientación, tamaño de papel, columnas, encabezados, pies y numeración.
- Tabla de contenido, enlaces/fuentes, comentario, lista e imagen local.
- Documento protegido y documento solo lectura.
- Cancelación a mitad y fallo artificial en una acción intermedia; comprobar rollback de Word.
- Respuesta Gemini inválida, `set_margins{...}`, JSON incompleto, timeout, 429, 503 e Internet caído.
- Verificar que jamás aparezca “aplicado correctamente” si el documento no cambió como se pidió.

### Excel
- Celdas/fórmulas, tabla, formato, validación, filtros, gráfico y tabla dinámica básica.
- Confirmar copia de recuperación antes del primer cambio.
- Libro solo lectura, fallo intermedio y fórmula bloqueada.

### PowerPoint
- Crear varias diapositivas con texto/tabla/forma/notas/transición.
- Confirmar copia de recuperación conservando extensión/formato.
- Presentación solo lectura y fallo intermedio.

### Compatibilidad
- Office 2010/2013 x86 donde sea posible.
- Office 2016/2021/Microsoft 365 x64.
- Documentos modernos y formatos antiguos soportados por cada aplicación.
- Windows limpio con VSTO Runtime y sin herramientas de desarrollo instaladas.

## Estado honesto de v0.9

La fuente de v0.9 está reforzada y pasó controles estáticos de estructura, listas blancas/handlers y regresiones clave dentro del entorno de trabajo. Este entorno Linux no contiene Microsoft Office, VSTO ni MSBuild de Windows, por lo que aquí no se puede afirmar que el complemento haya pasado una compilación real ni una prueba COM dentro de Word/Excel/PowerPoint.

El workflow de GitHub Actions ejecuta QA estática y después compila en `windows-2022`. Esa compilación, seguida de las pruebas manuales P0 anteriores en Office real, es el gate necesario antes de llamar a la versión “sin fallas”. Ningún software real puede prometer cero fallos; el objetivo técnico es prevenirlos, detectarlos antes de modificar, recuperarse cuando sea posible y nunca anunciar éxito falso.

## Después de estabilizar P0

P1 debe centrarse en bibliografía/referencias nativas y tablas avanzadas en Word; limpieza/importación, PivotTables más completas, gráficos y Power Query cuando la versión lo permita en Excel; y layouts, gráficos, temas y animaciones más avanzados en PowerPoint. No conviene ampliar P1 hasta cerrar la matriz P0 en Windows Office.
