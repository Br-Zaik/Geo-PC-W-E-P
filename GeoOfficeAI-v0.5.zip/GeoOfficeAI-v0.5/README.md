# Geo Office AI v0.5 — Gemini para Word, Excel y PowerPoint

Complementos VSTO para **Microsoft Word, Excel y PowerPoint de escritorio en Windows**. El usuario trabaja en sus programas de Office normales; Geo Office AI agrega un panel lateral tipo chat conectado únicamente a **Gemini**.

## Experiencia de uso

1. Se instala una sola vez con una de las 3 claves autorizadas.
2. Abres Word, Excel o PowerPoint.
3. Aparece **Asistente IA · Gemini** a la derecha.
4. Pulsas **Iniciar sesión con Google**. Se abre el navegador y autorizas la aplicación.
5. Escribes en lenguaje normal lo que quieres. Ejemplos:
   - Word: `Resume este texto, corrige la ortografía y pon los títulos centrados.`
   - Excel: `Calcula los promedios de esta tabla y crea un gráfico de columnas.`
   - PowerPoint: `Crea 5 diapositivas claras sobre seguridad minera.`
   - Web: `Busca en Internet los tipos de perforación minera y agrégalos aquí de forma breve.`
   - Imagen: `Dame un prompt profesional para generar una imagen sobre perforación diamantina en Gemini web.`
6. La IA devuelve un plan estructurado y el complemento ejecuta solo acciones permitidas dentro del archivo abierto.

El chat no tiene botones separados para resumir, tabla, etc. Solo **Enviar, Cancelar y Deshacer IA**. Existe un único botón en la cinta de Office, **Abrir Asistente IA**, para volver a mostrar el panel si lo cerraste con la X.

## Solo Gemini

No incluye OpenAI, Claude, Anthropic, Ollama ni selector de proveedor. No guarda API keys porque el acceso está diseñado con **OAuth de Google** para una aplicación de escritorio.

> Importante: iniciar sesión con Google autoriza el uso de **Gemini API** asociado al proyecto OAuth de la aplicación. No convierte una suscripción Google AI Plus en crédito de API.

Modelo configurado: `gemini-2.5-flash`, estable y con nivel gratuito para texto según las condiciones vigentes de Google. La búsqueda web solo se activa cuando la instrucción pide explícitamente buscar/investigar en Internet.

## Imágenes

La generación de imágenes dentro del complemento está desactivada para evitar el costo del modelo de imagen. Si el usuario pide **crear/generar una imagen**, Gemini prepara un prompt listo para pegar en Gemini web. El complemento sí puede **insertar una imagen local existente** en Word, Excel o PowerPoint cuando se indica una ruta válida.

## Capacidades principales

### Word
Texto, resumen, corrección y redacción; formato de selección o documento completo; estilos y títulos; listas; tablas; márgenes; papel/orientación; columnas; secciones; encabezado/pie; números de página; tabla de contenido; hipervínculos para fuentes; comentarios; control de cambios; imágenes locales con ajuste de texto.

### Excel
Celdas y rangos; fórmulas con filtros de seguridad; Tablas de Excel; columnas calculadas que se expanden con nuevas filas; formato y autofit; formato condicional; validación de datos; filtros y ordenamiento; gráficos; tablas dinámicas; nombres definidos; fila de totales; cálculo automático/manual; hojas nuevas/renombradas; combinar celdas; congelar fila superior; buscar/reemplazar; imágenes locales.

### PowerPoint
Crear/duplicar diapositivas; layouts; títulos y cuadros de texto; buscar/reemplazar; tablas; formas; fondos; temas locales; espacios reservados para imágenes; estilo profesional consistente; alineación/distribución; notas del presentador; transiciones discretas; animaciones básicas; imágenes locales.

## Seguridad implementada

- 3 claves fijas de instalación; en el script del instalador solo están sus hashes SHA-256.
- Marcador de instalación autorizado para que los complementos no carguen si no pasaron por el instalador.
- OAuth con `state` aleatorio + PKCE y retorno únicamente por loopback `127.0.0.1`.
- Access token y refresh token **solo en memoria**: no se crea `token.json`.
- Al cerrar la X del panel o cerrar una aplicación de Office: se cancela la petición, se borra chat, se limpian temporales y se revoca/borra la sesión del broker.
- El canal local entre Office y el broker usa named pipe restringido al usuario actual de Windows.
- Lista blanca de acciones; se bloquean macros, VBA, PowerShell, scripts, borrado de hojas/diapositivas/archivos y fórmulas de Excel consideradas peligrosas.
- Límites de tamaño para planes, tablas, rangos e imágenes locales.
- Word agrupa cambios con `UndoRecord`; Excel y PowerPoint crean una copia temporal previa a los cambios durante la sesión.

### Lo que no puede garantizarse sin servidor

Las 3 claves son una protección local sencilla, tal como se pidió. Un atacante con acceso administrativo y conocimientos de ingeniería inversa podría saltarse una validación puramente local. Para una licencia realmente revocable/multi-PC haría falta un servidor, que se dejó fuera de esta versión deliberadamente.

Tampoco se borran las cookies o el inicio de sesión global de **Chrome/Edge**: eso pertenece al navegador y borrarlo afectaría otras cuentas del usuario. Se borra y revoca la **sesión de Geo Office AI**.

## Requisito pendiente obligatorio para el inicio de sesión

Antes de poder producir un instalador funcional final, el desarrollador debe crear **una credencial OAuth 2.0 de tipo Desktop** en Google Cloud, habilitar Generative Language API y crear localmente `GeoOfficeAI.Broker/google_oauth.json` a partir de la plantilla incluida. Ese archivo real está excluido por `.gitignore`. Consulta `docs/OAUTH-GOOGLE.md`.

El repositorio contiene una plantilla, no credenciales reales. No es correcto inventar o compartir un Client ID de otra aplicación.

## Compilación

Requiere Windows + Visual Studio 2022 con herramientas de desarrollo de Office/VSTO + .NET Framework 4.8. Incluye `build.ps1` y workflow de GitHub Actions para compilar en `windows-2022` y generar el instalador con Inno Setup.

Esta entrega fue revisada estáticamente en Linux, pero **no ha sido ejecutada dentro de Word/Excel/PowerPoint reales** en este entorno. La compilación y prueba en Windows es el siguiente gate antes de llamarla versión final de instalación.

Consulta `docs/INVESTIGACION-Y-HOJA-DE-RUTA.md` para la especificación técnica, prioridades P0/P1/P2 y límites reales de compatibilidad.
